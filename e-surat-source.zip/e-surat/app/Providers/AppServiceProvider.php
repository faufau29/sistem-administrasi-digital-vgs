<?php

namespace App\Providers;

use Illuminate\Routing\Router;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        $this->app->booted(function () {
            /** @var Router $router */
            $router = $this->app->make(Router::class);
            $router->aliasMiddleware('role', \App\Http\Middleware\RoleMiddleware::class);
        });
    }
}
