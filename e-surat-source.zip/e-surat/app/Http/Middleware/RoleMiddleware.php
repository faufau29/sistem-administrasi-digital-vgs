<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class RoleMiddleware
{
    /**
     * Handle an incoming request.
     * Usage: register alias 'role' => RoleMiddleware::class and use 'role:admin'
     */
    public function handle(Request $request, Closure $next, $role = null)
    {
        $user = $request->user();
        if (! $user) {
            return redirect('/login');
        }

        if ($role) {
            // support multiple roles separated by | or ,
            $roles = preg_split('/[\|,]/', $role);
            $roles = array_map('trim', $roles);
            if (! in_array($user->role, $roles, true)) {
                abort(403, 'Unauthorized');
            }
        }

        return $next($request);
    }
}
