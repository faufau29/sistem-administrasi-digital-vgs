<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DocumentCategory;

class DocumentCategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $categories = DocumentCategory::orderBy('name')->paginate(20);
        return view('categories.index', compact('categories'));
    }

    public function create()
    {
        return view('categories.create');
    }

    public function store(Request $request)
    {
        $this->authorizeAction($request->user());

        $data = $request->validate([
            'name' => 'required|string',
            'code' => 'nullable|string',
            'is_active' => 'nullable|boolean',
        ]);

        $data['is_active'] = $request->has('is_active');
        DocumentCategory::create($data);
        return redirect()->route('categories.index')->with('success','Category created');
    }

    public function show(DocumentCategory $category)
    {
        return view('categories.show', compact('category'));
    }

    public function edit(DocumentCategory $category)
    {
        return view('categories.edit', compact('category'));
    }

    public function update(Request $request, DocumentCategory $category)
    {
        $this->authorizeAction($request->user());

        $data = $request->validate([
            'name' => 'required|string',
            'code' => 'nullable|string',
            'is_active' => 'nullable|boolean',
        ]);

        $data['is_active'] = $request->has('is_active');
        $category->update($data);
        return redirect()->route('categories.index')->with('success','Category updated');
    }

    public function destroy(Request $request, DocumentCategory $category)
    {
        $this->authorizeAction($request->user());
        $category->delete();
        return redirect()->route('categories.index')->with('success','Category deleted');
    }

    protected function authorizeAction($user)
    {
        if (! $user || ! in_array($user->role, ['admin','direktur'])) {
            abort(403);
        }
    }
}
