<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use App\Models\Receipt;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function monthly(Request $request)
    {
        $report = $this->monthlyReportData($request);

        return view('reports.monthly', $report);
    }

    public function monthlyPdf(Request $request)
    {
        $report = $this->monthlyReportData($request);
        $filename = 'Laporan-Bulanan-Invoice-Kwitansi-'.$report['year'].'.pdf';

        return Pdf::loadView('reports.monthly-pdf', $report)
            ->setPaper('a4', 'portrait')
            ->download($filename);
    }

    private function monthlyReportData(Request $request): array
    {
        $validated = $request->validate([
            'year' => ['nullable', 'integer', 'digits:4', 'between:1900,9999'],
        ]);
        $year = (int) ($validated['year'] ?? now()->year);
        $monthNames = [
            1 => 'Januari',
            2 => 'Februari',
            3 => 'Maret',
            4 => 'April',
            5 => 'Mei',
            6 => 'Juni',
            7 => 'Juli',
            8 => 'Agustus',
            9 => 'September',
            10 => 'Oktober',
            11 => 'November',
            12 => 'Desember',
        ];

        $monthlyReports = collect(range(1, 12))->map(function (int $month) use ($year, $monthNames) {
            $start = Carbon::create($year, $month, 1)->startOfMonth();
            $startDate = $start->toDateString();
            $endDate = $start->copy()->endOfMonth()->toDateString();
            $invoiceCount = Invoice::query()
                ->whereBetween('date', [$startDate, $endDate])
                ->count();
            $receiptCount = Receipt::query()
                ->whereBetween('date', [$startDate, $endDate])
                ->count();

            return [
                'month' => $month,
                'month_name' => $monthNames[$month],
                'invoice_count' => $invoiceCount,
                'receipt_count' => $receiptCount,
                'total_count' => $invoiceCount + $receiptCount,
            ];
        });

        return [
            'monthlyReports' => $monthlyReports,
            'year' => $year,
            'totalInvoices' => $monthlyReports->sum('invoice_count'),
            'totalReceipts' => $monthlyReports->sum('receipt_count'),
            'totalDocuments' => $monthlyReports->sum('total_count'),
        ];
    }
}
