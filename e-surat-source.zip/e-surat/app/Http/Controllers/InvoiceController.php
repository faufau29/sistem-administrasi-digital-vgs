<?php

namespace App\Http\Controllers;

use App\Models\DocumentNumberHistory;
use App\Models\DocumentSequence;
use App\Models\Invoice;
use App\Services\ExportService;
use App\Services\SequenceGenerator;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\SimpleType\Jc;

class InvoiceController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $invoices = $this->filteredInvoices($request)
            ->orderByDesc('number')
            ->paginate(10)
            ->withQueryString();

        return view('invoices.index', compact('invoices'));
    }

    public function export(Request $request)
    {
        $invoices = $this->filteredInvoices($request)
            ->with('items')
            ->orderBy('number')
            ->get();
        $format = $request->input('format', 'csv');
        if ($format === 'xlsx') {
            return ExportService::exportInvoicesXlsx($invoices);
        }

        return ExportService::exportInvoicesCsv($invoices);
    }

    private function filteredInvoices(Request $request): Builder
    {
        $filters = $request->validate([
            'search' => ['nullable', 'string', 'max:255'],
            'month' => ['nullable', 'integer', 'between:1,12'],
            'year' => ['nullable', 'integer', 'digits:4', 'between:1900,9999'],
        ]);

        $query = Invoice::query();

        if (! empty($filters['search'])) {
            $search = $filters['search'];
            $query->where(function (Builder $query) use ($search) {
                $query->where('full_number', 'like', "%{$search}%")
                    ->orWhere('recipient', 'like', "%{$search}%")
                    ->orWhere('description', 'like', "%{$search}%")
                    ->orWhere('status', 'like', "%{$search}%");
            });
        }

        $this->applyDateFilters($query, $filters);

        return $query;
    }

    private function applyDateFilters(Builder $query, array $filters): void
    {
        $year = $filters['year'] ?? null;
        $month = $filters['month'] ?? null;

        if ($year !== null && $month !== null) {
            $start = Carbon::createFromDate((int) $year, (int) $month, 1)->startOfMonth();
            $query->whereBetween('date', [$start->toDateString(), $start->copy()->endOfMonth()->toDateString()]);
        } elseif ($year !== null) {
            $start = Carbon::createFromDate((int) $year, 1, 1)->startOfYear();
            $query->whereBetween('date', [$start->toDateString(), $start->copy()->endOfYear()->toDateString()]);
        } elseif ($month !== null) {
            $query->whereMonth('date', (int) $month);
        }
    }

    public function create()
    {
        return view('invoices.create', [
            'trainingCatalog' => config('invoice_trainings'),
            'nextNumber' => SequenceGenerator::preview('invoice', null, [
                'padding' => 1,
                'format' => '{number_plain} - VTR',
            ])['full_number'],
        ]);
    }

    public function store(Request $request)
    {
        $data = $this->validatedInvoiceData($request, true);
        $data['created_by'] = Auth::id();
        $requestedFullNumber = $data['full_number'] ?? null;

        $result = null;
        DB::transaction(function () use (&$result, $data, $requestedFullNumber) {
            if ($requestedFullNumber !== null) {
                $number = (int) strtok($requestedFullNumber, ' ');
                $this->recordRequestedNumber($number, $requestedFullNumber, $data['created_by']);
            } else {
                $seq = SequenceGenerator::next('invoice', null, [
                    'created_by' => $data['created_by'],
                    'padding' => 1,
                    'format' => '{number_plain} - VTR',
                ]);
                $number = $seq['number'];
                $requestedFullNumber = $seq['full_number'];
            }

            $lineItems = $data['_items'];
            unset($data['_items']);

            $result = Invoice::create(array_merge($data, [
                'number' => $number,
                'full_number' => $requestedFullNumber,
            ]));
            $result->items()->createMany($lineItems);
        });

        return redirect()->route('invoices.show', $result)->with('success', 'Invoice created');
    }

    public function show(Invoice $invoice)
    {
        return view('invoices.show', compact('invoice'));
    }

    public function pdf(Invoice $invoice)
    {
        return Pdf::loadView('invoices.pdf', compact('invoice'))
            ->setPaper('a4')
            ->stream($this->invoiceFilename($invoice, 'pdf'));
    }

    private function safeFilenamePart(string $value, int $maxLength): string
    {
        $value = preg_replace('/[<>:"\/\\\\|?*\x00-\x1F]/u', ' ', $value);
        $value = preg_replace('/\s+/u', ' ', trim($value));
        $value = trim(Str::limit($value, $maxLength, ''), " .\t\n\r\0\x0B");

        return $value !== '' ? $value : 'Invoice';
    }

    private function invoiceFilename(Invoice $invoice, string $extension): string
    {
        $trainingNames = $invoice->lineItems()
            ->map(fn ($item) => preg_replace('/^Penyedia(?:an)?\s+Pelatihan\s+(?:dan\s+)?Sertifikasi\s+/iu', '', trim($item->description)))
            ->filter(fn ($name) => $name !== '')
            ->map(fn ($name) => $this->safeFilenamePart($name, 100));
        $trainingName = $trainingNames->isNotEmpty()
            ? $trainingNames->implode(' & ')
            : 'Invoice';
        $recipient = $this->safeFilenamePart($invoice->recipient, 100);

        return $invoice->number.'. inv '.$trainingName.' '.$recipient.'.'.$extension;
    }

    public function word(Invoice $invoice)
    {
        $tax = $invoice->taxAmount();
        $lineItems = $invoice->lineItems();
        $downPayment = (float) ($invoice->down_payment ?? 0);
        $grossTotal = $invoice->totalWithTax();
        $remaining = max(0, $grossTotal - $downPayment);
        $signaturePath = public_path($invoice->requiresStamp()
            ? 'images/invoice-signature-stamped-mark.png'
            : 'images/invoice-signature-mark.png');

        if (! is_file($signaturePath)) {
            abort(500, 'Invoice signature image is missing.');
        }

        $word = new PhpWord;
        $word->setDefaultFontName('Times New Roman');
        $word->setDefaultFontSize(9);
        $section = $word->addSection([
            'paperSize' => 'A4',
            'marginTop' => 1440,
            'marginBottom' => 900,
            'marginLeft' => 1140,
            'marginRight' => 1140,
        ]);

        $header = $section->addTable([
            'alignment' => Jc::CENTER,
            'borderSize' => 2,
            'borderColor' => 'FFFFFF',
            'cellMargin' => 0,
            'width' => 10000,
            'unit' => 'pct',
            'layout' => 'fixed',
        ]);
        $header->addRow(null, ['cantSplit' => true]);
        $companyCell = $header->addCell(6000, ['valign' => 'bottom']);
        $companyCell->addText('PT. Veritrust Global Solusindo', ['bold' => true, 'size' => 12], [
            'spaceAfter' => 60,
        ]);
        $companyCell->addText(
            "Komplek NABE Blok A2 No 6 Banjar Agung Cipocok Jaya Kota Serang\nPhone: 0818 1881 0021\noffice@veritrust.id",
            ['size' => 8.25],
            ['spaceAfter' => 0],
        );
        $metaCell = $header->addCell(4000, ['valign' => 'bottom']);
        $metaCell->addText('Nomor : '.$invoice->full_number, ['size' => 8.25], [
            'alignment' => Jc::END,
            'spaceAfter' => 0,
        ]);
        $metaCell->addText('Tanggal : '.Carbon::parse($invoice->date)->format('d/m/Y'), ['size' => 8.25], [
            'alignment' => Jc::END,
            'spaceAfter' => 0,
        ]);

        $section->addText('Bill To:', ['bold' => true], [
            'spaceBefore' => 240,
            'spaceAfter' => 0,
        ]);
        $section->addText($invoice->recipient, ['bold' => true], ['spaceAfter' => 0]);
        $section->addTextBreak(1);
        $section->addText('Di', [], ['spaceAfter' => 0]);
        $section->addText('Tempat', [], [
            'indentation' => ['left' => 270],
            'spaceAfter' => 0,
        ]);
        $section->addText('INVOICE', ['bold' => true, 'size' => 11.25], [
            'alignment' => Jc::CENTER,
            'spaceBefore' => 180,
            'spaceAfter' => 270,
        ]);

        $tableStyle = [
            'alignment' => Jc::CENTER,
            'borderSize' => 6,
            'borderColor' => '111111',
            'cellMargin' => 90,
            'width' => 10000,
            'unit' => 'pct',
            'layout' => 'fixed',
        ];
        $word->addTableStyle('InvoiceTable', $tableStyle);
        $table = $section->addTable('InvoiceTable');
        $headerCell = ['bgColor' => 'C8C8C8', 'valign' => 'center'];
        $headerText = ['bold' => true];
        $center = ['alignment' => Jc::CENTER];
        $right = ['alignment' => Jc::END];

        $table->addRow(null, ['tblHeader' => true, 'cantSplit' => true]);
        $table->addCell(4600, $headerCell)->addText('Item Description', $headerText, $center);
        $table->addCell(900, $headerCell)->addText('Qty', $headerText, $center);
        $table->addCell(2200, $headerCell)->addText('Price Per', $headerText, $center);
        $table->addCell(2300, $headerCell)->addText('Total', $headerText, $center);

        foreach ($lineItems as $item) {
            $table->addRow(null, ['cantSplit' => true]);
            $description = $table->addCell(4600, ['noWrap' => false])->addTextRun();
            foreach (preg_split('/\R/u', $item->description) as $index => $line) {
                if ($index > 0) {
                    $description->addTextBreak();
                }

                $description->addText($line);
            }
            $table->addCell(900)->addText(number_format($item->quantity, 0, ',', '.'), [], $center);
            $table->addCell(2200)->addText('Rp. '.number_format((float) $item->unit_price, 0, ',', '.'), [], $right);
            $table->addCell(2300)->addText('Rp. '.number_format((float) $item->line_total, 0, ',', '.'), [], $right);
        }

        if ($tax > 0) {
            $table->addRow(null, ['cantSplit' => true]);
            $table->addCell(4600)->addText('PPn Nilai Lain', [], $right);
            $table->addCell(900);
            $table->addCell(2200);
            $table->addCell(2300)->addText('Rp. '.number_format($tax, 0, ',', '.'), [], $right);
        }

        if ($downPayment > 0) {
            $table->addRow(null, ['cantSplit' => true]);
            $table->addCell(4600)->addText('DP', [], $right);
            $table->addCell(900);
            $table->addCell(2200);
            $table->addCell(2300)->addText('-Rp. '.number_format($downPayment, 0, ',', '.'), [], $right);
        }

        $table->addRow(420, ['exactHeight' => true, 'cantSplit' => true]);
        $spacerCell = ['cellMargin' => 0];
        $table->addCell(4600, $spacerCell);
        $table->addCell(900, $spacerCell);
        $table->addCell(2200, $spacerCell);
        $table->addCell(2300, $spacerCell);

        $table->addRow(null, ['cantSplit' => true]);
        $bankCell = $table->addCell(4600, ['bgColor' => 'C8C8C8']);
        $bankCell->addText('Bank BCA : 5421-1822-22', ['bold' => true, 'size' => 8.25], ['spaceAfter' => 0]);
        $bankCell->addText('Bank Mandiri : 163-00-0332556-3', ['bold' => true, 'size' => 8.25], ['spaceAfter' => 0]);
        $bankCell->addText('a.n. PT VERITRUST GLOBAL SOLUSINDO', ['bold' => true, 'size' => 8.25], ['spaceAfter' => 0]);
        $table->addCell(900, ['bgColor' => 'C8C8C8']);
        $table->addCell(2200, $headerCell)->addText($downPayment > 0 ? 'TOTAL SISA' : 'TOTAL', $headerText, $center);
        $table->addCell(2300, $headerCell)->addText(
            'Rp. '.number_format($downPayment > 0 ? $remaining : $grossTotal, 0, ',', '.'),
            $headerText,
            $right,
        );

        if ($invoice->paymentNote() !== null) {
            $section->addText(
                $invoice->paymentNote(),
                ['size' => 8.25],
                ['indentation' => ['left' => 60], 'spaceBefore' => 75],
            );
        }

        $closing = $section->addTable([
            'alignment' => Jc::END,
            'borderSize' => 2,
            'borderColor' => 'FFFFFF',
            'cellMargin' => 0,
            'width' => 10000,
            'unit' => 'pct',
            'layout' => 'fixed',
        ]);
        $closing->addRow(null, ['cantSplit' => true]);
        $closing->addCell(6000);
        $closingCell = $closing->addCell(4000);
        $closingCell->addText('Hormat Kami,', [], [
            'alignment' => Jc::CENTER,
            'spaceBefore' => 240,
            'spaceAfter' => 0,
        ]);
        $closingCell->addTextBreak(1);
        $closingCell->addImage($signaturePath, [
            'width' => 190,
            'alignment' => Jc::CENTER,
        ]);
        $closingCell->addText('Fitriyah, S.Si., M.Si', [
            'name' => 'Times New Roman',
            'size' => 10.5,
            'bold' => true,
            'underline' => 'single',
        ], ['alignment' => Jc::CENTER, 'spaceAfter' => 0]);
        $closingCell->addText('General Manager', [
            'name' => 'Arial',
            'size' => 9.75,
        ], ['alignment' => Jc::CENTER, 'spaceAfter' => 0]);

        return response()->streamDownload(function () use ($word) {
            IOFactory::createWriter($word, 'Word2007')->save('php://output');
        }, $this->invoiceFilename($invoice, 'docx'), [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        ]);
    }

    public function edit(Invoice $invoice)
    {
        return view('invoices.edit', [
            'invoice' => $invoice->load('items'),
            'trainingCatalog' => config('invoice_trainings'),
        ]);
    }

    public function update(Request $request, Invoice $invoice)
    {
        $data = $this->validatedInvoiceData($request, false, $invoice);
        $lineItems = $data['_items'];
        unset($data['_items']);

        DB::transaction(function () use ($invoice, $data, $lineItems) {
            if ((int) $data['number'] !== (int) $invoice->number) {
                $this->recordRequestedNumber((int) $data['number'], $data['full_number'], Auth::id());
            }

            $invoice->update($data);
            $invoice->items()->delete();
            $invoice->items()->createMany($lineItems);
        });

        return redirect()->route('invoices.show', $invoice)->with('success', 'Invoice updated');
    }

    private function validatedInvoiceData(Request $request, bool $allowRequestedNumber = false, ?Invoice $invoice = null): array
    {
        $requestedNumber = trim((string) $request->input('full_number', ''));
        if ($requestedNumber !== '' && preg_match('/^(\d+)(?:\s*-\s*VTR)?$/i', $requestedNumber, $matches)) {
            $request->merge(['full_number' => $matches[1].' - VTR']);
            $requestedNumber = $matches[1].' - VTR';
        }
        $request->merge([
            'number' => $requestedNumber !== '' && preg_match('/^(\d+) - VTR$/', $requestedNumber, $matches)
                ? (int) $matches[1]
                : null,
        ]);

        $commonRules = [
            'date' => ['required', 'date'],
            'recipient' => ['required', 'string', 'max:255'],
            'number' => ['nullable', 'integer', Rule::unique('invoices', 'number')->ignore($invoice?->getKey())],
            'full_number' => $allowRequestedNumber
                ? [
                    'nullable',
                    'string',
                    'max:30',
                    'regex:/^\d+ - VTR$/',
                    Rule::unique('invoices', 'full_number'),
                ]
                : [
                    'required',
                    'string',
                    'max:30',
                    'regex:/^\d+ - VTR$/',
                    Rule::unique('invoices', 'full_number')->ignore($invoice?->getKey()),
                ],
            'client_type' => ['required', 'in:individual,company'],
            'down_payment' => ['nullable', 'integer', 'min:0', 'max:9999999999999'],
            'status' => ['required', 'in:draft,issued,paid'],
        ];

        if ($request->has('items')) {
            $data = $request->validate($commonRules + [
                'items' => ['required', 'array', 'min:1', 'max:20'],
                'items.*.training' => ['required', Rule::in(array_merge(array_keys(config('invoice_trainings')), ['custom']))],
                'items.*.description' => ['nullable', 'string', 'max:1000'],
                'items.*.quantity' => ['required', 'integer', 'min:1', 'max:999999'],
                'items.*.unit_price' => ['required', 'integer', 'min:1', 'max:999999999999'],
            ], [
                'items.required' => 'Tambahkan minimal satu skema pelatihan.',
                'items.min' => 'Tambahkan minimal satu skema pelatihan.',
                'items.*.training.required' => 'Pilih skema pelatihan.',
                'items.*.quantity.min' => 'Jumlah setiap skema minimal 1.',
                'full_number.unique' => 'Nomor invoice sudah digunakan.',
                'number.unique' => 'Nomor invoice sudah digunakan.',
            ]);

            $lineItems = [];
            $total = 0;
            $totalQuantity = 0;
            $catalog = config('invoice_trainings');

            foreach ($data['items'] as $index => $item) {
                if ($item['training'] === 'custom') {
                    $description = trim((string) ($item['description'] ?? ''));
                    $unitPrice = (int) ($item['unit_price'] ?? 0);

                    if ($description === '' || $unitPrice < 1) {
                        throw ValidationException::withMessages([
                            "items.{$index}.description" => 'Nama skema dan harga wajib diisi untuk pelatihan lainnya.',
                        ]);
                    }

                    $trainingCode = null;
                } else {
                    $training = $catalog[$item['training']];
                    $description = $training['name'];
                    $unitPrice = (int) $item['unit_price'];
                    $trainingCode = $item['training'];
                }

                $quantity = (int) $item['quantity'];
                $lineTotal = $quantity * $unitPrice;
                if ($lineTotal > 9999999999999 - $total) {
                    throw ValidationException::withMessages([
                        'items' => 'Total invoice melebihi batas nilai yang didukung.',
                    ]);
                }

                $total += $lineTotal;
                $totalQuantity += $quantity;

                $lineItems[] = [
                    'training_code' => $trainingCode,
                    'description' => $description,
                    'quantity' => $quantity,
                    'unit_price' => $unitPrice,
                    'line_total' => $lineTotal,
                ];
            }

            unset($data['items']);
        } else {
            $data = $request->validate($commonRules + [
                'description' => ['required', 'string', 'max:1000'],
                'quantity' => ['required', 'integer', 'min:1', 'max:999999'],
                'unit_price' => ['required', 'integer', 'min:1', 'max:999999999999'],
            ], [
                'description.required' => 'Deskripsi barang atau jasa wajib diisi.',
                'quantity.min' => 'Jumlah minimal 1.',
                'unit_price.min' => 'Harga per unit harus lebih dari Rp0.',
                'status.in' => 'Status invoice tidak valid.',
                'full_number.unique' => 'Nomor invoice sudah digunakan.',
                'number.unique' => 'Nomor invoice sudah digunakan.',
            ]);

            $quantity = (int) $data['quantity'];
            $unitPrice = (int) $data['unit_price'];
            $total = $quantity * $unitPrice;
            $totalQuantity = $quantity;
            $lineItems = [[
                'training_code' => null,
                'description' => $data['description'],
                'quantity' => $quantity,
                'unit_price' => $unitPrice,
                'line_total' => $total,
            ]];
        }

        $data['down_payment'] = (int) ($data['down_payment'] ?? 0);
        $tax = $data['client_type'] === 'company' ? (int) round($total * 0.11) : 0;
        $grossTotal = $total + $tax;

        if ($grossTotal > 9999999999999) {
            throw ValidationException::withMessages([
                'items' => 'Total invoice melebihi batas nilai yang didukung.',
            ]);
        }

        if ((int) $data['down_payment'] > $grossTotal) {
            throw ValidationException::withMessages([
                'down_payment' => 'DP tidak boleh lebih besar dari total invoice termasuk PPn.',
            ]);
        }

        $data['amount'] = $total;
        $data['description'] = implode("\n", array_column($lineItems, 'description'));
        if (mb_strlen($data['description']) > 1000) {
            throw ValidationException::withMessages([
                'items' => 'Gabungan nama pelatihan tidak boleh lebih dari 1.000 karakter.',
            ]);
        }
        $data['quantity'] = $totalQuantity;
        $data['unit_price'] = count($lineItems) === 1 ? $lineItems[0]['unit_price'] : null;
        $data['_items'] = $lineItems;

        return $data;
    }

    private function recordRequestedNumber(int $number, string $fullNumber, ?int $createdBy): void
    {
        $sequence = DocumentSequence::query()
            ->where('document_type', 'invoice')
            ->whereNull('category_id')
            ->lockForUpdate()
            ->first();

        if (! $sequence) {
            $sequence = DocumentSequence::create([
                'document_type' => 'invoice',
                'category_id' => null,
                'last_number' => 0,
                'padding' => 1,
                'format' => '{number_plain} - VTR',
            ]);
        }

        $sequence->last_number = max($sequence->last_number, $number);
        $sequence->save();

        DocumentNumberHistory::create([
            'document_type' => 'invoice',
            'category_id' => null,
            'number' => $number,
            'full_number' => $fullNumber,
            'created_by' => $createdBy,
            'status' => 'requested',
            'notes' => 'Nomor invoice dimasukkan atau diubah.',
        ]);
    }

    public function destroy(Invoice $invoice)
    {
        $invoice->delete();

        return redirect()->route('invoices.index')->with('success', 'Invoice deleted');
    }
}
