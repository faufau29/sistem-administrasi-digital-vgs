<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\SequenceGenerator;

class SequenceController extends Controller
{
    public function generate(Request $request)
    {
        $data = $request->validate([
            'document_type' => 'required|string',
            'category_id' => 'nullable|integer|exists:document_categories,id',
            'format' => 'nullable|string',
        ]);

        $result = SequenceGenerator::next($data['document_type'], $data['category_id'] ?? null, [
            'format' => $data['format'] ?? null,
            'created_by' => $request->user()->id ?? null,
        ]);

        return response()->json($result);
    }
}
