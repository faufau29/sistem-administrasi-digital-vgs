<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Invoice;
use App\Models\Receipt;
use App\Models\Letter;

class DocumentController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function dashboard()
    {
        $letters = Letter::count();
        $invoices = Invoice::count();
        $receipts = Receipt::count();
        $lettersThisMonth = Letter::whereMonth('date', now()->month)->count();
        $documentsThisYear = Letter::whereYear('date', now()->year)->count() + Invoice::whereYear('date', now()->year)->count() + Receipt::whereYear('date', now()->year)->count();

        return view('dashboard', compact('letters','invoices','receipts','lettersThisMonth','documentsThisYear'));
    }
}
