<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\LetterTemplate;
use App\Models\DocumentCategory;

class LetterTemplateController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $templates = LetterTemplate::with('category')->paginate(20);
        return view('templates.index', compact('templates'));
    }

    public function create()
    {
        $categories = DocumentCategory::where('is_active',true)->get();
        $letterTypes = config('letter_types');
        return view('templates.create', compact('categories','letterTypes'));
    }

    public function store(Request $request)
    {
        $this->authorizeAction($request->user());

        $data = $request->validate([
            'category_id' => 'nullable|exists:document_categories,id',
            'letter_type' => 'nullable|string|in:'.implode(',', array_keys(config('letter_types'))),
            'name' => 'required|string',
            'content' => 'required|string',
            'is_default' => 'nullable|boolean',
            'template_file' => 'nullable|file|mimes:doc,docx',
        ]);

        $data['is_default'] = $request->has('is_default');

        if ($request->hasFile('template_file')) {
            $file = $request->file('template_file');
            $filename = uniqid('tpl_', true) . '.' . $file->getClientOriginalExtension();
            $file->storeAs('public/templates', $filename);
            $data['file_name'] = $filename;
        }

        LetterTemplate::create($data);
        return redirect()->route('templates.index')->with('success','Template created');
    }

    public function show(LetterTemplate $template)
    {
        return view('templates.show', compact('template'));
    }

    public function edit(LetterTemplate $template)
    {
        $categories = DocumentCategory::where('is_active',true)->get();
        $letterTypes = config('letter_types');
        return view('templates.edit', compact('template','categories','letterTypes'));
    }

    public function update(Request $request, LetterTemplate $template)
    {
        $this->authorizeAction($request->user());

        $data = $request->validate([
            'category_id' => 'nullable|exists:document_categories,id',
            'letter_type' => 'nullable|string|in:'.implode(',', array_keys(config('letter_types'))),
            'name' => 'required|string',
            'content' => 'required|string',
            'is_default' => 'nullable|boolean',
            'template_file' => 'nullable|file|mimes:doc,docx',
        ]);

        $data['is_default'] = $request->has('is_default');
        if ($request->hasFile('template_file')) {
            $file = $request->file('template_file');
            $filename = uniqid('tpl_', true) . '.' . $file->getClientOriginalExtension();
            $file->storeAs('public/templates', $filename);
            $data['file_name'] = $filename;
        }

        $template->update($data);
        return redirect()->route('templates.index')->with('success','Template updated');
    }

    public function destroy(Request $request, LetterTemplate $template)
    {
        $this->authorizeAction($request->user());
        $template->delete();
        return redirect()->route('templates.index')->with('success','Template deleted');
    }

    protected function authorizeAction($user)
    {
        if (! $user || ! in_array($user->role, ['admin','direktur'])) {
            abort(403);
        }
    }
}
