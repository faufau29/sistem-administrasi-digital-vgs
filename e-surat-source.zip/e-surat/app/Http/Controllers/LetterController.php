<?php

namespace App\Http\Controllers;

use App\Models\DocumentCategory;
use App\Models\Letter;
use App\Models\LetterTemplate;
use App\Services\DocxTemplateRenderer;
use App\Services\ExportService;
use App\Services\LibreOfficePdfRenderer;
use App\Services\SequenceGenerator;
use App\Services\TemplateRenderer;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Dompdf\Dompdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use PhpOffice\PhpWord\Element\Section;
use PhpOffice\PhpWord\Escaper\Xml;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\Settings;
use PhpOffice\PhpWord\SimpleType\Jc;
use PhpOffice\PhpWord\TemplateProcessor;

class LetterController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $q = Letter::query()->with('category');
        if ($request->filled('search')) {
            $s = $request->input('search');
            $q->where('full_number', 'like', '%'.$s.'%')
                ->orWhere('subject', 'like', '%'.$s.'%')
                ->orWhere('recipient_company', 'like', '%'.$s.'%');
        }
        $letters = $q->orderBy('date', 'desc')->paginate(20);

        return view('letters.index', compact('letters'));
    }

    public function export(Request $request)
    {
        $q = Letter::query();
        if ($request->filled('search')) {
            $s = $request->input('search');
            $q->where('full_number', 'like', '%'.$s.'%')
                ->orWhere('subject', 'like', '%'.$s.'%')
                ->orWhere('recipient_company', 'like', '%'.$s.'%');
        }
        $letters = $q->orderBy('date', 'desc')->get();

        $format = $request->input('format', 'csv');
        if ($format === 'xlsx') {
            return ExportService::exportLettersXlsx($letters);
        }

        return ExportService::exportLettersCsv($letters);
    }

    public function create(?string $letterType = null)
    {
        $letterTypes = config('letter_types');
        if ($letterType === null) {
            return view('letters.choose-type', compact('letterTypes'));
        }

        abort_unless(array_key_exists($letterType, $letterTypes), 404);

        $categories = DocumentCategory::where('is_active', true)->orderBy('name')->get();
        $templates = LetterTemplate::with('category')->get();
        $proposalSchemes = config('proposal_schemes');
        $instructorDefaults = config('instructor_request.defaults');
        $defaultCategoryId = $categories->firstWhere('code', 'SRT')?->id ?? $categories->first()?->id;

        return view('letters.create', compact('categories', 'templates', 'letterTypes', 'letterType', 'proposalSchemes', 'defaultCategoryId', 'instructorDefaults'));
    }

    public function store(Request $request)
    {
        $requireInstructorDetails = $request->input('letter_type') === 'instructor_request'
            && $request->has('instructor_details');
        $instructorFieldRule = $requireInstructorDetails ? 'required|string' : 'nullable|string';
        $agendaRule = $requireInstructorDetails ? 'required|array|min:1' : 'nullable|array';

        $data = $request->validate([
            'category_id' => 'required|exists:document_categories,id',
            'template_id' => 'nullable|exists:letter_templates,id',
            'full_number' => 'nullable|string|max:255|unique:letters,full_number',
            'date' => 'required|date',
            'subject' => 'required|string',
            'letter_type' => ['required', 'string', Rule::in(array_keys(config('letter_types')))],
            'attachment_note' => 'nullable|string|max:255',
            'offer_items' => 'required_if:letter_type,proposal|array|min:1',
            'offer_items.*.scheme' => ['required', 'distinct', Rule::in([...array_keys(config('proposal_schemes')), 'custom'])],
            'offer_items.*.title' => 'required|string|max:500',
            'offer_items.*.schedule' => 'required|string|max:255',
            'offer_items.*.price' => 'required|numeric|min:0',
            'instructor_details' => $requireInstructorDetails ? 'required|array' : 'nullable|array',
            'instructor_details.training_name' => $instructorFieldRule.'|max:255',
            'instructor_details.training_schedule' => $instructorFieldRule.'|max:255',
            'instructor_details.training_time' => $instructorFieldRule.'|max:100',
            'instructor_details.training_place' => $instructorFieldRule.'|max:255',
            'instructor_details.rundown_title' => 'nullable|string|max:255',
            'instructor_details.agenda' => $agendaRule,
            'instructor_details.agenda.*.day' => $instructorFieldRule.'|max:100',
            'instructor_details.agenda.*.time' => $instructorFieldRule.'|max:50',
            'instructor_details.agenda.*.activity' => $instructorFieldRule.'|max:500',
            'instructor_details.agenda.*.pic' => $instructorFieldRule.'|max:150',
            'recipient_name' => $requireInstructorDetails ? 'required|string' : 'nullable|string',
            'recipient_title' => 'nullable|string',
            'recipient_company' => 'nullable|string',
            'recipient_address' => 'nullable|string',
            'body' => 'nullable|string',
            'signer_name' => 'nullable|string',
            'signer_title' => 'nullable|string',
            'status' => 'nullable|in:draft,pending,approved,rejected,published,archived',
        ], [
            'offer_items.required_if' => 'Tambahkan minimal satu skema untuk surat penawaran.',
            'offer_items.*.scheme.required' => 'Pilih skema untuk setiap paket penawaran.',
            'offer_items.*.scheme.distinct' => 'Setiap skema hanya boleh dipilih satu kali.',
            'offer_items.*.schedule.required' => 'Isi jadwal training untuk setiap paket.',
            'offer_items.*.price.required' => 'Isi harga untuk setiap paket.',
            'instructor_details.training_name.required' => 'Isi nama pelatihan untuk surat permohonan instruktur.',
            'instructor_details.training_schedule.required' => 'Isi hari dan tanggal pelatihan.',
            'instructor_details.training_time.required' => 'Isi waktu pelatihan.',
            'instructor_details.training_place.required' => 'Isi tempat pelatihan.',
            'instructor_details.agenda.required' => 'Tambahkan minimal satu baris rundown pelatihan.',
            'recipient_name.required' => 'Isi nama instruktur yang diundang.',
        ]);

        $this->validateTemplateType($data['template_id'] ?? null, $data['letter_type']);
        $data['created_by'] = Auth::id();
        $data['status'] = $data['status'] ?? 'draft';
        $data['offer_items'] = $data['letter_type'] === 'proposal' ? $data['offer_items'] : null;
        $data['attachment_note'] = $data['letter_type'] === 'proposal'
            ? count($data['offer_items']).' lampiran'
            : ($data['letter_type'] === 'instructor_request'
                ? ($data['attachment_note'] ?? 'Rundown pelatihan')
                : null);
        $data['template_id'] = $data['letter_type'] === 'proposal' ? null : ($data['template_id'] ?? null);
        $data['instructor_details'] = $data['letter_type'] === 'instructor_request'
            ? ($data['instructor_details'] ?? null)
            : null;

        // Generate number atomically and save letter
        $result = null;
        DB::transaction(function () use (&$result, $data) {
            $seq = SequenceGenerator::next('letter', $data['category_id'], ['created_by' => $data['created_by']]);
            $letter = Letter::create(array_merge($data, [
                'number' => $seq['number'],
                'full_number' => trim($data['full_number'] ?? '') ?: $seq['full_number'],
            ]));
            $result = $letter;
        });

        return redirect()->route('letters.show', $result->id)->with('success', 'Surat berhasil dibuat.');
    }

    public function show(Letter $letter)
    {
        $renderedBody = $letter->body;
        $template = $this->resolveTemplate($letter);
        if ($template && ! $letter->instructor_details) {
            $renderedBody = TemplateRenderer::render($template->content, $letter);
        }

        return view('letters.show', compact('letter', 'renderedBody'));
    }

    public function pdf(Letter $letter)
    {
        if ($letter->letter_type === 'proposal') {
            $pdf = Pdf::loadView('letters.proposal-pdf', $this->proposalPdfViewData($letter))
                ->setPaper('a4', 'portrait');

            return $pdf->stream('surat-penawaran-'.$letter->id.'.pdf');
        }

        if ($letter->letter_type === 'instructor_request' && $letter->instructor_details) {
            $pdf = $this->createInstructorRequestPdfContent($letter);

            return response($pdf, 200, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'inline; filename="surat-permohonan-instruktur-'.$letter->id.'.pdf"',
            ]);
        }

        $template = $this->resolveTemplate($letter);
        if ($template?->file_name) {
            $data = $this->letterTemplateData($letter);
            $html = (new DocxTemplateRenderer)->renderToHtml($template->file_name, $data);
            $pdf = Pdf::loadHTML($html)->setPaper('a4', 'portrait');

            return $pdf->stream('surat-'.$letter->id.'.pdf');
        }

        $renderedBody = $letter->body;
        if ($template) {
            $renderedBody = TemplateRenderer::render($template->content, $letter);
        }

        $html = view('letters.pdf', compact('letter', 'renderedBody'))->render();

        // If Barryvdh\\DomPDF is available
        if (class_exists('Barryvdh\\DomPDF\\Facade\\Pdf')) {
            $pdf = Pdf::loadHTML($html);

            return $pdf->stream('letter-'.$letter->id.'.pdf');
        }

        // Fallback to DOMPDF directly if installed
        if (class_exists('Dompdf\\Dompdf')) {
            $dompdf = new Dompdf;
            $dompdf->loadHtml($html);
            $dompdf->setPaper('A4', 'portrait');
            $dompdf->render();
            $dompdf->stream('letter-'.$letter->id.'.pdf');

            return response('', 200);
        }

        abort(500, 'DomPDF not installed. Run: composer require barryvdh/laravel-dompdf');
    }

    public function exportDocx(Request $request, Letter $letter, DocxTemplateRenderer $renderer)
    {
        if ($letter->letter_type === 'proposal') {
            return $this->exportProposalDocx($letter);
        }

        if ($letter->letter_type === 'instructor_request' && $letter->instructor_details) {
            return $this->exportInstructorRequestDocx($letter);
        }

        $template = $this->resolveTemplate($letter);
        $data = $this->letterTemplateData($letter);

        if ($template && $template->header_logo) {
            // If template contains images, TemplateProcessor needs different handling; keep simple for now
        }

        if ($template?->file_name) {
            $docx = $renderer->render($template->file_name, $data);

            return response()->download($docx)->deleteFileAfterSend(true);
        }

        return $this->exportGenericDocx($letter, $template);
    }

    public function exportPdf(Letter $letter)
    {
        if ($letter->letter_type === 'proposal') {
            $pdf = Pdf::loadView('letters.proposal-pdf', $this->proposalPdfViewData($letter))
                ->setPaper('a4', 'portrait');

            return $pdf->download('surat-penawaran-'.$letter->id.'.pdf');
        }

        if ($letter->letter_type === 'instructor_request' && $letter->instructor_details) {
            $pdf = $this->createInstructorRequestPdfContent($letter);

            return response($pdf, 200, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'attachment; filename="surat-permohonan-instruktur-'.$letter->id.'.pdf"',
            ]);
        }

        $docxPath = storage_path('app/exports/letter_'.$letter->id.'.docx');

        // Try to render DOCX first if template exists
        $template = $this->resolveTemplate($letter);
        if ($template) {
            $renderer = new DocxTemplateRenderer;
            $data = $this->letterTemplateData($letter);

            // If the template has an uploaded DOCX, render it to HTML then convert to PDF
            if ($template->file_name) {
                $html = $renderer->renderToHtml($template->file_name, $data);
                if (class_exists('Barryvdh\\DomPDF\\Facade\\Pdf')) {
                    $pdf = Pdf::loadHTML($html);

                    return $pdf->download('letter-'.$letter->id.'.pdf');
                }
                if (class_exists('Dompdf\\Dompdf')) {
                    $dompdf = new Dompdf;
                    $dompdf->loadHtml($html);
                    $dompdf->setPaper('A4', 'portrait');
                    $dompdf->render();
                    $out = $dompdf->output();

                    return response($out, 200, [
                        'Content-Type' => 'application/pdf',
                        'Content-Disposition' => 'attachment; filename="letter-'.$letter->id.'.pdf"',
                    ]);
                }
                abort(500, 'DomPDF not installed. Run: composer require barryvdh/laravel-dompdf');
            }
        }

        $renderedBody = $letter->body;
        if ($template && ! $template->file_name) {
            $renderedBody = TemplateRenderer::render($template->content, $letter);
        }
        $html = view('letters.pdf', compact('letter', 'renderedBody'))->render();
        if (class_exists('Barryvdh\\DomPDF\\Facade\\Pdf')) {
            $pdf = Pdf::loadHTML($html);

            return $pdf->download('letter-'.$letter->id.'.pdf');
        }
        if (class_exists('Dompdf\\Dompdf')) {
            $dompdf = new Dompdf;
            $dompdf->loadHtml($html);
            $dompdf->setPaper('A4', 'portrait');
            $dompdf->render();
            $out = $dompdf->output();

            return response($out, 200, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'attachment; filename="letter-'.$letter->id.'.pdf"',
            ]);
        }

        abort(500, 'DomPDF not installed. Run: composer require barryvdh/laravel-dompdf');
    }

    public function edit(Letter $letter)
    {
        $categories = DocumentCategory::where('is_active', true)->orderBy('name')->get();
        $templates = LetterTemplate::with('category')->get();
        $letterTypes = config('letter_types');
        $proposalSchemes = config('proposal_schemes');
        $letter->offer_items = $this->normalizeProposalItems($letter->offer_items ?? []);

        return view('letters.edit', compact('letter', 'categories', 'templates', 'letterTypes', 'proposalSchemes'));
    }

    public function update(Request $request, Letter $letter)
    {
        $letterType = $request->input('letter_type', $letter->letter_type);
        $requireInstructorDetails = $letterType === 'instructor_request'
            && $request->has('instructor_details');
        $instructorFieldRule = $requireInstructorDetails ? 'required|string' : 'nullable|string';
        $agendaRule = $requireInstructorDetails ? 'required|array|min:1' : 'nullable|array';

        $data = $request->validate([
            'category_id' => 'required|exists:document_categories,id',
            'template_id' => 'nullable|exists:letter_templates,id',
            'full_number' => ['required', 'string', 'max:255', Rule::unique('letters', 'full_number')->ignore($letter->id)],
            'date' => 'required|date',
            'subject' => 'required|string',
            'letter_type' => ['nullable', 'string', Rule::in(array_keys(config('letter_types')))],
            'attachment_note' => 'nullable|string|max:255',
            'offer_items' => 'required_if:letter_type,proposal|array|min:1',
            'offer_items.*.scheme' => ['required', 'distinct', Rule::in([...array_keys(config('proposal_schemes')), 'custom'])],
            'offer_items.*.title' => 'required|string|max:500',
            'offer_items.*.schedule' => 'required|string|max:255',
            'offer_items.*.price' => 'required|numeric|min:0',
            'instructor_details' => $requireInstructorDetails ? 'required|array' : 'nullable|array',
            'instructor_details.training_name' => $instructorFieldRule.'|max:255',
            'instructor_details.training_schedule' => $instructorFieldRule.'|max:255',
            'instructor_details.training_time' => $instructorFieldRule.'|max:100',
            'instructor_details.training_place' => $instructorFieldRule.'|max:255',
            'instructor_details.rundown_title' => 'nullable|string|max:255',
            'instructor_details.agenda' => $agendaRule,
            'instructor_details.agenda.*.day' => $instructorFieldRule.'|max:100',
            'instructor_details.agenda.*.time' => $instructorFieldRule.'|max:50',
            'instructor_details.agenda.*.activity' => $instructorFieldRule.'|max:500',
            'instructor_details.agenda.*.pic' => $instructorFieldRule.'|max:150',
            'recipient_name' => $requireInstructorDetails ? 'required|string' : 'nullable|string',
            'recipient_title' => 'nullable|string',
            'recipient_company' => 'nullable|string',
            'recipient_address' => 'nullable|string',
            'body' => 'nullable|string',
            'signer_name' => 'nullable|string',
            'signer_title' => 'nullable|string',
            'status' => 'nullable|in:draft,pending,approved,rejected,published,archived',
        ], [
            'offer_items.required_if' => 'Tambahkan minimal satu skema untuk surat penawaran.',
            'offer_items.*.scheme.required' => 'Pilih skema untuk setiap paket penawaran.',
            'offer_items.*.scheme.distinct' => 'Setiap skema hanya boleh dipilih satu kali.',
            'offer_items.*.schedule.required' => 'Isi jadwal training untuk setiap paket.',
            'offer_items.*.price.required' => 'Isi harga untuk setiap paket.',
            'instructor_details.training_name.required' => 'Isi nama pelatihan untuk surat permohonan instruktur.',
            'instructor_details.training_schedule.required' => 'Isi hari dan tanggal pelatihan.',
            'instructor_details.training_time.required' => 'Isi waktu pelatihan.',
            'instructor_details.training_place.required' => 'Isi tempat pelatihan.',
            'instructor_details.agenda.required' => 'Tambahkan minimal satu baris rundown pelatihan.',
            'recipient_name.required' => 'Isi nama instruktur yang diundang.',
        ]);

        $letterType = $data['letter_type'] ?? $letter->letter_type;
        $this->validateTemplateType($data['template_id'] ?? null, $letterType);
        $data['offer_items'] = ($data['letter_type'] ?? $letter->letter_type) === 'proposal'
            ? ($data['offer_items'] ?? $letter->offer_items)
            : null;
        $data['attachment_note'] = $letterType === 'proposal'
            ? count($data['offer_items']).' lampiran'
            : ($letterType === 'instructor_request' && ($data['instructor_details'] ?? $letter->instructor_details)
                ? ($data['attachment_note'] ?? $letter->attachment_note ?? 'Rundown pelatihan')
                : null);
        $data['template_id'] = $letterType === 'proposal' ? null : ($data['template_id'] ?? null);
        $data['instructor_details'] = $letterType === 'instructor_request'
            ? ($data['instructor_details'] ?? $letter->instructor_details)
            : null;

        // Keep the generated sequence number; the displayed letter number is editable.
        $letter->update($data);

        return redirect()->route('letters.show', $letter)->with('success', 'Surat berhasil diperbarui.');
    }

    private function exportProposalDocx(Letter $letter)
    {
        $word = new PhpWord;
        $word->setDefaultFontName('Times New Roman');
        $word->setDefaultFontSize(10);
        $section = $word->addSection([
            'paperSize' => 'A4',
            'marginTop' => 1900,
            'marginBottom' => 1900,
            'marginLeft' => 920,
            'marginRight' => 920,
        ]);
        $header = $section->addHeader();
        $header->addImage(public_path('images/proposal-letterhead.jpg'), [
            'width' => 526,
            'height' => 46,
            'alignment' => Jc::CENTER,
        ]);
        $footer = $section->addFooter();
        $footer->addImage(public_path('images/proposal-footer.jpg'), [
            'width' => 520,
            'height' => 56,
            'alignment' => Jc::CENTER,
        ]);

        $this->addProposalDocxCover($section, $letter);
        $section->addPageBreak();
        $this->addProposalDocxConditions($section, $letter);
        $textSchemes = $this->selectedProposalSchemes($letter, ['pppa', 'popal']);
        if ($textSchemes) {
            $section->addPageBreak();
            $this->addProposalDocxCompetencies($section, $letter, $textSchemes);
        }

        $chartSchemes = $this->selectedProposalSchemes($letter, ['oplb3', 'mplb3']);
        if ($chartSchemes) {
            $section->addPageBreak();
            $this->addProposalDocxCompetencyCharts($section, $letter);
        }
        $section->addPageBreak();
        $this->addProposalDocxRequirements($section);

        return response()->streamDownload(function () use ($word) {
            IOFactory::createWriter($word, 'Word2007')->save('php://output');
        }, 'surat-penawaran-'.$letter->id.'.docx', [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        ]);
    }

    private function addProposalDocxCover(
        Section $section,
        Letter $letter,
    ): void {
        $metadata = $section->addTable(['borderSize' => 0, 'cellMargin' => 0]);
        foreach ([
            ['Nomor', $letter->full_number, Carbon::parse($letter->date)->locale('id')->translatedFormat('d F Y')],
            ['Lampiran', $letter->attachment_note, ''],
            ['Perihal', $letter->subject, ''],
        ] as [$label, $value, $date]) {
            $metadata->addRow();
            $metadata->addCell(1250)->addText($label, ['size' => 10]);
            $metadata->addCell(250)->addText(':', ['size' => 10]);
            $metadata->addCell(5550)->addText($value ?: '', ['size' => 10]);
            $metadata->addCell(2350)->addText($date, ['size' => 9]);
        }

        $section->addTextBreak(1);
        $section->addText('Yth,', ['size' => 10]);
        $section->addText($letter->recipient_title ?: 'Direktur Utama', ['bold' => true, 'size' => 10]);
        $section->addText($letter->recipient_company ?: $letter->recipient_name ?: '', ['bold' => true, 'size' => 10]);
        $section->addText($letter->recipient_address ?: 'di Tempat.', ['size' => 10]);
        $section->addTextBreak(1);
        $section->addText('Dengan hormat,', ['size' => 10]);
        $section->addText(
            $letter->body ?: 'PT Veritrust Global Solusindo sebagai perusahaan di bidang pelayanan jasa pelatihan dan konsultasi manajemen K3 dan Lingkungan. Dengan ini menawarkan pelatihan dan sertifikasi BNSP sebagai berikut:',
            ['size' => 10],
            ['alignment' => Jc::BOTH],
        );

        $table = $section->addTable([
            'borderSize' => 6,
            'borderColor' => '444444',
            'cellMargin' => 55,
            'width' => 10000,
            'unit' => 'pct',
        ]);
        $table->addRow();
        foreach ([
            ['No', 600],
            ['Ruang Lingkup', 4650],
            ['Jadwal Training', 2500],
            ['Harga', 1650],
        ] as [$heading, $width]) {
            $table->addCell($width, ['bgColor' => 'D8D8D8', 'valign' => 'center'])
                ->addText($heading, ['bold' => true, 'size' => 9], ['alignment' => Jc::CENTER]);
        }
        foreach ($letter->offer_items ?? [] as $index => $item) {
            $table->addRow();
            $table->addCell(600)->addText((string) ($index + 1), ['size' => 8]);
            $table->addCell(4650)->addText($this->proposalPackageName($item), ['size' => 8]);
            $table->addCell(2500)->addText($item['schedule'] ?: '-', ['size' => 8], ['alignment' => Jc::CENTER]);
            $table->addCell(1650)->addText('Rp '.number_format((float) $item['price'], 0, ',', '.'), ['size' => 8]);
        }
    }

    private function exportInstructorRequestDocx(Letter $letter)
    {
        $docxPath = $this->createInstructorRequestDocx($letter);

        return response()->download($docxPath, 'surat-permohonan-instruktur-'.$letter->id.'.docx', [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        ])->deleteFileAfterSend(true);
    }

    private function createInstructorRequestPdf(Letter $letter): string
    {
        $docxPath = $this->createInstructorRequestDocx($letter);

        try {
            return (new LibreOfficePdfRenderer)->render($docxPath);
        } finally {
            @unlink($docxPath);
        }
    }

    private function createInstructorRequestPdfContent(Letter $letter): string
    {
        $pdfPath = $this->createInstructorRequestPdf($letter);

        try {
            $pdf = file_get_contents($pdfPath);
            if ($pdf === false) {
                throw new \RuntimeException('Tidak dapat membaca PDF surat permohonan instruktur.');
            }

            return $pdf;
        } finally {
            @unlink($pdfPath);
        }
    }

    private function createInstructorRequestDocx(Letter $letter): string
    {
        $details = $letter->instructor_details;
        $agenda = array_values($details['agenda'] ?? []);
        if ($agenda === []) {
            throw new \RuntimeException('Surat permohonan instruktur harus memiliki minimal satu baris rundown.');
        }

        $template = new TemplateProcessor(resource_path('templates/instructor_request.docx'));
        $template->cloneRow('agenda_time', count($agenda));
        $xmlEscaper = Settings::isOutputEscapingEnabled() ? null : new Xml;
        $escapeValue = static fn (string $value): string => $xmlEscaper !== null
            ? $xmlEscaper->escape($value)
            : $value;

        $rundownTitle = $details['rundown_title'] ?? $this->defaultRundownTitle($details['training_name'] ?? '');
        preg_match('/\b(20\d{2})\b/', $details['training_schedule'] ?? '', $yearMatch);
        $values = [
            'full_number' => $letter->full_number,
            'letter_date' => Carbon::parse($letter->date)->locale('id')->translatedFormat('d F Y'),
            'attachment_note' => $letter->attachment_note ?: '-',
            'subject' => $letter->subject,
            'recipient_name' => $letter->recipient_name,
            'recipient_address' => $letter->recipient_address ?: 'Di Tempat',
            'training_name' => $details['training_name'],
            'training_schedule' => $details['training_schedule'],
            'training_time' => $details['training_time'],
            'training_place' => $details['training_place'],
            'signer_name' => $letter->signer_name,
            'signer_title' => $letter->signer_title,
            'rundown_title' => $rundownTitle,
            'training_year' => $yearMatch[1] ?? Carbon::parse($letter->date)->format('Y'),
        ];
        foreach ($values as $key => $value) {
            $template->setValue($key, $escapeValue((string) ($value ?? '')));
        }

        $currentDay = null;
        $dayNumber = 0;
        foreach ($agenda as $index => $item) {
            $day = trim((string) ($item['day'] ?? ''));
            if ($day !== '' && $day !== $currentDay) {
                $currentDay = $day;
                $dayNumber = 1;
            } else {
                $dayNumber++;
            }
            $row = $index + 1;
            $template->setValue('agenda_no#'.$row, (string) $dayNumber);
            $template->setValue('agenda_day#'.$row, $escapeValue($day));
            $template->setValue('agenda_time#'.$row, $escapeValue((string) ($item['time'] ?? '')));
            $template->setValue('agenda_activity#'.$row, $escapeValue((string) ($item['activity'] ?? '')));
            $template->setValue('agenda_pic#'.$row, $escapeValue((string) ($item['pic'] ?? '')));
        }

        $directory = storage_path('app/exports');
        if (! is_dir($directory)) {
            mkdir($directory, 0755, true);
        }
        $path = $directory.DIRECTORY_SEPARATOR.'instructor-'.$letter->id.'-'.uniqid('', true).'.docx';
        $template->saveAs($path);
        $this->applyInstructorAgendaLayout($path, $agenda);

        return $path;
    }

    private function applyInstructorAgendaLayout(string $path, array $agenda): void
    {
        $archive = new \ZipArchive;
        if ($archive->open($path) !== true) {
            throw new \RuntimeException('Tidak dapat membuka dokumen surat instruktur.');
        }

        try {
            $documentXml = $archive->getFromName('word/document.xml');
            if ($documentXml === false) {
                throw new \RuntimeException('Dokumen surat instruktur tidak memiliki isi XML yang valid.');
            }

            $document = new \DOMDocument('1.0', 'UTF-8');
            if (! $document->loadXML($documentXml, LIBXML_NONET)) {
                throw new \RuntimeException('Isi XML surat instruktur tidak dapat diproses.');
            }

            $xpath = new \DOMXPath($document);
            $wordNamespace = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
            $xpath->registerNamespace('w', $wordNamespace);
            $table = $xpath->query('//w:tbl')->item(0);
            if (! $table) {
                throw new \RuntimeException('Tabel rundown tidak ditemukan pada template surat instruktur.');
            }

            $tableRows = $xpath->query('./w:tr', $table);
            $rows = [];
            foreach ($tableRows as $row) {
                $rows[] = $row;
            }

            if (count($rows) !== count($agenda) + 1) {
                throw new \RuntimeException('Jumlah baris rundown tidak sesuai dengan data surat instruktur.');
            }

            $dataRows = array_slice($rows, 1);
            $groups = [];
            $groupStart = 0;
            $groupDay = '';
            $previousDay = '';

            foreach ($agenda as $index => $item) {
                $day = trim((string) ($item['day'] ?? ''));
                if ($index > 0 && $day !== '' && $previousDay !== '' && $day !== $previousDay) {
                    $groups[] = ['start' => $groupStart, 'end' => $index - 1, 'day' => $groupDay];
                    $groupStart = $index;
                    $groupDay = $day;
                } elseif ($groupDay === '' && $day !== '') {
                    $groupDay = $day;
                }

                if ($day !== '') {
                    $previousDay = $day;
                }
            }
            $groups[] = ['start' => $groupStart, 'end' => count($agenda) - 1, 'day' => $groupDay];

            foreach ($groups as $group) {
                $groupLength = $group['end'] - $group['start'] + 1;
                for ($index = $group['start']; $index <= $group['end']; $index++) {
                    $cells = $xpath->query('./w:tc', $dataRows[$index]);
                    $dayCell = $cells->item(1);
                    if (! $dayCell) {
                        throw new \RuntimeException('Sel hari pada tabel rundown tidak ditemukan.');
                    }
                    $cellProperties = $xpath->query('./w:tcPr', $dayCell)->item(0);
                    if (! $cellProperties) {
                        throw new \RuntimeException('Sel hari pada tabel rundown tidak ditemukan.');
                    }

                    foreach ($xpath->query('./w:vMerge', $cellProperties) as $existingMerge) {
                        $cellProperties->removeChild($existingMerge);
                    }

                    if ($groupLength > 1) {
                        $merge = $document->createElementNS($wordNamespace, 'w:vMerge');
                        $merge->setAttributeNS($wordNamespace, 'w:val', $index === $group['start'] ? 'restart' : 'continue');
                        $anchor = $xpath->query('./w:vAlign', $cellProperties)->item(0);
                        if ($anchor) {
                            $cellProperties->insertBefore($merge, $anchor);
                        } else {
                            $cellProperties->appendChild($merge);
                        }
                    }

                    if ($index === $group['start']) {
                        $dayText = $xpath->query('.//w:t', $dayCell)->item(0);
                        if ($dayText) {
                            $dayText->nodeValue = $group['day'];
                        }
                    } else {
                        foreach ($xpath->query('.//w:t', $dayCell) as $textNode) {
                            $textNode->parentNode->removeChild($textNode);
                        }
                    }
                }
            }

            foreach (array_slice($groups, 0, -1) as $group) {
                $separator = $rows[0]->cloneNode(true);
                foreach ($xpath->query('.//w:t', $separator) as $textNode) {
                    $textNode->parentNode->removeChild($textNode);
                }
                $separatorHeight = $xpath->query('./w:trPr/w:trHeight', $separator)->item(0);
                if ($separatorHeight) {
                    $separatorHeight->setAttributeNS($wordNamespace, 'w:val', '293');
                }

                $table->insertBefore($separator, $dataRows[$group['end'] + 1]);
            }

            $updatedXml = $document->saveXML();
            if ($updatedXml === false || ! $archive->addFromString('word/document.xml', $updatedXml)) {
                throw new \RuntimeException('Perubahan format tabel rundown tidak dapat disimpan.');
            }
        } finally {
            $archive->close();
        }
    }

    private function defaultRundownTitle(string $trainingName): string
    {
        if (preg_match('/\(([^)]+)\)/', $trainingName, $acronym)) {
            return mb_strtoupper($acronym[1]).(str_contains(mb_strtolower($trainingName), 'bnsp') ? ' BNSP' : '');
        }

        return $trainingName;
    }

    private function addProposalDocxConditions(
        Section $section,
        Letter $letter,
    ): void {
        $section->addText('Syarat dan Kondisi:', ['bold' => true, 'size' => 11]);
        foreach ($this->proposalConditions() as $condition) {
            $section->addListItem($condition, 0, ['size' => 10]);
        }
        $section->addTextBreak(1);
        $section->addText('Demikianlah Surat Penawaran ini kami buat, atas perhatian dan kerjasamanya, kami ucapkan Terimakasih.', ['size' => 10]);
        $section->addTextBreak(2);
        $section->addText('Hormat kami,', ['size' => 10], ['alignment' => Jc::END]);
        $section->addTextBreak(2);
        $section->addText($letter->signer_name ?: 'Fitriyah, S.Si., M.Si.', ['bold' => true, 'underline' => 'single', 'size' => 10], ['alignment' => Jc::END]);
        $section->addText($letter->signer_title ?: 'Manager Operasional', ['size' => 9], ['alignment' => Jc::END]);
    }

    private function addProposalDocxCompetencies(
        Section $section,
        Letter $letter,
        array $schemes,
    ): void {
        $section->addText('DAFTAR SKEMA LINGKUNGAN SERTIFIKASI BNSP', ['bold' => true, 'size' => 12], ['alignment' => Jc::CENTER]);
        $section->addText('PT VERITRUST GLOBAL SOLUSINDO - '.$this->letterYear($letter), ['bold' => true, 'size' => 10], ['alignment' => Jc::CENTER]);
        $section->addTextBreak(1);

        foreach ($this->selectedProposalSchemes($letter, $schemes) as $schemeKey) {
            $scheme = config('proposal_schemes.'.$schemeKey);
            $section->addText($scheme['appendix_title'], ['bold' => true, 'size' => 9]);
            $table = $section->addTable([
                'borderSize' => 5,
                'borderColor' => '555555',
                'cellMargin' => 45,
                'width' => 10000,
                'unit' => 'pct',
            ]);
            $table->addRow();
            $table->addCell(700, ['bgColor' => 'D8D8D8'])->addText('No', ['bold' => true, 'size' => 8]);
            $table->addCell(9300, ['bgColor' => 'D8D8D8'])->addText('Judul Unit Kompetensi', ['bold' => true, 'size' => 8]);
            foreach ($scheme['competencies'] as $index => $competency) {
                $table->addRow();
                $table->addCell(700)->addText((string) ($index + 1).'.', ['size' => 8]);
                $table->addCell(9300)->addText($competency, ['size' => 8]);
            }
            $section->addTextBreak(1);
        }
    }

    private function addProposalDocxCompetencyCharts(
        Section $section,
        Letter $letter,
    ): void {
        $section->addText('UNIT KOMPETENSI SKEMA LIMBAH B3', ['bold' => true, 'size' => 11], ['alignment' => Jc::CENTER]);
        foreach ($this->selectedProposalSchemes($letter, ['oplb3', 'mplb3']) as $schemeKey) {
            $scheme = config('proposal_schemes.'.$schemeKey);
            $section->addText($scheme['appendix_title'], ['bold' => true, 'size' => 9]);
            $section->addImage(public_path($scheme['chart']), ['width' => 510]);
            $section->addTextBreak(1);
        }
    }

    private function addProposalDocxRequirements(Section $section): void
    {
        $section->addText('Lampiran Skema Lingkungan BNSP', ['bold' => true, 'size' => 11]);
        $this->addDocxListTable($section, 'Dokumen Persyaratan', [
            'KTP',
            'Pas Foto Background Merah',
            'Ijazah',
            'CV',
            'Surat aktif kerja (jika utusan Perusahaan)',
            'Jobdesk',
            'Laporan Kerja',
            'Registrasi akun SIAP KERJA',
        ]);
        $this->addDocxListTable($section, 'Fasilitas', [
            'Sertifikat SKKNI (sesuai Skema)',
            'Sertifikat Digital/Softcopy Kompetensi BNSP',
            'Sertifikat Penunjang Internal Veritrust',
            'Training Record',
            'Modul Materi (Softfile)',
            'Eco Tumbler Eksklusif Veritrust',
            'Souvenir',
            'T-Shirt',
            'Akses Grup Alumni',
        ]);
    }

    private function addDocxListTable(
        Section $section,
        string $heading,
        array $items,
    ): void {
        $table = $section->addTable([
            'borderSize' => 5,
            'borderColor' => '555555',
            'cellMargin' => 55,
            'width' => 10000,
            'unit' => 'pct',
        ]);
        $table->addRow();
        $table->addCell(700, ['bgColor' => 'D8D8D8'])->addText('No', ['bold' => true, 'size' => 8]);
        $table->addCell(9300, ['bgColor' => 'D8D8D8'])->addText($heading, ['bold' => true, 'size' => 8]);
        foreach ($items as $index => $item) {
            $table->addRow();
            $table->addCell(700)->addText((string) ($index + 1), ['size' => 8]);
            $table->addCell(9300)->addText($item, ['size' => 8]);
        }
        $section->addTextBreak(1);
    }

    private function selectedProposalSchemes(Letter $letter, ?array $only = null): array
    {
        $selected = array_unique(array_column($letter->offer_items ?? [], 'scheme'));
        $schemes = config('proposal_schemes');
        $selected = array_values(array_filter($selected, fn ($scheme) => isset($schemes[$scheme])));

        return $only ? array_values(array_intersect($only, $selected)) : $selected;
    }

    private function proposalPdfViewData(Letter $letter): array
    {
        return [
            'letter' => $letter,
            'proposalSchemes' => config('proposal_schemes'),
            'textSchemes' => $this->selectedProposalSchemes($letter, ['pppa', 'popal']),
            'chartSchemes' => $this->selectedProposalSchemes($letter, ['oplb3', 'mplb3']),
        ];
    }

    private function proposalPackageName(array $item): string
    {
        $scheme = config('proposal_schemes.'.($item['scheme'] ?? ''));

        return $item['title'] ?? $scheme['package'] ?? '';
    }

    private function normalizeProposalItems(array $items): array
    {
        $schemes = config('proposal_schemes');

        return array_map(function (array $item) use ($schemes) {
            $title = $item['title'] ?? '';
            $schemeKey = $item['scheme'] ?? null;

            if (! $schemeKey && $title !== '') {
                foreach ($schemes as $key => $scheme) {
                    if (str_contains(mb_strtolower($title), mb_strtolower($key))
                        || str_contains(mb_strtolower($title), mb_strtolower($scheme['name']))) {
                        $schemeKey = $key;
                        break;
                    }
                }
            }

            if ($schemeKey && isset($schemes[$schemeKey])) {
                $item['scheme'] = $schemeKey;
                $item['title'] = $title ?: $schemes[$schemeKey]['package'];
            } elseif ($title !== '') {
                $item['scheme'] = 'custom';
            }

            return $item;
        }, $items);
    }

    private function proposalConditions(): array
    {
        return [
            'Harga belum termasuk PPn.',
            'Pembayaran dilakukan 50% saat SPK/PO dikeluarkan oleh Customer.',
            'Sisa pembayaran dilakukan sebelum Uji Kompetensi dilakukan.',
            'Pembayaran dilakukan ke Nomor Rek. Bank Mandiri - 163-00-0332556-3 dan BCA - 5421-1822-22 atas nama PT VERITRUST GLOBAL SOLUSINDO.',
        ];
    }

    private function letterYear(Letter $letter): string
    {
        return Carbon::parse($letter->date)->format('Y');
    }

    private function resolveTemplate(Letter $letter): ?LetterTemplate
    {
        if ($letter->template) {
            return $letter->template;
        }

        if ($letter->letter_type) {
            $typedDefault = LetterTemplate::query()
                ->where('letter_type', $letter->letter_type)
                ->where('is_default', true)
                ->first();

            if ($typedDefault) {
                return $typedDefault;
            }
        }

        return LetterTemplate::query()
            ->whereNull('letter_type')
            ->where('is_default', true)
            ->where(function ($query) use ($letter) {
                $query->where('category_id', $letter->category_id)
                    ->orWhereNull('category_id');
            })
            ->orderByRaw('category_id IS NULL')
            ->first();
    }

    private function validateTemplateType(?int $templateId, ?string $letterType): void
    {
        if (! $templateId) {
            return;
        }

        $template = LetterTemplate::findOrFail($templateId);
        if ($template->letter_type && $template->letter_type !== $letterType) {
            throw ValidationException::withMessages([
                'template_id' => 'Template yang dipilih tidak sesuai dengan jenis surat.',
            ]);
        }
    }

    private function letterTemplateData(Letter $letter): array
    {
        return [
            'subject' => $letter->subject,
            'letter_type' => $letter->letter_type_label,
            'date' => Carbon::parse($letter->date)->locale('id')->translatedFormat('d F Y'),
            'recipient_name' => $letter->recipient_name,
            'recipient_title' => $letter->recipient_title,
            'recipient_company' => $letter->recipient_company,
            'recipient_address' => $letter->recipient_address,
            'body' => $letter->body,
            'signer_name' => $letter->signer_name,
            'signer_title' => $letter->signer_title,
            'full_number' => $letter->full_number,
        ];
    }

    private function exportGenericDocx(Letter $letter, ?LetterTemplate $template)
    {
        $word = new PhpWord;
        $word->setDefaultFontName('Times New Roman');
        $word->setDefaultFontSize(12);
        $section = $word->addSection([
            'paperSize' => 'A4',
            'marginTop' => 1200,
            'marginBottom' => 1200,
            'marginLeft' => 1400,
            'marginRight' => 1400,
        ]);
        $section->addText('PT. VERITRUST GLOBAL SOLUSINDO', ['bold' => true, 'size' => 14]);
        $section->addText($letter->letter_type_label, ['bold' => true, 'size' => 12]);
        $section->addTextBreak(1);
        $section->addText('Nomor: '.$letter->full_number);
        $section->addText('Tanggal: '.Carbon::parse($letter->date)->locale('id')->translatedFormat('d F Y'));
        $section->addText('Perihal: '.$letter->subject);
        $section->addTextBreak(1);
        $section->addText('Kepada Yth.');
        $section->addText($letter->recipient_name ?: '');
        $section->addText($letter->recipient_title ?: '');
        $section->addText($letter->recipient_company ?: '');
        $section->addText($letter->recipient_address ?: '');
        $section->addTextBreak(1);

        $body = $template
            ? TemplateRenderer::render($template->content, $letter)
            : ($letter->body ?? '');
        $body = html_entity_decode(strip_tags(str_replace(['<br>', '<br/>', '<br />', '</p>'], "\n", $body)));
        foreach (preg_split('/\r\n|\r|\n/', $body) as $paragraph) {
            $section->addText($paragraph, [], ['alignment' => Jc::BOTH]);
        }

        $section->addTextBreak(2);
        $section->addText('Hormat kami,');
        $section->addTextBreak(2);
        $section->addText($letter->signer_name ?: '', ['bold' => true, 'underline' => 'single']);
        $section->addText($letter->signer_title ?: '');

        return response()->streamDownload(function () use ($word) {
            IOFactory::createWriter($word, 'Word2007')->save('php://output');
        }, 'surat-'.$letter->id.'.docx', [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        ]);
    }

    public function destroy(Letter $letter)
    {
        $letter->delete();

        return redirect()->route('letters.index')->with('success', 'Surat berhasil dihapus.');
    }
}
