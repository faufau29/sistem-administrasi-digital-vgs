<?php

namespace App\Http\Controllers;

use App\Models\DocumentNumberHistory;
use App\Models\DocumentSequence;
use App\Models\Receipt;
use App\Services\DocxTemplateRenderer;
use App\Services\ExportService;
use App\Services\SequenceGenerator;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class ReceiptController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $receipts = $this->filteredReceipts($request)
            ->orderByDesc('number')
            ->orderByDesc('id')
            ->paginate(10)
            ->withQueryString();

        return view('receipts.index', compact('receipts'));
    }

    public function export(Request $request)
    {
        $receipts = $this->filteredReceipts($request)
            ->orderByDesc('number')
            ->orderByDesc('id')
            ->get();

        $format = $request->input('format', 'csv');
        if ($format === 'xlsx') {
            return ExportService::exportReceiptsXlsx($receipts);
        }

        return ExportService::exportReceiptsCsv($receipts);
    }

    private function filteredReceipts(Request $request): Builder
    {
        $filters = $request->validate([
            'search' => ['nullable', 'string', 'max:255'],
            'month' => ['nullable', 'integer', 'between:1,12'],
            'year' => ['nullable', 'integer', 'digits:4', 'between:1900,9999'],
        ]);

        $query = Receipt::query();

        if (! empty($filters['search'])) {
            $search = $filters['search'];
            $query->where(function (Builder $query) use ($search) {
                $query->where('full_number', 'like', "%{$search}%")
                    ->orWhere('payer', 'like', "%{$search}%")
                    ->orWhere('purpose', 'like', "%{$search}%")
                    ->orWhere('status', 'like', "%{$search}%");
            });
        }

        $this->applyDateFilters($query, $filters);

        return $query;
    }

    private function applyDateFilters(Builder $query, array $filters): void
    {
        $year = $filters['year'] ?? null;
        $month = $filters['month'] ?? null;

        if ($year !== null && $month !== null) {
            $start = Carbon::createFromDate((int) $year, (int) $month, 1)->startOfMonth();
            $query->whereBetween('date', [$start->toDateString(), $start->copy()->endOfMonth()->toDateString()]);
        } elseif ($year !== null) {
            $start = Carbon::createFromDate((int) $year, 1, 1)->startOfYear();
            $query->whereBetween('date', [$start->toDateString(), $start->copy()->endOfYear()->toDateString()]);
        } elseif ($month !== null) {
            $query->whereMonth('date', (int) $month);
        }
    }

    public function create()
    {
        return view('receipts.create', [
            'savedPurposes' => $this->savedPurposes(),
            'nextNumber' => SequenceGenerator::preview('receipt', null, [
                'padding' => 1,
                'format' => 'KWT/POPAL BNSP -Veritrust {number_plain}/{year}',
            ])['full_number'],
        ]);
    }

    public function store(Request $request)
    {
        $data = $this->validatedReceiptData($request);

        $data['created_by'] = Auth::id();
        $data['status'] = $data['status'] ?? 'paid';
        $requestedFullNumber = $data['full_number'] ?? null;

        $result = null;
        DB::transaction(function () use (&$result, $data, $requestedFullNumber) {
            if ($requestedFullNumber !== null) {
                $number = $this->numberFromFullNumber($requestedFullNumber);
                $this->recordRequestedNumber($number, $requestedFullNumber, $data['created_by']);
            } else {
                $seq = SequenceGenerator::next('receipt', null, [
                    'created_by' => $data['created_by'],
                    'padding' => 1,
                    'format' => 'KWT/POPAL BNSP -Veritrust {number_plain}/{year}',
                ]);
                $number = $seq['number'];
                $requestedFullNumber = $seq['full_number'];
            }

            $result = Receipt::create(array_merge($data, [
                'number' => $number,
                'full_number' => $requestedFullNumber,
            ]));
        });

        return redirect()->route('receipts.show', $result)->with('success', 'Kwitansi berhasil dibuat.');
    }

    public function show(Receipt $receipt)
    {
        return view('receipts.show', compact('receipt'));
    }

    public function pdf(Receipt $receipt)
    {
        return Pdf::loadView('receipts.pdf', compact('receipt'))
            ->setPaper('a4', 'landscape')
            ->stream($this->pdfFilename($receipt));
    }

    public function word(Receipt $receipt, DocxTemplateRenderer $renderer)
    {
        $path = $renderer->render('veritrust_receipt_template.docx', [
            'no_kwitansi' => $receipt->full_number,
            'date' => Carbon::parse($receipt->date)->locale('id')->translatedFormat('d F Y'),
            'received_from' => $receipt->payer,
            'amount' => 'Rp. '.number_format((float) $receipt->amount, 2, ',', '.'),
            'for' => $receipt->purpose,
            'remaining' => 'Rp. '.number_format((float) $receipt->remaining_amount, 0, ',', '.'),
            'signer' => 'Fitriyah, S.Si., M.Si',
            'payment_method' => ucfirst($receipt->payment_method),
        ]);

        return response()->download($path, 'kwitansi-'.$receipt->id.'.docx')->deleteFileAfterSend(true);
    }

    public function edit(Receipt $receipt)
    {
        return view('receipts.edit', [
            'receipt' => $receipt,
            'savedPurposes' => $this->savedPurposes($receipt),
        ]);
    }

    public function update(Request $request, Receipt $receipt)
    {
        $data = $this->validatedReceiptData($request, $receipt);

        DB::transaction(function () use ($receipt, $data) {
            if ($data['number'] !== null && (int) $data['number'] !== (int) $receipt->number) {
                $this->recordRequestedNumber(
                    (int) $data['number'],
                    $data['full_number'],
                    Auth::id(),
                );
            }

            $receipt->update($data);
        });

        return redirect()->route('receipts.show', $receipt)->with('success', 'Kwitansi berhasil diperbarui.');
    }

    public function destroy(Receipt $receipt)
    {
        $receipt->delete();

        return redirect()->route('receipts.index')->with('success', 'Receipt deleted');
    }

    private function validatedReceiptData(Request $request, ?Receipt $receipt = null): array
    {
        $fullNumber = trim((string) $request->input('full_number', ''));

        $request->merge([
            'number' => $fullNumber !== '' ? $this->numberFromFullNumber($fullNumber) : null,
        ]);

        $data = $request->validate([
            'date' => ['required', 'date'],
            'payer' => ['required', 'string', 'max:255'],
            'number' => [
                'nullable',
                'integer',
                Rule::unique('receipts', 'number')->ignore($receipt?->getKey()),
            ],
            'full_number' => $receipt
                ? ['required', 'string', 'max:255', 'regex:/\d+\/\d{4}$/', Rule::unique('receipts', 'full_number')->ignore($receipt->getKey())]
                : ['nullable', 'string', 'max:255', 'regex:/\d+\/\d{4}$/', Rule::unique('receipts', 'full_number')],
            'amount' => ['required', 'numeric', 'min:0', 'max:9999999999999'],
            'purpose' => ['required', 'string', 'max:2000'],
            'remaining_amount' => ['required', 'numeric', 'min:0', 'max:9999999999999'],
            'payment_method' => ['required', 'in:cash,transfer'],
            'status' => ['required', 'in:paid,unpaid'],
        ], [
            'payer.required' => 'Nama pihak yang membayar wajib diisi.',
            'purpose.required' => 'Keperluan pembayaran wajib diisi.',
            'payment_method.in' => 'Cara pembayaran harus tunai atau transfer.',
            'status.in' => 'Status kwitansi tidak valid.',
            'full_number.unique' => 'Nomor kwitansi sudah digunakan.',
            'full_number.regex' => 'Nomor kwitansi harus diakhiri dengan nomor/tahun, contoh: KWT/POPAL BNSP -Veritrust 454/2026.',
            'number.required' => 'Nomor kwitansi harus memuat nomor yang valid sebelum tahun.',
            'number.unique' => 'Nomor kwitansi sudah digunakan.',
        ]);

        if ($data['status'] === 'paid' && (float) $data['remaining_amount'] > 0) {
            throw ValidationException::withMessages([
                'remaining_amount' => 'Sisa pembayaran harus Rp0 jika status kwitansi lunas.',
            ]);
        }

        return $data;
    }

    private function savedPurposes(?Receipt $receipt = null): array
    {
        $purposes = Receipt::query()
            ->select('purpose')
            ->selectRaw('MAX(id) as latest_receipt_id')
            ->whereNotNull('purpose')
            ->where('purpose', '<>', '')
            ->groupBy('purpose')
            ->orderByDesc('latest_receipt_id')
            ->limit(100)
            ->pluck('purpose')
            ->all();

        if ($receipt?->purpose && ! in_array($receipt->purpose, $purposes, true)) {
            array_unshift($purposes, $receipt->purpose);
        }

        return $purposes;
    }

    private function numberFromFullNumber(string $fullNumber): ?int
    {
        if (preg_match('/(\d+)\/\d{4}$/', $fullNumber, $matches)) {
            return (int) $matches[1];
        }

        return null;
    }

    private function pdfFilename(Receipt $receipt): string
    {
        $training = preg_replace(
            '/^Pelunasan\s+Training\s+dan\s+Sertifikasi\s*/iu',
            '',
            trim((string) $receipt->purpose),
        );
        $training = is_string($training) && $training !== '' ? $training : trim((string) $receipt->purpose);
        $name = sprintf(
            '%d. KWITANSI %s %s',
            $receipt->number ?? $receipt->id,
            $training,
            trim((string) $receipt->payer),
        );
        $name = preg_replace('/[<>:"\/\\\\|?*\x00-\x1F]+/u', ' ', $name);
        $name = preg_replace('/\s+/u', ' ', (string) $name);
        $name = trim((string) $name, " .\t\n\r\0\x0B");

        return $name.'.pdf';
    }

    private function recordRequestedNumber(?int $number, string $fullNumber, ?int $createdBy): void
    {
        if ($number === null) {
            return;
        }

        $sequence = DocumentSequence::query()
            ->where('document_type', 'receipt')
            ->whereNull('category_id')
            ->lockForUpdate()
            ->first();

        if (! $sequence) {
            $sequence = DocumentSequence::create([
                'document_type' => 'receipt',
                'category_id' => null,
                'last_number' => 0,
                'padding' => 1,
                'format' => 'KWT/POPAL BNSP -Veritrust {number_plain}/{year}',
            ]);
        }

        $sequence->last_number = max($sequence->last_number, $number);
        $sequence->save();

        DocumentNumberHistory::create([
            'document_type' => 'receipt',
            'category_id' => null,
            'number' => $number,
            'full_number' => $fullNumber,
            'created_by' => $createdBy,
            'status' => 'requested',
            'notes' => 'Nomor kwitansi dimasukkan atau diubah.',
        ]);
    }
}
