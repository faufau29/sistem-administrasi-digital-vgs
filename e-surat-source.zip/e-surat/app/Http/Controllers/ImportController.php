<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\DocumentCategory;
use App\Models\DocumentSequence;
use App\Models\DocumentNumberHistory;

class ImportController extends Controller
{
    public function index()
    {
        return view('imports.index');
    }

    public function upload(Request $request)
    {
        $request->validate([
            'file' => 'required|file',
        ]);

        $path = $request->file('file')->getRealPath();
        $ext = strtolower($request->file('file')->getClientOriginalExtension());

        $rows = [];

        // Try PhpSpreadsheet if available
        if (class_exists('\PhpOffice\PhpSpreadsheet\IOFactory')) {
            $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile($path);
            $spreadsheet = $reader->load($path);
            $sheet = $spreadsheet->getActiveSheet();
            $rows = $sheet->toArray();
        } else {
            // fallback CSV
            if ($ext === 'csv' || $ext === 'txt') {
                if (($handle = fopen($path, 'r')) !== false) {
                    while (($data = fgetcsv($handle, 0, ',')) !== false) {
                        $rows[] = $data;
                    }
                    fclose($handle);
                }
            } else {
                return back()->withErrors(['file' => 'PhpSpreadsheet not installed and file is not CSV']);
            }
        }

        // Expect header in first row: document_type, category_code, number, full_number, date, notes
        if (count($rows) < 1) {
            return back()->withErrors(['file' => 'File is empty or unreadable']);
        }

        $header = array_map('strtolower', array_map('trim', $rows[0]));
        $mapped = [];
        for ($i = 1; $i < count($rows); $i++) {
            $r = $rows[$i];
            if (count($r) !== count($header)) {
                // skip malformed row
                continue;
            }
            $row = array_combine($header, $r);
            $mapped[] = $row;
        }

        DB::transaction(function () use ($mapped, $request) {
            foreach ($mapped as $row) {
                $docType = trim($row['document_type'] ?? 'letter');
                $categoryCode = trim($row['category_code'] ?? ($row['category'] ?? ''));
                $fullNumber = trim($row['full_number'] ?? ($row['number'] ?? ''));
                $date = $row['date'] ?? null;
                $notes = $row['notes'] ?? null;

                // Extract numeric part from number or full_number
                $num = null;
                if (!empty($row['number'])) {
                    // numeric expected
                    if (is_numeric($row['number'])) $num = (int)$row['number'];
                    else {
                        preg_match('/(\d+)/', $row['number'], $m);
                        if (isset($m[1])) $num = (int)$m[1];
                    }
                } else {
                    preg_match('/(\d+)/', $fullNumber, $m);
                    if (isset($m[1])) $num = (int)$m[1];
                }

                // Find category by code or name
                $category = null;
                if ($categoryCode) {
                    $category = DocumentCategory::where('code', $categoryCode)->orWhere('name', $categoryCode)->first();
                }

                // Update or create sequence
                $sequence = DocumentSequence::firstOrCreate([
                    'document_type' => $docType,
                    'category_id' => $category->id ?? null,
                ], [
                    'last_number' => 0,
                    'padding' => 3,
                ]);

                if ($num !== null && $num > $sequence->last_number) {
                    $sequence->last_number = $num;
                    $sequence->save();
                }

                // Store history
                if ($num !== null) {
                    DocumentNumberHistory::create([
                        'document_type' => $docType,
                        'category_id' => $category->id ?? null,
                        'number' => $num,
                        'full_number' => $fullNumber,
                        'created_by' => $request->user()->id ?? null,
                        'status' => 'imported',
                        'notes' => $notes,
                        'created_at' => $date ?? now(),
                    ]);
                }
            }
        });

        return redirect()->route('imports.index')->with('success','Import completed');
    }
}
