<?php

namespace App\Services;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ExportService
{
    public static function exportLettersCsv($letters)
    {
        $filename = 'letters_export_'.date('Ymd_His').'.csv';
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"$filename\"",
        ];

        $callback = function () use ($letters) {
            $out = fopen('php://output', 'w');
            fputcsv($out, ['id', 'full_number', 'date', 'letter_type', 'subject', 'recipient_company', 'status', 'created_by', 'created_at']);
            foreach ($letters as $l) {
                fputcsv($out, [
                    $l->id,
                    $l->full_number,
                    $l->date,
                    $l->letter_type_label,
                    $l->subject,
                    $l->recipient_company,
                    $l->status,
                    $l->created_by,
                    $l->created_at,
                ]);
            }
            fclose($out);
        };

        return response()->stream($callback, 200, $headers);
    }

    public static function exportLettersXlsx($letters)
    {
        if (! class_exists(Spreadsheet::class)) {
            abort(500, 'PhpSpreadsheet not installed. Run: composer require phpoffice/phpspreadsheet');
        }

        $spreadsheet = new Spreadsheet;
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->fromArray(['id', 'full_number', 'date', 'letter_type', 'subject', 'recipient_company', 'status', 'created_by', 'created_at'], null, 'A1');

        $row = 2;
        foreach ($letters as $l) {
            $sheet->fromArray([
                $l->id,
                $l->full_number,
                $l->date,
                $l->letter_type_label,
                $l->subject,
                $l->recipient_company,
                $l->status,
                $l->created_by,
                $l->created_at,
            ], null, 'A'.$row);
            $row++;
        }

        $writer = new Xlsx($spreadsheet);
        $filename = 'letters_export_'.date('Ymd_His').'.xlsx';

        return response()->stream(function () use ($writer) {
            $writer->save('php://output');
        }, 200, [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'Content-Disposition' => "attachment; filename=\"{$filename}\"",
        ]);
    }

    public static function exportInvoicesCsv($invoices)
    {
        $filename = 'invoices_export_'.date('Ymd_His').'.csv';
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"{$filename}\"",
        ];

        $callback = function () use ($invoices) {
            $out = fopen('php://output', 'w');
            fputcsv($out, [
                'id', 'full_number', 'date', 'recipient', 'amount', 'status', 'created_by', 'created_at',
                'description', 'quantity', 'unit_price', 'down_payment', 'remaining_amount', 'requires_stamp',
                'client_type', 'tax_amount', 'gross_amount', 'line_items',
            ]);
            foreach ($invoices as $invoice) {
                fputcsv($out, [
                    $invoice->id,
                    $invoice->full_number,
                    $invoice->date,
                    $invoice->recipient,
                    $invoice->amount,
                    $invoice->status,
                    $invoice->created_by,
                    $invoice->created_at,
                    $invoice->description,
                    $invoice->quantity,
                    $invoice->unit_price,
                    $invoice->down_payment,
                    $invoice->remainingAmount(),
                    $invoice->requiresStamp() ? 'yes' : 'no',
                    $invoice->client_type,
                    $invoice->taxAmount(),
                    $invoice->totalWithTax(),
                    $invoice->lineItems()->map(fn ($item) => $item->description.' ('.$item->quantity.' x '.$item->unit_price.')')->implode('; '),
                ]);
            }
            fclose($out);
        };

        return response()->stream($callback, 200, $headers);
    }

    public static function exportInvoicesXlsx($invoices)
    {
        if (! class_exists(Spreadsheet::class)) {
            abort(500, 'PhpSpreadsheet not installed. Run: composer require phpoffice/phpspreadsheet');
        }

        $spreadsheet = new Spreadsheet;
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->fromArray([
            'id', 'full_number', 'date', 'recipient', 'amount', 'status', 'created_by', 'created_at',
            'description', 'quantity', 'unit_price', 'down_payment', 'remaining_amount', 'requires_stamp',
            'client_type', 'tax_amount', 'gross_amount', 'line_items',
        ], null, 'A1');

        $row = 2;
        foreach ($invoices as $invoice) {
            $sheet->fromArray([
                $invoice->id,
                $invoice->full_number,
                $invoice->date,
                $invoice->recipient,
                $invoice->amount,
                $invoice->status,
                $invoice->created_by,
                $invoice->created_at,
                $invoice->description,
                $invoice->quantity,
                $invoice->unit_price,
                $invoice->down_payment,
                $invoice->remainingAmount(),
                $invoice->requiresStamp() ? 'yes' : 'no',
                $invoice->client_type,
                $invoice->taxAmount(),
                $invoice->totalWithTax(),
                $invoice->lineItems()->map(fn ($item) => $item->description.' ('.$item->quantity.' x '.$item->unit_price.')')->implode('; '),
            ], null, 'A'.$row);
            $row++;
        }

        $writer = new Xlsx($spreadsheet);
        $filename = 'invoices_export_'.date('Ymd_His').'.xlsx';

        return response()->stream(function () use ($writer) {
            $writer->save('php://output');
        }, 200, [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'Content-Disposition' => "attachment; filename=\"{$filename}\"",
        ]);
    }

    public static function exportReceiptsCsv($receipts)
    {
        $filename = 'receipts_export_'.date('Ymd_His').'.csv';
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"{$filename}\"",
        ];

        $callback = function () use ($receipts) {
            $out = fopen('php://output', 'w');
            fputcsv($out, ['id', 'full_number', 'date', 'payer', 'amount', 'status', 'created_by', 'created_at']);
            foreach ($receipts as $receipt) {
                fputcsv($out, [
                    $receipt->id,
                    $receipt->full_number,
                    $receipt->date,
                    $receipt->payer,
                    $receipt->amount,
                    $receipt->status,
                    $receipt->created_by,
                    $receipt->created_at,
                ]);
            }
            fclose($out);
        };

        return response()->stream($callback, 200, $headers);
    }

    public static function exportReceiptsXlsx($receipts)
    {
        if (! class_exists(Spreadsheet::class)) {
            abort(500, 'PhpSpreadsheet not installed. Run: composer require phpoffice/phpspreadsheet');
        }

        $spreadsheet = new Spreadsheet;
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->fromArray(['id', 'full_number', 'date', 'payer', 'amount', 'status', 'created_by', 'created_at'], null, 'A1');

        $row = 2;
        foreach ($receipts as $receipt) {
            $sheet->fromArray([
                $receipt->id,
                $receipt->full_number,
                $receipt->date,
                $receipt->payer,
                $receipt->amount,
                $receipt->status,
                $receipt->created_by,
                $receipt->created_at,
            ], null, 'A'.$row);
            $row++;
        }

        $writer = new Xlsx($spreadsheet);
        $filename = 'receipts_export_'.date('Ymd_His').'.xlsx';

        return response()->stream(function () use ($writer) {
            $writer->save('php://output');
        }, 200, [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'Content-Disposition' => "attachment; filename=\"{$filename}\"",
        ]);
    }
}
