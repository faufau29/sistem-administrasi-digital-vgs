<?php

namespace App\Services;

use App\Models\DocumentSequence;
use App\Models\DocumentCategory;
use App\Models\DocumentNumberHistory;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class SequenceGenerator
{
    public static function preview(string $documentType, ?int $categoryId = null, ?array $opts = []): array
    {
        $sequence = DocumentSequence::query()
            ->where('document_type', $documentType)
            ->where('category_id', $categoryId)
            ->first();

        if (! $sequence) {
            $sequence = new DocumentSequence([
                'padding' => $opts['padding'] ?? 3,
                'format' => $opts['format'] ?? null,
                'prefix' => $opts['prefix'] ?? null,
            ]);
        }

        $number = $documentType === 'receipt'
            ? self::nextAvailableReceiptNumber()
            : max((int) $sequence->last_number, self::latestStoredNumber($documentType)) + 1;
        $category = $categoryId ? DocumentCategory::find($categoryId) : null;

        return [
            'number' => $number,
            'full_number' => self::formatFullNumber($sequence, $number, $category, $opts),
        ];
    }

    /**
     * Generate next number for given document type and category.
     * Returns array with keys: number, full_number
     */
    public static function next(string $documentType, ?int $categoryId = null, ?array $opts = []): array
    {
        return DB::transaction(function () use ($documentType, $categoryId, $opts) {
            $query = DocumentSequence::where('document_type', $documentType)->where('category_id', $categoryId);

            // lock row for update (create if not exists)
            $sequence = $query->lockForUpdate()->first();

            if (! $sequence) {
                $sequence = DocumentSequence::create([
                    'document_type' => $documentType,
                    'category_id' => $categoryId,
                    'last_number' => self::latestStoredNumber($documentType),
                    'padding' => $opts['padding'] ?? 3,
                    'format' => $opts['format'] ?? null,
                    'prefix' => $opts['prefix'] ?? null,
                ]);
            }

            if ($documentType === 'receipt') {
                $next = self::nextAvailableReceiptNumber();
            } else {
                $next = max((int) $sequence->last_number, self::latestStoredNumber($documentType)) + 1;
            }

            $sequence->last_number = $next;
            $sequence->save();

            $category = $categoryId ? DocumentCategory::find($categoryId) : null;

            $full = self::formatFullNumber($sequence, $next, $category, $opts);

            DocumentNumberHistory::create([
                'document_type' => $documentType,
                'category_id' => $categoryId,
                'number' => $next,
                'full_number' => $full,
                'created_by' => $opts['created_by'] ?? null,
                'status' => $opts['status'] ?? 'issued',
                'notes' => $opts['notes'] ?? null,
            ]);

            return ['number' => $next, 'full_number' => $full];
        });
    }

    private static function latestStoredNumber(string $documentType): int
    {
        $table = match ($documentType) {
            'invoice' => 'invoices',
            'receipt' => 'receipts',
            default => null,
        };

        return $table ? (int) DB::table($table)->max('number') : 0;
    }

    private static function nextAvailableReceiptNumber(): int
    {
        $number = max(0, (int) DB::table('receipts')->max('number')) + 1;
        $usedNumbers = DB::table('document_number_histories')
            ->where('document_type', 'receipt')
            ->where('number', '>=', $number)
            ->pluck('number')
            ->map(static fn ($usedNumber) => (int) $usedNumber)
            ->flip();

        while ($usedNumbers->has($number)) {
            $number++;
        }

        return $number;
    }

    protected static function formatFullNumber(DocumentSequence $sequence, int $number, ?DocumentCategory $category = null, array $opts = []): string
    {
        $format = $opts['format'] ?? $sequence->format;
        $padding = $sequence->padding ?? 3;
        $company = $opts['company'] ?? config('app.name','VERITRUST');
        $categoryCode = $category->code ?? ($opts['category_code'] ?? '');
        $now = Carbon::now();

        $replacements = [
            '{number}' => str_pad((string)$number, $padding, '0', STR_PAD_LEFT),
            '{number_plain}' => (string)$number,
            '{category}' => $categoryCode,
            '{company}' => $company,
            '{month}' => $now->format('n'),
            '{month_roman}' => self::toRoman((int)$now->format('n')),
            '{year}' => $now->format('Y'),
        ];

        if ($format) {
            $full = strtr($format, $replacements);
        } else {
            $parts = [str_pad((string)$number, $padding, '0', STR_PAD_LEFT)];
            if ($categoryCode) $parts[] = $categoryCode;
            $parts[] = $company;
            $parts[] = self::toRoman((int)$now->format('n'));
            $parts[] = $now->format('Y');
            $full = implode('/', $parts);
        }

        if ($sequence->prefix) {
            $full = trim($sequence->prefix) . ' ' . $full;
        }

        return $full;
    }

    protected static function toRoman(int $num): string
    {
        $romans = [1000 => 'M',900=>'CM',500=>'D',400=>'CD',100=>'C',90=>'XC',50=>'L',40=>'XL',10=>'X',9=>'IX',5=>'V',4=>'IV',1=>'I'];
        $result = '';
        foreach ($romans as $value => $letter) {
            while ($num >= $value) {
                $result .= $letter;
                $num -= $value;
            }
        }
        return $result;
    }
}
