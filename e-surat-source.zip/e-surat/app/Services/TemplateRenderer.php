<?php

namespace App\Services;

use App\Models\Letter;
use Carbon\Carbon;

class TemplateRenderer
{
    public static function render(string $template, Letter $letter): string
    {
        $map = [
            '{{nomor_surat}}' => $letter->full_number ?? '',
            '{{tanggal_surat}}' => $letter->date ? Carbon::parse($letter->date)->format('d-m-Y') : '',
            '{{nama_penerima}}' => $letter->recipient_name ?? '',
            '{{jabatan_penerima}}' => $letter->recipient_title ?? '',
            '{{nama_perusahaan}}' => $letter->recipient_company ?? '',
            '{{alamat_perusahaan}}' => $letter->recipient_address ?? '',
            '{{perihal}}' => $letter->subject ?? '',
            '{{jenis_surat}}' => $letter->letter_type_label,
            '{{isi_surat}}' => $letter->body ?? '',
            '{{nama_penandatangan}}' => $letter->signer_name ?? '',
            '{{jabatan_penandatangan}}' => $letter->signer_title ?? '',
        ];

        // allow both {{key}} and {key} styles
        foreach ($map as $k => $v) {
            $template = str_replace($k, $v, $template);
            $template = str_replace(str_replace(['{{','}}'], ['{','}'], $k), $v, $template);
        }

        return $template;
    }
}
