<?php

namespace App\Services;

use Illuminate\Filesystem\Filesystem;
use RuntimeException;
use Symfony\Component\Process\Process;

class LibreOfficePdfRenderer
{
    public function render(string $docxPath): string
    {
        if (! is_file($docxPath)) {
            throw new RuntimeException("Document not found: {$docxPath}");
        }

        $binary = config('services.libreoffice.binary');
        if (! is_string($binary) || $binary === '') {
            throw new RuntimeException('LibreOffice binary is not configured.');
        }

        $outputDirectory = dirname($docxPath);
        $pdfPath = $outputDirectory.DIRECTORY_SEPARATOR.pathinfo($docxPath, PATHINFO_FILENAME).'.pdf';
        $profileDirectory = storage_path('app/libreoffice-profile');
        $lock = fopen(storage_path('app/libreoffice-profile.lock'), 'c');
        if ($lock === false) {
            throw new RuntimeException('Unable to open the LibreOffice conversion lock.');
        }
        if (! flock($lock, LOCK_EX)) {
            fclose($lock);
            throw new RuntimeException('Unable to lock the LibreOffice conversion profile.');
        }

        $converted = false;
        try {
            if (! is_dir($profileDirectory) && ! mkdir($profileDirectory, 0700, true) && ! is_dir($profileDirectory)) {
                throw new RuntimeException('Unable to create the LibreOffice profile.');
            }

            $process = new Process([
                $binary,
                '--headless',
                '-env:UserInstallation='.$this->fileUri($profileDirectory),
                '--convert-to',
                'pdf:writer_pdf_Export',
                '--outdir',
                $outputDirectory,
                $docxPath,
            ]);
            $process->setTimeout(120);
            $process->run();

            if (! $process->isSuccessful()) {
                $error = trim($process->getErrorOutput());
                if ($error === '') {
                    $error = trim($process->getOutput());
                }

                throw new RuntimeException('LibreOffice PDF conversion failed.'.($error === '' ? '' : ' '.$error));
            }

            if (! is_file($pdfPath) || filesize($pdfPath) === 0) {
                throw new RuntimeException('LibreOffice did not produce a valid PDF.');
            }

            $converted = true;

            return $pdfPath;
        } finally {
            try {
                if (! $converted && is_file($pdfPath) && ! (new Filesystem)->delete($pdfPath)) {
                    throw new RuntimeException('Unable to remove an incomplete PDF export.');
                }
            } finally {
                flock($lock, LOCK_UN);
                fclose($lock);
            }
        }
    }

    private function fileUri(string $path): string
    {
        $path = str_replace('\\', '/', $path);
        if (preg_match('/^[A-Za-z]:\//', $path, $drive)) {
            $segments = explode('/', substr($path, 3));

            return 'file:///'.substr($drive[0], 0, 2).'/'.implode('/', array_map('rawurlencode', $segments));
        }

        return 'file:///'.implode('/', array_map('rawurlencode', explode('/', ltrim($path, '/'))));
    }
}
