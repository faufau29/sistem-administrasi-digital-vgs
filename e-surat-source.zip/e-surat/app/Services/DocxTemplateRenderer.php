<?php

namespace App\Services;

use PhpOffice\PhpWord\Escaper\Xml;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\Settings;
use PhpOffice\PhpWord\TemplateProcessor;

class DocxTemplateRenderer
{
    protected string $templatesPath;

    public function __construct()
    {
        $this->templatesPath = storage_path('app/public/templates');
    }

    /**
     * Render a DOCX template by replacing placeholders with provided data.
     * Placeholders in DOCX should be like ${name} as PhpWord expects.
     *
     * @return string path to generated file
     */
    public function render(string $templateFile, array $data, ?string $outputPath = null): string
    {
        $templatePath = $this->templatesPath.DIRECTORY_SEPARATOR.$templateFile;
        if (! file_exists($templatePath)) {
            throw new \RuntimeException("Template not found: {$templateFile}");
        }

        $template = new TemplateProcessor($templatePath);
        $xmlEscaper = Settings::isOutputEscapingEnabled() ? null : new Xml;

        foreach ($data as $key => $value) {
            $replacement = is_scalar($value) ? (string) $value : json_encode($value);
            if ($xmlEscaper !== null) {
                $replacement = $xmlEscaper->escape($replacement);
            }
            $template->setValue($key, $replacement);
        }

        $outputPath = $outputPath ?: storage_path('app/exports/'.uniqid('doc_', true).'.docx');
        if (! is_dir(dirname($outputPath))) {
            mkdir(dirname($outputPath), 0755, true);
        }

        $template->saveAs($outputPath);

        return $outputPath;
    }

    /**
     * Render the DOCX template with data and return HTML string.
     * This saves a temporary DOCX then loads it with PhpWord and writes HTML.
     */
    public function renderToHtml(string $templateFile, array $data): string
    {
        $docx = $this->render($templateFile, $data, storage_path('app/public/templates/temp_'.uniqid().'.docx'));
        try {
            $html = $this->renderDocumentToHtml($docx);
        } finally {
            @unlink($docx);
        }

        return $html;
    }

    public function renderDocumentToHtml(string $docxPath): string
    {
        if (! file_exists($docxPath)) {
            throw new \RuntimeException("Document not found: {$docxPath}");
        }

        $phpWord = IOFactory::load($docxPath);
        $htmlWriter = IOFactory::createWriter($phpWord, 'HTML');
        $tmpHtml = storage_path('app/public/templates/temp_'.uniqid().'.html');
        try {
            $htmlWriter->save($tmpHtml);
            $html = file_get_contents($tmpHtml);
        } finally {
            @unlink($tmpHtml);
        }

        if ($html === false) {
            throw new \RuntimeException('Unable to read rendered document HTML.');
        }

        return str_replace("font-family: 'Arial'", "font-family: 'Times New Roman'", $html);
    }
}
