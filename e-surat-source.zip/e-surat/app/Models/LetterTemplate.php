<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LetterTemplate extends Model
{
    use HasFactory;

    protected $fillable = ['category_id','letter_type','name','content','is_default','header_logo','file_name'];

    public function category()
    {
        return $this->belongsTo(DocumentCategory::class, 'category_id');
    }
}
