<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DocumentNumberHistory extends Model
{
    use HasFactory;

    protected $fillable = ['document_type','category_id','number','full_number','created_by','status','notes'];

    public function category()
    {
        return $this->belongsTo(DocumentCategory::class, 'category_id');
    }
}
