<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Invoice extends Model
{
    use HasFactory;

    protected $fillable = [
        'number',
        'full_number',
        'date',
        'recipient',
        'client_type',
        'description',
        'quantity',
        'unit_price',
        'down_payment',
        'amount',
        'status',
        'created_by',
    ];

    public function items(): HasMany
    {
        return $this->hasMany(InvoiceItem::class)->orderBy('id');
    }

    public function lineItems(): Collection
    {
        $items = $this->items;

        if ($items->isNotEmpty()) {
            $items->each(function (InvoiceItem $item): void {
                $item->description = $this->normalizeItemDescription((string) $item->description);
            });

            return $items;
        }

        return new Collection([
            new InvoiceItem([
                'description' => $this->normalizeItemDescription($this->description ?: 'Invoice'),
                'quantity' => $this->quantity ?? 1,
                'unit_price' => $this->unit_price ?? $this->amount,
                'line_total' => $this->amount,
            ]),
        ]);
    }

    private function normalizeItemDescription(string $description): string
    {
        return str_ireplace('penyediaan', 'Penyedia', $description);
    }

    public function requiresStamp(): bool
    {
        return $this->remainingAmount() >= 5000000;
    }

    public function taxAmount(): int
    {
        return $this->client_type === 'company'
            ? (int) round((float) $this->amount * 0.11)
            : 0;
    }

    public function totalWithTax(): int
    {
        return (int) $this->amount + $this->taxAmount();
    }

    public function remainingAmount(): int
    {
        return max(0, $this->totalWithTax() - (int) ($this->down_payment ?? 0));
    }

    public function paymentNote(): ?string
    {
        if ((float) ($this->down_payment ?? 0) <= 0) {
            return null;
        }

        $description = (string) $this->description;
        $deadline = stripos($description, 'BNSP') !== false ? 'asesmen' : 'ujian';

        return 'Note : Untuk Sisa Pembayaran Maksimal Saat Training berlangsung/sebelum '.$deadline.'.';
    }
}
