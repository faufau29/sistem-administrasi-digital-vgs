<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Receipt extends Model
{
    use HasFactory;

    protected $fillable = [
        'number',
        'full_number',
        'date',
        'payer',
        'amount',
        'purpose',
        'remaining_amount',
        'payment_method',
        'status',
        'created_by',
    ];

    public function requiresStamp(): bool
    {
        return (float) $this->amount >= 5000000;
    }

    public function isPaid(): bool
    {
        return in_array($this->status, ['paid', 'received'], true)
            && (float) $this->remaining_amount === 0.0;
    }

    public function paymentStatusLabel(): string
    {
        return $this->isPaid() ? 'Lunas' : 'Belum Lunas';
    }
}
