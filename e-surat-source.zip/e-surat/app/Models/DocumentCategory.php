<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DocumentCategory extends Model
{
    use HasFactory;

    protected $fillable = ['name','code','is_active'];

    public function sequences()
    {
        return $this->hasMany(DocumentSequence::class, 'category_id');
    }

    public function templates()
    {
        return $this->hasMany(LetterTemplate::class, 'category_id');
    }

    public function letters()
    {
        return $this->hasMany(Letter::class, 'category_id');
    }
}
