<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DocumentSequence extends Model
{
    use HasFactory;

    protected $fillable = ['document_type','category_id','last_number','padding','format','prefix'];

    public function category()
    {
        return $this->belongsTo(DocumentCategory::class, 'category_id');
    }
}
