<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Letter extends Model
{
    use HasFactory;

    protected $fillable = [
        'category_id','template_id','number','full_number','date','subject','letter_type','attachment_note','offer_items','recipient_name','recipient_title',
        'recipient_company','recipient_address','body','instructor_details','signer_name','signer_title','status','created_by'
    ];

    protected function casts(): array
    {
        return [
            'offer_items' => 'array',
            'instructor_details' => 'array',
        ];
    }

    public function getLetterTypeLabelAttribute(): string
    {
        if (! $this->letter_type) {
            return 'Surat Umum';
        }

        return config('letter_types.'.$this->letter_type, 'Surat Umum');
    }

    public function template()
    {
        return $this->belongsTo(LetterTemplate::class, 'template_id');
    }

    public function category()
    {
        return $this->belongsTo(DocumentCategory::class, 'category_id');
    }
}
