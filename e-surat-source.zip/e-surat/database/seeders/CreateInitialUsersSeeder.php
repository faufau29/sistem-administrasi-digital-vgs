<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class CreateInitialUsersSeeder extends Seeder
{
    public function run(): void
    {
        // Direktur - single account (set email to desired official email)
        User::updateOrCreate([
            'email' => 'direktur@veritrust.local'
        ],[
            'name' => 'Direktur',
            'password' => Hash::make('direktur123'),
            'role' => 'direktur'
        ]);

        // Admin
        User::updateOrCreate([
            'email' => 'admin@veritrust.local'
        ],[
            'name' => 'Admin',
            'password' => Hash::make('admin123'),
            'role' => 'admin'
        ]);

        // Example staff
        User::updateOrCreate([
            'email' => 'staff@veritrust.local'
        ],[
            'name' => 'Staff',
            'password' => Hash::make('staff123'),
            'role' => 'staff'
        ]);
    }
}
