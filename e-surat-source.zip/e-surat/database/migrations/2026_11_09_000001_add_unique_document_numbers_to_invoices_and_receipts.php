<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('invoices', function (Blueprint $table) {
            $table->unique('number');
        });

        Schema::table('receipts', function (Blueprint $table) {
            $table->unique('number');
            $table->unique('full_number');
        });
    }

    public function down(): void
    {
        Schema::table('invoices', function (Blueprint $table) {
            $table->dropUnique(['number']);
        });

        Schema::table('receipts', function (Blueprint $table) {
            $table->dropUnique(['number']);
            $table->dropUnique(['full_number']);
        });
    }
};
