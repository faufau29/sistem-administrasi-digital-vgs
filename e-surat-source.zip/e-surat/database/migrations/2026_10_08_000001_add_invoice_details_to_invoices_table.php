<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('invoices', function (Blueprint $table) {
            $table->string('description', 1000)->nullable();
            $table->unsignedInteger('quantity')->nullable();
            $table->decimal('unit_price', 15, 2)->nullable();
            $table->decimal('down_payment', 15, 2)->default(0);
        });
    }

    public function down(): void
    {
        Schema::table('invoices', function (Blueprint $table) {
            $table->dropColumn(['description', 'quantity', 'unit_price', 'down_payment']);
        });
    }
};
