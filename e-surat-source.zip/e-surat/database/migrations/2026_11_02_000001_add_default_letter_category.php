<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        $categoryExists = DB::table('document_categories')
            ->where('name', 'Surat')
            ->orWhere('code', 'SRT')
            ->exists();

        if ($categoryExists) {
            return;
        }

        DB::table('document_categories')->insert([
            'name' => 'Surat',
            'code' => 'SRT',
            'is_active' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function down(): void
    {
        $category = DB::table('document_categories')
            ->where('name', 'Surat')
            ->where('code', 'SRT')
            ->first();

        if (! $category) {
            return;
        }

        $isInUse = DB::table('letters')->where('category_id', $category->id)->exists()
            || DB::table('document_sequences')->where('category_id', $category->id)->exists()
            || DB::table('document_number_histories')->where('category_id', $category->id)->exists()
            || DB::table('letter_templates')->where('category_id', $category->id)->exists();

        if (! $isInUse) {
            DB::table('document_categories')->where('id', $category->id)->delete();
        }
    }
};
