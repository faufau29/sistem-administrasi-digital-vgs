<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('receipts', function (Blueprint $table) {
            $table->text('purpose')->nullable()->after('amount');
            $table->decimal('remaining_amount', 15, 2)->default(0)->after('purpose');
            $table->string('payment_method')->default('transfer')->after('remaining_amount');
        });
    }

    public function down(): void
    {
        Schema::table('receipts', function (Blueprint $table) {
            $table->dropColumn(['purpose', 'remaining_amount', 'payment_method']);
        });
    }
};
