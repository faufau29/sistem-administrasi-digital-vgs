<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('document_sequences', function (Blueprint $table) {
            $table->id();
            $table->string('document_type');
            $table->unsignedBigInteger('category_id')->nullable();
            $table->bigInteger('last_number')->default(0);
            $table->integer('padding')->default(3);
            $table->string('format')->nullable();
            $table->string('prefix')->nullable();
            $table->timestamps();

            $table->unique(['document_type','category_id']);
            $table->foreign('category_id')->references('id')->on('document_categories')->onDelete('set null');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('document_sequences');
    }
};
