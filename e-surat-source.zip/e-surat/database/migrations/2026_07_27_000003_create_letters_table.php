<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('letters', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('category_id');
            $table->bigInteger('number')->nullable();
            $table->string('full_number')->nullable();
            $table->date('date')->nullable();
            $table->string('subject')->nullable();
            $table->string('recipient_name')->nullable();
            $table->string('recipient_title')->nullable();
            $table->string('recipient_company')->nullable();
            $table->text('recipient_address')->nullable();
            $table->text('body')->nullable();
            $table->string('signer_name')->nullable();
            $table->string('signer_title')->nullable();
            $table->enum('status',['draft','pending','approved','rejected','published','archived'])->default('draft');
            $table->unsignedBigInteger('created_by')->nullable();
            $table->timestamps();

            $table->foreign('category_id')->references('id')->on('document_categories')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('letters');
    }
};
