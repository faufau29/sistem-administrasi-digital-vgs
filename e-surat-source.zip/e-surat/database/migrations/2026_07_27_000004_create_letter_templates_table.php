<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('letter_templates', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('category_id')->nullable();
            $table->string('name');
            $table->text('content');
            $table->boolean('is_default')->default(false);
            $table->string('header_logo')->nullable();
            $table->timestamps();

            $table->foreign('category_id')->references('id')->on('document_categories')->onDelete('set null');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('letter_templates');
    }
};
