<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('invoice_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('invoice_id')->constrained()->cascadeOnDelete();
            $table->string('training_code')->nullable();
            $table->string('description', 1000);
            $table->unsignedInteger('quantity')->default(1);
            $table->decimal('unit_price', 15, 2);
            $table->decimal('line_total', 15, 2);
            $table->timestamps();

            $table->index(['invoice_id', 'id']);
        });

        $now = now();
        DB::table('invoices')
            ->whereNotNull('description')
            ->where('description', '<>', '')
            ->orderBy('id')
            ->chunkById(500, function ($invoices) use ($now) {
                foreach ($invoices as $invoice) {
                    $quantity = max(1, (int) ($invoice->quantity ?? 1));
                    $unitPrice = (float) ($invoice->unit_price ?? $invoice->amount);

                    DB::table('invoice_items')->insert([
                        'invoice_id' => $invoice->id,
                        'training_code' => null,
                        'description' => $invoice->description,
                        'quantity' => $quantity,
                        'unit_price' => $unitPrice,
                        'line_total' => $invoice->amount,
                        'created_at' => $now,
                        'updated_at' => $now,
                    ]);
                }
            });
    }

    public function down(): void
    {
        Schema::dropIfExists('invoice_items');
    }
};
