<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('invoices', function (Blueprint $table) {
            $table->index('date', 'invoices_date_index');
        });

        Schema::table('receipts', function (Blueprint $table) {
            $table->index('date', 'receipts_date_index');
        });
    }

    public function down(): void
    {
        Schema::table('invoices', function (Blueprint $table) {
            $table->dropIndex('invoices_date_index');
        });

        Schema::table('receipts', function (Blueprint $table) {
            $table->dropIndex('receipts_date_index');
        });
    }
};
