<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('document_number_histories', function (Blueprint $table) {
            $table->id();
            $table->string('document_type');
            $table->unsignedBigInteger('category_id')->nullable();
            $table->bigInteger('number');
            $table->string('full_number');
            $table->unsignedBigInteger('created_by')->nullable();
            $table->string('status')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->foreign('category_id')->references('id')->on('document_categories')->onDelete('set null');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('document_number_histories');
    }
};
