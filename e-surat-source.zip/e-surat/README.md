# E-Surat

Aplikasi pengelolaan surat, invoice, kwitansi, template dokumen, dan laporan bulanan berbasis Laravel.

## Persyaratan

- PHP 8.3 atau lebih baru dengan ekstensi yang dibutuhkan Laravel
- Composer
- Node.js dan npm
- SQLite (bawaan untuk konfigurasi pengembangan)
- LibreOffice, jika fitur ekspor PDF tertentu memerlukannya

## Menjalankan secara lokal

1. Salin `.env.example` menjadi `.env`, lalu sesuaikan konfigurasi lokal.
2. Pasang dependency PHP dan JavaScript:

   ```sh
   composer install
   npm ci
   ```

3. Buat application key dan siapkan database:

   ```sh
   php artisan key:generate
   php artisan migrate
   ```

   Jika file `database/database.sqlite` belum ada, buat file kosong tersebut sebelum migrasi.

4. Bangun asset frontend dan jalankan aplikasi:

   ```sh
   npm run build
   php artisan serve
   ```

   Buka URL yang ditampilkan oleh `php artisan serve`.

## Pengembangan

Jalankan Vite dalam mode development dengan:

```sh
npm run dev
```

Jalankan pengujian dengan:

```sh
php artisan test
```

## GitHub dan hosting

ZIP ini berisi source code, bukan aplikasi yang dapat dijalankan langsung oleh GitHub Pages. Untuk memasukkan source ke GitHub, ekstrak ZIP lalu buat/push repository Git. Untuk menjalankan aplikasi secara online, gunakan server atau layanan hosting yang mendukung PHP/Laravel; arahkan document root ke folder `public` dan atur environment production, database, serta storage sesuai penyedia hosting.

Jangan unggah `.env`, database lokal, file hasil upload, atau kredensial ke repository. Gunakan `.env.example` sebagai acuan konfigurasi dan simpan rahasia production pada environment variables di layanan hosting.
