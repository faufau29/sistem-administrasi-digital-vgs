<?php
require __DIR__ . '/../vendor/autoload.php';

use App\Models\DocumentCategory;
use App\Models\Letter;
use App\Models\LetterTemplate;
use Illuminate\Contracts\Console\Kernel as ConsoleKernel;

$app = require __DIR__ . '/../bootstrap/app.php';
$app->make(ConsoleKernel::class)->bootstrap();

$category = DocumentCategory::firstOrCreate(
    ['code' => 'RECEIPT'],
    ['name' => 'Receipt', 'is_active' => true]
);

$template = LetterTemplate::firstOrCreate(
    ['name' => 'Veritrust Receipt'],
    ['category_id' => $category->id, 'content' => 'Sample receipt with placeholders', 'is_default' => true, 'file_name' => 'veritrust_receipt_template.docx']
);

$letter = Letter::create([
    'category_id' => $category->id,
    'template_id' => $template->id,
    'date' => date('Y-m-d'),
    'subject' => 'Pembayaran Lunas',
    'recipient_name' => 'Bintang Alethea Nagara',
    'recipient_title' => 'Client',
    'recipient_company' => 'Veritrust Global Solutions',
    'recipient_address' => 'Jakarta, Indonesia',
    'body' => 'Terima kasih atas pelunasan training.',
    'signer_name' => 'Abdul Darda, S.H., M.H.',
    'signer_title' => 'Finance',
    'status' => 'approved',
    'created_by' => 1,
]);

echo 'Sample letter created: id=' . $letter->id . ' subject=' . $letter->subject . PHP_EOL;
