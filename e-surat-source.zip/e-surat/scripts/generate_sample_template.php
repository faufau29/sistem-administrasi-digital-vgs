<?php
require __DIR__ . '/../vendor/autoload.php';

use PhpOffice\PhpWord\PhpWord;

$phpWord = new PhpWord();
$section = $phpWord->addSection(['marginTop' => 600, 'marginLeft' => 600, 'marginRight' => 600]);

// Header (logo placeholder)
$header = $section->addHeader();
$header->addText('Veritrust', ['size' => 24, 'bold' => true]);
$header->addText('Trusted Partner to Be Excellence', ['size' => 10]);

$section->addTextBreak(1);
$section->addText('Nomor Surat: ${full_number}', ['size' => 12]);
$section->addText('Tanggal: ${date}', ['size' => 12]);
$section->addTextBreak(1);

$section->addText('Kepada:', ['bold' => true]);
$section->addText('${recipient_name}');
$section->addText('${recipient_title}');
$section->addText('${recipient_company}');
$section->addText('${recipient_address}');
$section->addTextBreak(1);

$section->addText('Perihal: ${subject}', ['bold' => true]);
$section->addTextBreak(1);

$section->addText('${body}', ['size' => 12]);
$section->addTextBreak(2);

$section->addText('Hormat kami,');
$section->addTextBreak(3);
$section->addText('${signer_name}');
$section->addText('${signer_title}');

$dir = __DIR__ . '/../storage/app/public/templates';
if (!is_dir($dir)) mkdir($dir, 0755, true);
$path = $dir . '/sample_template.docx';
$phpWord->save($path, 'Word2007');

echo "Sample template created: $path\n";
