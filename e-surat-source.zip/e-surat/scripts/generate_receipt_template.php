<?php
require __DIR__ . '/../vendor/autoload.php';

use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\Style\Table;

$phpWord = new PhpWord();
$section = $phpWord->addSection(['marginTop' => 600, 'marginLeft' => 600, 'marginRight' => 600]);

// Header with company name and tagline
$header = $section->addHeader();
$header->addText('Veritrust', ['size' => 26, 'bold' => true, 'color' => '0A887F']);
$header->addText('Trusted Partner to Be Excellence', ['size' => 10, 'color' => '666666']);

$section->addTextBreak(1);

// Title
$section->addText('KWITANSI', ['size' => 14, 'bold' => true], ['alignment' => 'center']);
$section->addTextBreak(1);

// Two-column table for fields
$tableStyle = ['borderSize' => 0, 'cellMargin' => 80];
$phpWord->addTableStyle('fields', $tableStyle);
$table = $section->addTable('fields');

$table->addRow();
$table->addCell(7000)->addText('No Kwitansi	: ${no_kwitansi}\nTanggal	: ${date}\nTelah diterima Dari	: ${received_from}\nUang Sejumlah	: ${amount}\nUntuk Keperluan	: ${for}\n\nSisa Pembayaran	: ${remaining}');
$table->addCell(3000)->addText('Yang Menerima\n\n${signer}\n', ['size' => 11], ['alignment' => 'center']);

$section->addTextBreak(1);

// Large LUNAS box
$tbl = $section->addTable(['borderSize' => 0, 'cellMargin' => 100]);
$tbl->addRow(2000);
$cell = $tbl->addCell(10000, ['borderColor' => '7BC043', 'borderSize' => 400]);
$cell->addText('LUNAS', ['size' => 32, 'bold' => true, 'color' => '000000'], ['alignment' => 'center']);

$section->addTextBreak(1);
$section->addText('Ket. Bayar: ${payment_method}', ['size' => 10, 'color' => '444444']);

$dir = __DIR__ . '/../storage/app/public/templates';
if (!is_dir($dir)) mkdir($dir, 0755, true);
$path = $dir . '/veritrust_receipt_template.docx';
$phpWord->save($path, 'Word2007');

echo "Receipt template created: $path\n";
