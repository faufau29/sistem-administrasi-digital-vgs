<?php
require __DIR__ . '/../vendor/autoload.php';

use App\Models\DocumentCategory;
use App\Models\LetterTemplate;
use App\Models\Letter;

echo PHP_EOL . 'Categories:' . PHP_EOL;
foreach (DocumentCategory::all() as $c) {
    echo $c->id . ' ' . $c->name . PHP_EOL;
}

echo PHP_EOL . 'Templates:' . PHP_EOL;
foreach (LetterTemplate::all() as $t) {
    echo $t->id . ' ' . $t->name . ' ' . ($t->file_name ?? '[no file]') . PHP_EOL;
}

echo PHP_EOL . 'Letters:' . PHP_EOL;
foreach (Letter::all() as $l) {
    echo $l->id . ' ' . $l->subject . ' template_id=' . ($l->template_id ?? 'null') . PHP_EOL;
}
