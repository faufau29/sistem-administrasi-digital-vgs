<?php

return [
    'mplb3' => [
        'name' => 'Manager Pengumpulan Limbah B3 (MPLB3)',
        'package' => 'Pelatihan Skema Sertifikasi Manager Pengumpulan Limbah B3 (MPLB3) Sertifikasi BNSP',
        'appendix_title' => 'Skema Sertifikasi Manager Pengumpulan Limbah B3 (MPLB3)',
        'chart' => 'images/proposal-chart-2.jpg',
    ],
    'oplb3' => [
        'name' => 'Operasional Penyimpanan/Pengumpulan Limbah B3 (OPLB3)',
        'package' => 'Pelatihan Skema Operasional Penyimpanan/Pengumpulan Limbah B3 (OPLB3) Sertifikasi BNSP',
        'appendix_title' => 'Skema Sertifikasi Operasional Pengumpulan Limbah B3 (OPLB3)',
        'chart' => 'images/proposal-chart-1.jpg',
    ],
    'pppa' => [
        'name' => 'Penanggung Jawab Pengendalian Pencemaran Air (PPPA)',
        'package' => 'Pelatihan Skema Penanggung Jawab Pengendalian Pencemaran Air (PPPA) Sertifikasi BNSP',
        'appendix_title' => 'Skema Sertifikasi Penanggung Jawab Pengendalian Pencemaran Air (PPPA)',
        'competencies' => [
            'Mengidentifikasi Sumber Pencemaran Air Limbah',
            'Menentukan Karakteristik Sumber Pencemaran Air Limbah',
            'Menilai Tingkat Pencemaran Air Limbah',
            'Menentukan Peralatan Instalasi Pengolahan Air Limbah (IPAL)',
            'Mengoperasikan Instalasi Pengolahan Air Limbah (IPAL)',
            'Melaksanakan Daur Ulang Olahan Air Limbah',
            'Menyusun Rencana Pemantauan Kualitas Air Limbah',
            'Melaksanakan Pemantauan Kualitas Air Limbah',
            'Mengidentifikasi Bahaya Dalam Pengolahan Air Limbah',
            'Melakukan Tindakan Keselamatan dan Kesehatan Kerja (K3) Terhadap Bahaya Dalam Pengolahan Air Limbah',
        ],
    ],
    'popal' => [
        'name' => 'Penanggung Jawab Operasional Pengolahan Air Limbah (POPAL)',
        'package' => 'Pelatihan Skema Penanggung Jawab Operasional Pengolahan Air Limbah (POPAL) Sertifikasi BNSP',
        'appendix_title' => 'Skema Sertifikasi Penanggung Jawab Operasional Pengolahan Air Limbah (POPAL)',
        'competencies' => [
            'Menilai Tingkat Pencemaran Air Limbah',
            'Mengoperasikan Instalasi Pengolahan Air Limbah (IPAL)',
            'Melakukan Perawatan Instalasi Pengolahan Air Limbah (IPAL)',
            'Mengidentifikasi Bahaya dalam Pengolahan Air Limbah',
            'Melakukan Tindakan Keselamatan dan Kesehatan Kerja (K3) terhadap Bahaya dalam Pengolahan Air Limbah',
        ],
    ],
];
