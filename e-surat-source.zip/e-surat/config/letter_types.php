<?php

return [
    'proposal' => 'Surat Penawaran',
    'instructor_request' => 'Surat Permohonan Instruktur',
    'other' => 'Surat Lainnya / Umum',
];
