<?php

return [
    'pppu_bnsp' => [
        'name' => 'Penyedia Pelatihan dan Sertifikasi PPPU BNSP',
        'price' => 2550000,
    ],
    'poippu_bnsp' => [
        'name' => 'Penyedia Pelatihan dan Sertifikasi POIPPU BNSP',
        'price' => 2050000,
    ],
    'mplb3_bnsp' => [
        'name' => 'Penyedia Pelatihan dan Sertifikasi MPLB3 BNSP',
        'price' => 2550000,
    ],
    'oplb3_bnsp' => [
        'name' => 'Penyedia Pelatihan dan Sertifikasi OPLB3 BNSP',
        'price' => 2050000,
    ],
    'pppa_bnsp' => [
        'name' => 'Penyedia Pelatihan dan Sertifikasi PPPA BNSP',
        'price' => 2550000,
    ],
    'popal_bnsp' => [
        'name' => 'Penyedia Pelatihan dan Sertifikasi POPAL BNSP',
        'price' => 2050000,
    ],
];
