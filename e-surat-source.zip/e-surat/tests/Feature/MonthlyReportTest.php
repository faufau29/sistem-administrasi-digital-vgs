<?php

use App\Models\Invoice;
use App\Models\Receipt;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

test('monthly report counts invoices and receipts by document date for the selected year', function () {
    Invoice::query()->create([
        'number' => 1,
        'full_number' => '1 - VTR',
        'date' => '2026-10-10',
        'recipient' => 'Invoice October',
        'amount' => 100000,
        'status' => 'issued',
    ]);
    Invoice::query()->create([
        'number' => 2,
        'full_number' => '2 - VTR',
        'date' => '2026-10-31',
        'recipient' => 'Another October invoice',
        'amount' => 100000,
        'status' => 'issued',
    ]);
    Invoice::query()->create([
        'number' => 3,
        'full_number' => '3 - VTR',
        'date' => '2026-11-01',
        'recipient' => 'November invoice',
        'amount' => 100000,
        'status' => 'issued',
    ]);
    Receipt::query()->create([
        'number' => 1,
        'full_number' => 'KWT/1',
        'date' => '2026-10-15',
        'payer' => 'October payer',
        'amount' => 100000,
        'status' => 'paid',
    ]);
    Receipt::query()->create([
        'number' => 2,
        'full_number' => 'KWT/2',
        'date' => '2025-10-15',
        'payer' => 'Previous year payer',
        'amount' => 100000,
        'status' => 'paid',
    ]);

    $this->actingAs(User::factory()->create())
        ->get(route('reports.monthly', ['year' => 2026]))
        ->assertOk()
        ->assertViewHas('monthlyReports', function ($monthlyReports) {
            $october = $monthlyReports->firstWhere('month', 10);
            $november = $monthlyReports->firstWhere('month', 11);

            return $monthlyReports->count() === 12
                && $october['invoice_count'] === 2
                && $october['receipt_count'] === 1
                && $october['total_count'] === 3
                && $november['invoice_count'] === 1
                && $november['receipt_count'] === 0;
        })
        ->assertViewHas('totalInvoices', 3)
        ->assertViewHas('totalReceipts', 1)
        ->assertViewHas('totalDocuments', 4)
        ->assertSee('Laporan Bulanan Invoice')
        ->assertSee('Oktober');
});

test('monthly report requires authentication', function () {
    $this->get(route('reports.monthly'))->assertRedirect(route('login'));
});

test('monthly report can be downloaded as a PDF for the selected year', function () {
    $this->actingAs(User::factory()->create())
        ->get(route('reports.monthly.pdf', ['year' => 2026]))
        ->assertOk()
        ->assertHeader('content-type', 'application/pdf')
        ->assertHeader('content-disposition', 'attachment; filename=Laporan-Bulanan-Invoice-Kwitansi-2026.pdf');
});
