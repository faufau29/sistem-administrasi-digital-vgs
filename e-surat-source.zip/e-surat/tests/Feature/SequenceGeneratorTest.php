<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\DocumentCategory;
use App\Services\SequenceGenerator;

class SequenceGeneratorTest extends TestCase
{
    use RefreshDatabase;

    public function test_sequence_increments_and_creates_history()
    {
        $category = DocumentCategory::create(['name' => 'Surat Penawaran', 'code' => 'PNW']);

        $first = SequenceGenerator::next('letter', $category->id, ['created_by' => null, 'format' => '{number}/{category}/{company}/{month_roman}/{year}']);
        $second = SequenceGenerator::next('letter', $category->id, ['created_by' => null]);

        $this->assertEquals(1, $first['number']);
        $this->assertEquals(2, $second['number']);
        $this->assertStringContainsString('PNW', $first['full_number']);
    }
}
