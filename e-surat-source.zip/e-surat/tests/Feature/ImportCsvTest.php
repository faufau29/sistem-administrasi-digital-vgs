<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use App\Models\DocumentCategory;

class ImportCsvTest extends TestCase
{
    use RefreshDatabase;

    public function test_import_csv_updates_sequences_and_creates_history()
    {
        Storage::fake('local');

        $admin = User::factory()->create(['role' => 'admin']);

        $category = DocumentCategory::create(['name' => 'Surat Penawaran', 'code' => 'PNW']);

        $csv = "document_type,category_code,number,full_number,date,notes\n";
        $csv .= "letter,PNW,586,586/PNW/VERITRUST/VI/2026,2026-06-01,imported old\n";

        $file = UploadedFile::fake()->createWithContent('import.csv', $csv);

        $response = $this->actingAs($admin)->post(route('imports.upload'), ['file' => $file]);
        $response->assertRedirect(route('imports.index'));

        // After import, next sequence should be 587
        $next = \App\Services\SequenceGenerator::next('letter', $category->id, ['created_by' => $admin->id]);
        $this->assertEquals(587, $next['number']);
    }
}
