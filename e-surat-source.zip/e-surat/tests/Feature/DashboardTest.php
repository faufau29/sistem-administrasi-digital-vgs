<?php

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

test('authenticated users see a responsive dashboard with document summaries and module links', function () {
    $this->actingAs(User::factory()->create())
        ->get('/dashboard')
        ->assertOk()
        ->assertSee('Pusat administrasi')
        ->assertSee('Ringkasan dokumen')
        ->assertSee('Modul dokumen')
        ->assertSee('Surat')
        ->assertSee('Invoice')
        ->assertSee('Kwitansi')
        ->assertSee('Aktivitas dokumen')
        ->assertSee('Pengaturan &amp; data', false)
        ->assertSee('grid-template-columns: 1fr', false);
});
