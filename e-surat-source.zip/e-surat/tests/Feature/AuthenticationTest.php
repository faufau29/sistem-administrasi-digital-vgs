<?php

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

uses(RefreshDatabase::class);

test('a guest can open the login and registration pages', function () {
    $this->get('/login')->assertOk()->assertSee('Login')->assertSee('Ingat saya');
    $this->get('/register')->assertOk()->assertSee('Buat akun baru');
});

test('a guest can register as staff and is signed in', function () {
    $response = $this->post('/register', [
        'name' => 'Staff Baru',
        'email' => 'staff-baru@example.com',
        'password' => 'password-rahasia',
        'password_confirmation' => 'password-rahasia',
    ]);

    $response->assertRedirect('/dashboard');
    $this->assertAuthenticated();

    $user = User::where('email', 'staff-baru@example.com')->firstOrFail();

    expect($user->name)->toBe('Staff Baru')
        ->and($user->role)->toBe('staff')
        ->and(Hash::check('password-rahasia', $user->password))->toBeTrue();
});

test('registration rejects duplicate emails and mismatched passwords', function () {
    User::factory()->create(['email' => 'existing@example.com']);

    $this->from('/register')->post('/register', [
        'name' => 'Akun Duplikat',
        'email' => 'existing@example.com',
        'password' => 'password-rahasia',
        'password_confirmation' => 'berbeda',
    ])->assertRedirect('/register')
        ->assertSessionHasErrors(['email', 'password']);
});

test('a registered user can sign in', function () {
    $user = User::factory()->create([
        'email' => 'staff@example.com',
        'password' => 'password-rahasia',
    ]);

    $response = $this->post('/login', [
        'email' => 'staff@example.com',
        'password' => 'password-rahasia',
        'remember' => '1',
    ]);

    $response->assertRedirect('/dashboard')
        ->assertCookie(Auth::guard()->getRecallerName());
    $this->assertAuthenticatedAs($user);
});
