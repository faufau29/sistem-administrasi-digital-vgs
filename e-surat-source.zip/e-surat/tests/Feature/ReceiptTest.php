<?php

namespace Tests\Feature;

use App\Models\Receipt;
use App\Models\User;
use App\Models\DocumentSequence;
use App\Models\DocumentNumberHistory;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ReceiptTest extends TestCase
{
    use RefreshDatabase;

    public function test_authenticated_user_can_create_a_receipt_with_the_sample_number_format(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)
            ->get(route('receipts.create'))
            ->assertOk()
            ->assertSee('name="full_number"', false)
            ->assertSee('KWT/POPAL BNSP -Veritrust 1/'.now()->format('Y'))
            ->assertSee('Nomor berikutnya terisi otomatis dan dapat diedit')
            ->assertSee('id="amount-preview"', false)
            ->assertSee('Tampilan nominal akan muncul saat jumlah diisi.')
            ->assertSee('Untuk keperluan')
            ->assertSee('Keperluan akan tersimpan bersama kwitansi')
            ->assertSee('required></textarea>', false)
            ->assertDontSee('Pelunasan Training dan Sertifikasi')
            ->assertSee('Lunas')
            ->assertSee('Belum Lunas');

        $response = $this->post(route('receipts.store'), [
            'date' => '2026-10-05',
            'payer' => 'Prasetya Ramadhan',
            'amount' => 3900000,
            'purpose' => 'Pelunasan Training dan Sertifikasi POPAL BNSP',
            'remaining_amount' => 0,
            'payment_method' => 'transfer',
            'status' => 'paid',
        ]);

        $receipt = Receipt::query()->firstOrFail();

        $response->assertRedirect(route('receipts.show', $receipt));
        $this->assertSame('KWT/POPAL BNSP -Veritrust 1/2026', $receipt->full_number);
        $this->assertSame('Prasetya Ramadhan', $receipt->payer);
        $this->assertSame('Pelunasan Training dan Sertifikasi POPAL BNSP', $receipt->purpose);
        $this->assertSame(0.0, (float) $receipt->remaining_amount);
    }

    public function test_receipt_number_can_be_edited_from_the_list_and_cannot_duplicate_another_number(): void
    {
        $this->actingAs(User::factory()->create());

        $payload = [
            'date' => '2026-10-05',
            'payer' => 'Pelanggan',
            'amount' => 100000,
            'purpose' => 'Pembayaran',
            'remaining_amount' => 0,
            'payment_method' => 'transfer',
            'status' => 'paid',
        ];

        $this->post(route('receipts.store'), $payload)->assertRedirect();
        $receipt = Receipt::firstOrFail();
        $this->post(route('receipts.store'), $payload + [
            'full_number' => 'KWT/TEST 2/2026',
        ])->assertRedirect();
        $otherReceipt = Receipt::whereKeyNot($receipt->id)->firstOrFail();

        $this->get(route('receipts.index'))
            ->assertOk()
            ->assertSee(route('receipts.edit', $receipt));

        $this->get(route('receipts.edit', $receipt))
            ->assertOk()
            ->assertSee('id="amount-preview"', false)
            ->assertSee('Tampilan nominal: Rp 100.000,00');

        $this->put(route('receipts.update', $receipt), $payload + [
            'full_number' => 'KWT/TEST 3/2026',
        ])->assertRedirect(route('receipts.show', $receipt));

        $this->from(route('receipts.edit', $otherReceipt))
            ->put(route('receipts.update', $otherReceipt), $payload + [
                'full_number' => 'KWT/OTHER 3/2026',
            ])
            ->assertRedirect(route('receipts.edit', $otherReceipt))
            ->assertSessionHasErrors('number');

        $this->post(route('receipts.store'), $payload)->assertRedirect();

        $receipt->refresh();
        $this->assertSame('KWT/TEST 3/2026', $receipt->full_number);
        $this->assertSame(3, $receipt->number);
        $this->assertSame(4, Receipt::orderByDesc('number')->firstOrFail()->number);
    }

    public function test_automatic_receipt_number_is_displayed_and_saved_like_invoice_numbering(): void
    {
        $this->actingAs(User::factory()->create());
        Receipt::query()->create([
            'number' => 453,
            'full_number' => 'KWT/MPLB3 BNSP - Veritrust 453/2026',
            'date' => '2026-11-11',
            'payer' => 'Pelanggan Sebelumnya',
            'amount' => 100000,
            'purpose' => 'Pembayaran',
            'remaining_amount' => 0,
            'payment_method' => 'transfer',
            'status' => 'paid',
        ]);
        DocumentSequence::query()->create([
            'document_type' => 'receipt',
            'category_id' => null,
            'last_number' => 502,
            'padding' => 1,
            'format' => 'KWT/POPAL BNSP -Veritrust {number_plain}/{year}',
        ]);
        DocumentNumberHistory::query()->create([
            'document_type' => 'receipt',
            'category_id' => null,
            'number' => 502,
            'full_number' => 'KWT/POPAL BNSP -Veritrust 502/2026',
            'status' => 'requested',
        ]);
        DocumentNumberHistory::query()->create([
            'document_type' => 'receipt',
            'category_id' => null,
            'number' => 503,
            'full_number' => 'KWT/POPAL BNSP -Veritrust 503/2026',
            'status' => 'requested',
        ]);

        $this->get(route('receipts.create'))
            ->assertOk()
            ->assertSee('value="KWT/POPAL BNSP -Veritrust 454/2026"', false);

        $this->post(route('receipts.store'), [
            'date' => '2026-11-11',
            'payer' => 'Pelanggan',
            'full_number' => 'KWT/POPAL BNSP -Veritrust 454/2026',
            'amount' => 100000,
            'purpose' => 'Pembayaran',
            'remaining_amount' => 0,
            'payment_method' => 'transfer',
            'status' => 'paid',
        ])->assertRedirect();

        $receipt = Receipt::query()->where('number', 454)->firstOrFail();
        $this->assertSame(454, $receipt->number);
        $this->assertSame('KWT/POPAL BNSP -Veritrust 454/2026', $receipt->full_number);

        $this->get(route('receipts.create'))
            ->assertOk()
            ->assertSee('value="KWT/POPAL BNSP -Veritrust 455/2026"', false);
    }

    public function test_receipt_number_must_include_a_number_and_year_to_prevent_duplicate_bypasses(): void
    {
        $this->actingAs(User::factory()->create());

        $this->from(route('receipts.create'))
            ->post(route('receipts.store'), [
                'date' => '2026-11-11',
                'payer' => 'Pelanggan',
                'full_number' => 'KWT/TEST',
                'amount' => 100000,
                'purpose' => 'Pembayaran',
                'remaining_amount' => 0,
                'payment_method' => 'transfer',
                'status' => 'paid',
            ])
            ->assertRedirect(route('receipts.create'))
            ->assertSessionHasErrors('full_number');

        $this->assertDatabaseCount('receipts', 0);
    }

    public function test_receipt_number_in_history_can_be_reused_when_not_currently_assigned(): void
    {
        $this->actingAs(User::factory()->create());
        DocumentNumberHistory::query()->create([
            'document_type' => 'receipt',
            'category_id' => null,
            'number' => 502,
            'full_number' => 'KWT/POPAL BNSP -Veritrust 502/2026',
            'status' => 'requested',
        ]);

        $this->post(route('receipts.store'), [
            'date' => '2026-11-11',
            'payer' => 'Pelanggan',
            'full_number' => 'KWT/POPAL BNSP -Veritrust 502/2026',
            'amount' => 100000,
            'purpose' => 'Pembayaran',
            'remaining_amount' => 0,
            'payment_method' => 'transfer',
            'status' => 'paid',
        ])->assertRedirect();

        $this->assertDatabaseHas('receipts', [
            'number' => 502,
            'full_number' => 'KWT/POPAL BNSP -Veritrust 502/2026',
        ]);
    }

    public function test_deleted_receipt_number_can_be_reentered_but_active_number_remains_a_duplicate(): void
    {
        $this->actingAs(User::factory()->create());
        $payload = [
            'date' => '2026-11-11',
            'payer' => 'Pelanggan',
            'amount' => 100000,
            'purpose' => 'Pembayaran',
            'remaining_amount' => 0,
            'payment_method' => 'transfer',
            'status' => 'paid',
        ];

        $this->post(route('receipts.store'), $payload + [
            'full_number' => 'KWT/TEST 1/2026',
        ])->assertRedirect();
        $this->post(route('receipts.store'), $payload + [
            'full_number' => 'KWT/TEST 2/2026',
        ])->assertRedirect();
        $deletedReceipt = Receipt::where('number', 1)->firstOrFail();
        $deletedReceipt->delete();

        $this->post(route('receipts.store'), $payload + [
            'full_number' => 'KWT/TEST 1/2026',
        ])->assertRedirect();

        $this->from(route('receipts.create'))
            ->post(route('receipts.store'), $payload + [
                'full_number' => 'KWT/ANOTHER 2/2026',
            ])
            ->assertRedirect(route('receipts.create'))
            ->assertSessionHasErrors('number');

        $this->assertDatabaseHas('receipts', ['number' => 1, 'full_number' => 'KWT/TEST 1/2026']);
        $this->assertDatabaseCount('receipts', 2);
    }

    public function test_saved_receipt_purposes_are_available_for_reuse(): void
    {
        $user = User::factory()->create();
        $savedPurpose = 'Uang muka Training Sertifikasi AK3U KEMNAKER RI';

        Receipt::query()->create([
            'number' => 510,
            'full_number' => 'KWT/AK3U 510/2026',
            'date' => '2026-10-05',
            'payer' => 'Pelanggan Sebelumnya',
            'amount' => 1000000,
            'purpose' => $savedPurpose,
            'remaining_amount' => 2500000,
            'payment_method' => 'transfer',
            'status' => 'unpaid',
        ]);

        $this->actingAs($user)
            ->get(route('receipts.create'))
            ->assertOk()
            ->assertSee('Pilih keperluan dari kwitansi sebelumnya')
            ->assertSee($savedPurpose);
    }

    public function test_authenticated_user_can_open_a_receipt_pdf(): void
    {
        $user = User::factory()->create();
        $receipt = Receipt::query()->create([
            'number' => 413,
            'full_number' => 'KWT/POPAL BNSP -Veritrust 413/2026',
            'date' => '2026-10-05',
            'payer' => 'Prasetya Ramadhan',
            'amount' => 3900000,
            'purpose' => 'Pelunasan Training dan Sertifikasi POPAL BNSP',
            'remaining_amount' => 0,
            'payment_method' => 'transfer',
            'status' => 'paid',
            'created_by' => $user->id,
        ]);

        $response = $this->actingAs($user)->get(route('receipts.pdf', $receipt));
        $pdfHtml = view('receipts.pdf', ['receipt' => $receipt])->render();
        $showHtml = view('receipts.show', compact('receipt'))->render();
        $indexHtml = view('receipts.index', [
            'receipts' => Receipt::query()->paginate(10),
        ])->render();

        $response->assertOk();
        $response->assertHeader('content-type', 'application/pdf');
        $response->assertHeader(
            'content-disposition',
            'inline; filename="413. KWITANSI POPAL BNSP Prasetya Ramadhan.pdf"',
        );
        $this->assertStringContainsString('href="'.route('receipts.pdf', $receipt).'" class="btn btn-primary" target="_blank" rel="noopener"', $showHtml);
        $this->assertStringContainsString('href="'.route('receipts.word', $receipt).'" class="btn btn-outline-primary" target="_blank" rel="noopener"', $showHtml);
        $this->assertStringContainsString('href="'.route('receipts.pdf', $receipt).'" class="btn btn-sm btn-outline-secondary" target="_blank" rel="noopener"', $indexHtml);
        $this->assertStringNotContainsString('General Manager Operasional', $pdfHtml);
        $this->assertStringNotContainsString('General Manager', $pdfHtml);
    }

    public function test_receipt_list_is_sorted_by_number_instead_of_date(): void
    {
        $user = User::factory()->create();

        Receipt::query()->create([
            'number' => 502,
            'full_number' => 'KWT/PPPA BNSP -Veritrust 502/2026',
            'date' => '2026-10-07',
            'payer' => 'Penerima 502',
            'amount' => 100000,
            'purpose' => 'Pembayaran',
            'remaining_amount' => 0,
            'payment_method' => 'transfer',
            'status' => 'paid',
        ]);
        Receipt::query()->create([
            'number' => 500,
            'full_number' => 'KWT/AK3U BNSP -Veritrust 500/2026',
            'date' => '2026-10-09',
            'payer' => 'Penerima 500',
            'amount' => 100000,
            'purpose' => 'Pembayaran',
            'remaining_amount' => 0,
            'payment_method' => 'transfer',
            'status' => 'paid',
        ]);
        Receipt::query()->create([
            'number' => 501,
            'full_number' => 'KWT/AK3U BNSP -Veritrust 501/2026',
            'date' => '2026-10-09',
            'payer' => 'Penerima 501',
            'amount' => 100000,
            'purpose' => 'Pembayaran',
            'remaining_amount' => 0,
            'payment_method' => 'transfer',
            'status' => 'paid',
        ]);

        $this->actingAs($user)
            ->get(route('receipts.index'))
            ->assertOk()
            ->assertSeeInOrder([
                'KWT/PPPA BNSP -Veritrust 502/2026',
                'KWT/AK3U BNSP -Veritrust 501/2026',
                'KWT/AK3U BNSP -Veritrust 500/2026',
            ]);
    }

    public function test_receipt_list_displays_ten_records_per_page_with_compact_pagination_controls(): void
    {
        $this->actingAs(User::factory()->create());

        foreach (range(1, 14) as $number) {
            Receipt::query()->create([
                'number' => $number,
                'full_number' => "KWT/TEST {$number}/2026",
                'date' => '2026-10-09',
                'payer' => "Penerima {$number}",
                'amount' => 100000,
                'purpose' => 'Pembayaran',
                'remaining_amount' => 0,
                'payment_method' => 'transfer',
                'status' => 'paid',
            ]);
        }

        $this->get(route('receipts.index'))
            ->assertOk()
            ->assertSee('Menampilkan 1 s/d 10')
            ->assertSee('14 data')
            ->assertSee('Prev')
            ->assertSee('Next')
            ->assertSee('page=2', false)
            ->assertSee('Penerima 14')
            ->assertDontSee('<td>Penerima 4</td>', false);

        $this->get(route('receipts.index', ['page' => 2]))
            ->assertOk()
            ->assertSee('Menampilkan 11 s/d 14')
            ->assertSee('Penerima 4')
            ->assertDontSee('<td>Penerima 14</td>', false);
    }

    public function test_receipt_list_and_export_can_be_filtered_by_month_and_year(): void
    {
        $this->actingAs(User::factory()->create());

        foreach ([
            [70, '2026-10-15'],
            [71, '2025-10-15'],
            [72, '2026-09-15'],
        ] as [$number, $date]) {
            Receipt::query()->create([
                'number' => $number,
                'full_number' => "KWT/TEST {$number}/2026",
                'date' => $date,
                'payer' => 'Target Payer',
                'amount' => 100000,
                'purpose' => 'Pembayaran',
                'remaining_amount' => 0,
                'payment_method' => 'transfer',
                'status' => 'paid',
            ]);
        }

        $filters = ['month' => 10, 'year' => 2026, 'search' => 'Target'];

        $this->get(route('receipts.index', $filters))
            ->assertOk()
            ->assertSee('KWT/TEST 70/2026')
            ->assertDontSee('KWT/TEST 71/2026')
            ->assertDontSee('KWT/TEST 72/2026');

        $this->get(route('receipts.index', ['year' => 2026]))
            ->assertOk()
            ->assertSee('KWT/TEST 70/2026')
            ->assertSee('KWT/TEST 72/2026')
            ->assertDontSee('KWT/TEST 71/2026');

        $this->get(route('receipts.index', ['month' => 10]))
            ->assertOk()
            ->assertSee('KWT/TEST 70/2026')
            ->assertSee('KWT/TEST 71/2026')
            ->assertDontSee('KWT/TEST 72/2026');

        $export = $this->get(route('receipts.export', ['format' => 'csv'] + $filters));
        $export->assertOk();
        $this->assertStringContainsString('KWT/TEST 70/2026', $export->streamedContent());
        $this->assertStringNotContainsString('KWT/TEST 71/2026', $export->streamedContent());
        $this->assertStringNotContainsString('KWT/TEST 72/2026', $export->streamedContent());
    }

    public function test_receipt_uses_stamp_image_when_amount_is_at_least_five_million(): void
    {
        $user = User::factory()->create();
        $receipt = Receipt::query()->create([
            'number' => 500,
            'full_number' => 'KWT/POPAL BNSP -Veritrust 500/2026',
            'date' => '2026-10-05',
            'payer' => 'Prasetya Ramadhan',
            'amount' => 5000000,
            'purpose' => 'Pelunasan Training dan Sertifikasi POPAL BNSP',
            'remaining_amount' => 0,
            'payment_method' => 'transfer',
            'status' => 'paid',
            'created_by' => $user->id,
        ]);

        $this->assertTrue($receipt->requiresStamp());

        $html = view('receipts.pdf', compact('receipt'))->render();
        $stampedImage = base64_encode(file_get_contents(public_path('images/receipt-signature-stamped.png')));

        $this->assertStringContainsString($stampedImage, $html);
        $this->assertStringContainsString('<div class="signer">Fitriyah, S.Si., M.Si</div>', $html);
    }

    public function test_receipt_does_not_use_stamp_image_when_amount_is_below_five_million(): void
    {
        $receipt = new Receipt(['amount' => 4999999]);

        $this->assertFalse($receipt->requiresStamp());
    }

    public function test_paid_receipt_requires_zero_remaining_balance(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)
            ->from(route('receipts.create'))
            ->post(route('receipts.store'), [
                'date' => '2026-10-05',
                'payer' => 'Prasetya Ramadhan',
                'amount' => 3900000,
                'purpose' => 'Pelunasan Training dan Sertifikasi POPAL BNSP',
                'remaining_amount' => 1,
                'payment_method' => 'transfer',
                'status' => 'paid',
            ])
            ->assertRedirect(route('receipts.create'))
            ->assertSessionHasErrors('remaining_amount');

        $this->assertDatabaseCount('receipts', 0);
    }

    public function test_authenticated_user_can_create_an_unpaid_receipt_with_remaining_balance(): void
    {
        $user = User::factory()->create();

        $response = $this->actingAs($user)->post(route('receipts.store'), [
            'date' => '2026-10-05',
            'payer' => 'Prasetya Ramadhan',
            'amount' => 500000,
            'purpose' => 'Pelunasan Training dan Sertifikasi POPAL BNSP',
            'remaining_amount' => 1900000,
            'payment_method' => 'transfer',
            'status' => 'unpaid',
        ]);

        $receipt = Receipt::query()->firstOrFail();

        $response->assertRedirect(route('receipts.show', $receipt));
        $this->assertSame('unpaid', $receipt->status);
        $this->assertFalse($receipt->isPaid());
        $this->assertSame('Belum Lunas', $receipt->paymentStatusLabel());
        $this->actingAs($user)
            ->get(route('receipts.show', $receipt))
            ->assertOk()
            ->assertSee('Belum Lunas');
    }

    public function test_authenticated_user_can_download_a_receipt_word_document(): void
    {
        $user = User::factory()->create();
        $receipt = Receipt::query()->create([
            'number' => 413,
            'full_number' => 'KWT/POPAL BNSP -Veritrust 413/2026',
            'date' => '2026-10-05',
            'payer' => 'Prasetya Ramadhan',
            'amount' => 3900000,
            'purpose' => 'Pelunasan Training dan Sertifikasi POPAL BNSP',
            'remaining_amount' => 0,
            'payment_method' => 'transfer',
            'status' => 'paid',
            'created_by' => $user->id,
        ]);

        $response = $this->actingAs($user)->get(route('receipts.word', $receipt));
        $response->assertDownload('kwitansi-'.$receipt->id.'.docx');

        $path = $response->baseResponse->getFile()->getPathname();
        if (is_file($path)) {
            unlink($path);
        }
    }
}
