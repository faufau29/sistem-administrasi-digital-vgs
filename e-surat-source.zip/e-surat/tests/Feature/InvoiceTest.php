<?php

use App\Models\Invoice;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

function invoicePayload(array $overrides = []): array
{
    return array_merge([
        'date' => '2026-10-07',
        'recipient' => 'Desiamy Fitria',
        'client_type' => 'individual',
        'description' => 'Penyedia Pelatihan Sertifikasi AK3U KEMNAKER',
        'quantity' => 1,
        'unit_price' => 5500000,
        'down_payment' => 500000,
        'status' => 'issued',
    ], $overrides);
}

test('invoice numbers are generated in order and totals are calculated from quantity and price', function () {
    $user = User::factory()->create();
    $this->actingAs($user);

    $this->post(route('invoices.store'), invoicePayload())
        ->assertRedirect();

    $this->post(route('invoices.store'), invoicePayload([
        'recipient' => 'Pelanggan Kedua',
        'quantity' => 2,
        'unit_price' => 3500000,
        'down_payment' => 0,
    ]))->assertRedirect();

    $invoices = Invoice::orderBy('number')->get();

    expect($invoices)->toHaveCount(2)
        ->and($invoices[0]->number)->toBe(1)
        ->and($invoices[0]->full_number)->toBe('1 - VTR')
        ->and((float) $invoices[0]->amount)->toBe(5500000.0)
        ->and($invoices[1]->number)->toBe(2)
        ->and((float) $invoices[1]->amount)->toBe(7000000.0);
});

test('company invoices add 11 percent other-value VAT to each training price and remaining balance', function () {
    $this->actingAs(User::factory()->create());

    $this->post(route('invoices.store'), invoicePayload([
        'client_type' => 'company',
        'unit_price' => 5200000,
        'down_payment' => 500000,
    ]))->assertRedirect();

    $invoice = Invoice::firstOrFail();
    $pdfHtml = view('invoices.pdf', ['invoice' => $invoice])->render();

    expect($invoice->taxAmount())->toBe(572000)
        ->and($invoice->totalWithTax())->toBe(5772000)
        ->and($invoice->remainingAmount())->toBe(5272000)
        ->and($invoice->requiresStamp())->toBeTrue()
        ->and($pdfHtml)->toContain('PPn Nilai Lain')
        ->and($pdfHtml)->toContain('Rp. 572.000')
        ->and($pdfHtml)->toContain('Rp. 5.272.000')
        ->and($pdfHtml)->toContain('>TOTAL SISA<')
        ->and($pdfHtml)->toContain('width: 46%')
        ->and($pdfHtml)->toContain('width: 9%')
        ->and($pdfHtml)->toContain('width: 22%')
        ->and($pdfHtml)->toContain('width: 23%')
        ->and($pdfHtml)->toContain('class="spacer-row"');

    $this->get(route('invoices.show', $invoice))
        ->assertOk()
        ->assertSee('PPn Nilai Lain 11%')
        ->assertSee('5.272.000');
});

test('invoice form keeps calculated rupiah totals on one line', function () {
    $this->actingAs(User::factory()->create());

    $this->get(route('invoices.create'))
        ->assertOk()
        ->assertSee('class="col-sm-8 col-lg-2 text-nowrap"', false)
        ->assertSee('class="text-nowrap" data-line-total', false)
        ->assertSee('class="text-nowrap" id="invoice-subtotal"', false)
        ->assertSee('class="text-nowrap" id="invoice-tax"', false)
        ->assertSee('class="text-nowrap" id="invoice-total"', false);
});

test('invoice PDF and Word links open in a separate tab', function () {
    $this->actingAs(User::factory()->create());
    $this->post(route('invoices.store'), invoicePayload());
    $invoice = Invoice::firstOrFail();

    $showHtml = view('invoices.show', compact('invoice'))->render();
    $indexHtml = view('invoices.index', [
        'invoices' => Invoice::query()->paginate(10),
    ])->render();

    expect($showHtml)
        ->toContain('href="'.route('invoices.word', $invoice).'" class="btn btn-outline-primary" target="_blank" rel="noopener"')
        ->toContain('href="'.route('invoices.pdf', $invoice).'" class="btn btn-primary" target="_blank" rel="noopener"')
        ->and($indexHtml)
        ->toContain('href="'.route('invoices.pdf', $invoice).'" class="btn btn-sm btn-outline-secondary" target="_blank" rel="noopener"');
});

test('invoice document tables show the full total when there is no down payment', function () {
    $this->actingAs(User::factory()->create());
    $this->post(route('invoices.store'), invoicePayload(['down_payment' => '']));
    $invoice = Invoice::firstOrFail();
    $response = $this->get(route('invoices.word', $invoice))->assertOk();
    $temporaryDocx = tempnam(sys_get_temp_dir(), 'invoice-docx-');
    expect($temporaryDocx)->not->toBeFalse();

    try {
        file_put_contents($temporaryDocx, $response->streamedContent());
        $archive = new ZipArchive;
        $archiveOpened = $archive->open($temporaryDocx) === true;
        expect($archiveOpened)->toBeTrue();

        $documentXml = $archive->getFromName('word/document.xml');
        expect($documentXml)
            ->toContain('TOTAL')
            ->not->toContain('TOTAL SISA')
            ->toContain('5.500.000');
    } finally {
        if (isset($archive) && $archiveOpened) {
            $archive->close();
        }

        unlink($temporaryDocx);
    }
});

test('invoice tables display legacy penyediaan descriptions as penyedia', function () {
    $this->actingAs(User::factory()->create());
    $this->post(route('invoices.store'), invoicePayload([
        'description' => 'Penyediaan Pelatihan dan Sertifikasi MPLB3 BNSP',
    ]))->assertRedirect();

    $invoice = Invoice::firstOrFail();
    $pdfHtml = view('invoices.pdf', compact('invoice'))->render();

    expect($pdfHtml)
        ->toContain('Penyedia Pelatihan dan Sertifikasi MPLB3 BNSP')
        ->not->toContain('Penyediaan Pelatihan dan Sertifikasi MPLB3 BNSP');

    $this->get(route('invoices.show', $invoice))
        ->assertOk()
        ->assertSee('Penyedia Pelatihan dan Sertifikasi MPLB3 BNSP')
        ->assertDontSee('Penyediaan Pelatihan dan Sertifikasi MPLB3 BNSP');
});

test('invoice without down payment or tax keeps those rows out of its details and document table', function () {
    $this->actingAs(User::factory()->create());

    $this->post(route('invoices.store'), invoicePayload([
        'client_type' => 'individual',
        'down_payment' => '',
    ]))->assertRedirect();

    $invoice = Invoice::firstOrFail();
    $pdfHtml = view('invoices.pdf', compact('invoice'))->render();

    expect((int) $invoice->down_payment)->toBe(0)
        ->and($pdfHtml)->not->toContain('PPn Nilai Lain')
        ->and($pdfHtml)->not->toContain('>DP<')
        ->and($pdfHtml)->toContain('>TOTAL<')
        ->and($pdfHtml)->not->toContain('TOTAL SISA')
        ->and($pdfHtml)->toContain('Rp. 5.500.000');

    $this->get(route('invoices.show', $invoice))
        ->assertOk()
        ->assertDontSee('PPn Nilai Lain 11%')
        ->assertDontSee('<strong>DP:</strong>', false);
});

test('invoice supports multiple training schemes in one description while keeping one combined total', function () {
    $this->actingAs(User::factory()->create());
    $description = "Sertifikasi AK3U KEMNAKER\nSertifikasi POPAL BNSP";

    $this->post(route('invoices.store'), invoicePayload([
        'description' => $description,
        'quantity' => 2,
        'unit_price' => 3500000,
        'down_payment' => '',
    ]))->assertRedirect();

    $invoice = Invoice::firstOrFail();
    $pdfHtml = view('invoices.pdf', compact('invoice'))->render();

    expect($invoice->description)->toBe($description)
        ->and((float) $invoice->amount)->toBe(7000000.0)
        ->and($pdfHtml)->toContain('Sertifikasi AK3U KEMNAKER')
        ->and($pdfHtml)->toContain('Sertifikasi POPAL BNSP');

    $this->get(route('invoices.show', $invoice))
        ->assertOk()
        ->assertSee('Sertifikasi AK3U KEMNAKER')
        ->assertSee('Sertifikasi POPAL BNSP');
});

test('invoice automatically prices multiple selected training schemes and calculates company tax from their subtotal', function () {
    $this->actingAs(User::factory()->create());

    $this->get(route('invoices.create'))
        ->assertOk()
        ->assertSee('Penyedia Pelatihan dan Sertifikasi PPPU BNSP')
        ->assertSee('Penyedia Pelatihan dan Sertifikasi POIPPU BNSP')
        ->assertSee('Tambah pelatihan')
        ->assertSee('2550000')
        ->assertSee('2050000');

    $this->post(route('invoices.store'), [
        'date' => '2026-10-29',
        'recipient' => 'Pelanggan Perusahaan',
        'client_type' => 'company',
        'items' => [
            ['training' => 'pppu_bnsp', 'quantity' => 1, 'unit_price' => 2600000],
            ['training' => 'poippu_bnsp', 'quantity' => 1, 'unit_price' => 2050000],
            ['training' => 'mplb3_bnsp', 'quantity' => 1, 'unit_price' => 1],
            ['training' => 'oplb3_bnsp', 'quantity' => 1, 'unit_price' => 2050000],
            ['training' => 'pppa_bnsp', 'quantity' => 1, 'unit_price' => 1],
            ['training' => 'popal_bnsp', 'quantity' => 1, 'unit_price' => 2050000],
        ],
        'down_payment' => '',
        'status' => 'issued',
    ])->assertRedirect();

    $invoice = Invoice::with('items')->firstOrFail();

    expect($invoice->items)->toHaveCount(6)
        ->and($invoice->items[0]->description)->toBe('Penyedia Pelatihan dan Sertifikasi PPPU BNSP')
        ->and((float) $invoice->items[0]->unit_price)->toBe(2600000.0)
        ->and($invoice->items[1]->description)->toBe('Penyedia Pelatihan dan Sertifikasi POIPPU BNSP')
        ->and((float) $invoice->items[1]->unit_price)->toBe(2050000.0)
        ->and((float) $invoice->items[2]->unit_price)->toBe(2550000.0)
        ->and((float) $invoice->items[3]->unit_price)->toBe(2050000.0)
        ->and((float) $invoice->items[4]->unit_price)->toBe(2550000.0)
        ->and((float) $invoice->items[5]->unit_price)->toBe(2050000.0)
        ->and((float) $invoice->amount)->toBe(13850000.0)
        ->and($invoice->taxAmount())->toBe(1523500)
        ->and($invoice->totalWithTax())->toBe(15373500);

    $pdfHtml = view('invoices.pdf', compact('invoice'))->render();
    expect($pdfHtml)
        ->toContain('Penyedia Pelatihan dan Sertifikasi PPPU BNSP')
        ->toContain('Penyedia Pelatihan dan Sertifikasi POIPPU BNSP')
        ->toContain('Penyedia Pelatihan dan Sertifikasi MPLB3 BNSP')
        ->toContain('Penyedia Pelatihan dan Sertifikasi OPLB3 BNSP')
        ->toContain('Penyedia Pelatihan dan Sertifikasi PPPA BNSP')
        ->toContain('Penyedia Pelatihan dan Sertifikasi POPAL BNSP')
        ->toContain('Rp. 1.523.500')
        ->toContain('Rp. 15.373.500');

    $export = $this->get(route('invoices.export', ['format' => 'csv']));
    $export->assertOk();
    expect($export->streamedContent())
        ->toContain('Penyedia Pelatihan dan Sertifikasi PPPU BNSP')
        ->toContain('Penyedia Pelatihan dan Sertifikasi POIPPU BNSP')
        ->toContain('Penyedia Pelatihan dan Sertifikasi POPAL BNSP');
});

test('invoice rejects a down payment greater than the total', function () {
    $this->actingAs(User::factory()->create());

    $this->from(route('invoices.create'))
        ->post(route('invoices.store'), invoicePayload([
            'unit_price' => 4000000,
            'down_payment' => 5000000,
        ]))
        ->assertRedirect(route('invoices.create'))
        ->assertSessionHasErrors('down_payment');

    expect(Invoice::count())->toBe(0);
});

test('invoice accepts a manually requested number and continues the automatic sequence afterward', function () {
    $this->actingAs(User::factory()->create());

    $this->post(route('invoices.store'), invoicePayload([
        'full_number' => '539 - VTR',
    ]))->assertRedirect();

    $manual = Invoice::firstOrFail();

    expect($manual->number)->toBe(539)
        ->and($manual->full_number)->toBe('539 - VTR');

    $this->get(route('invoices.create'))
        ->assertOk()
        ->assertSee('value="540 - VTR"', false);

    $this->post(route('invoices.store'), invoicePayload())->assertRedirect();

    $automatic = Invoice::whereKeyNot($manual->id)->firstOrFail();

    expect($automatic->number)->toBe(540)
        ->and($automatic->full_number)->toBe('540 - VTR');
});

test('invoice list shows highest number first while export stays numerically ascending', function () {
    $this->actingAs(User::factory()->create());

    $this->post(route('invoices.store'), invoicePayload([
        'full_number' => '544 - VTR',
        'date' => '2026-10-09',
    ]))->assertRedirect();
    $this->post(route('invoices.store'), invoicePayload([
        'full_number' => '540 - VTR',
        'date' => '2026-10-08',
    ]))->assertRedirect();
    $this->post(route('invoices.store'), invoicePayload([
        'full_number' => '543 - VTR',
        'date' => '2026-10-09',
    ]))->assertRedirect();

    $this->get(route('invoices.index'))
        ->assertOk()
        ->assertSeeInOrder(['544 - VTR', '543 - VTR', '540 - VTR']);

    $export = $this->get(route('invoices.export', ['format' => 'csv']));
    $export->assertOk();
    expect($export->streamedContent())
        ->toContain('540 - VTR')
        ->toContain('543 - VTR')
        ->toContain('544 - VTR')
        ->and(strpos($export->streamedContent(), '540 - VTR'))
        ->toBeLessThan(strpos($export->streamedContent(), '543 - VTR'))
        ->and(strpos($export->streamedContent(), '543 - VTR'))
        ->toBeLessThan(strpos($export->streamedContent(), '544 - VTR'));
});

test('invoice list displays ten records per page with compact pagination controls', function () {
    $this->actingAs(User::factory()->create());

    foreach (range(1, 14) as $number) {
        Invoice::query()->create([
            'number' => $number,
            'full_number' => "{$number} - VTR",
            'date' => '2026-10-09',
            'recipient' => "Penerima {$number}",
            'amount' => 100000,
            'status' => 'issued',
        ]);
    }

    $this->get(route('invoices.index'))
        ->assertOk()
        ->assertSee('Menampilkan 1 s/d 10')
        ->assertSee('14 data')
        ->assertSee('Prev')
        ->assertSee('Next')
        ->assertSee('page=2', false)
        ->assertSee('Penerima 14')
        ->assertDontSee('<td>Penerima 4</td>', false);

    $this->get(route('invoices.index', ['page' => 2]))
        ->assertOk()
        ->assertSee('Menampilkan 11 s/d 14')
        ->assertSee('Penerima 4')
        ->assertDontSee('Penerima 14');
});

test('invoice list and export can be filtered by month and year', function () {
    $this->actingAs(User::factory()->create());

    foreach ([
        [70, '2026-10-15'],
        [71, '2025-10-15'],
        [72, '2026-09-15'],
    ] as [$number, $date]) {
        Invoice::query()->create([
            'number' => $number,
            'full_number' => "{$number} - VTR",
            'date' => $date,
            'recipient' => 'Target Customer',
            'amount' => 100000,
            'status' => 'issued',
        ]);
    }

    $filters = ['month' => 10, 'year' => 2026, 'search' => 'Target'];

    $this->get(route('invoices.index', $filters))
        ->assertOk()
        ->assertSee('70 - VTR')
        ->assertDontSee('71 - VTR')
        ->assertDontSee('72 - VTR');

    $this->get(route('invoices.index', ['year' => 2026]))
        ->assertOk()
        ->assertSee('70 - VTR')
        ->assertSee('72 - VTR')
        ->assertDontSee('71 - VTR');

    $this->get(route('invoices.index', ['month' => 10]))
        ->assertOk()
        ->assertSee('70 - VTR')
        ->assertSee('71 - VTR')
        ->assertDontSee('72 - VTR');

    $export = $this->get(route('invoices.export', ['format' => 'csv'] + $filters));
    $export->assertOk();
    expect($export->streamedContent())
        ->toContain('70 - VTR')
        ->not->toContain('71 - VTR')
        ->not->toContain('72 - VTR');
});

test('invoice rejects a duplicate or incorrectly formatted requested number', function () {
    $this->actingAs(User::factory()->create());
    $this->post(route('invoices.store'), invoicePayload(['full_number' => '2 - VTR']));

    $this->from(route('invoices.create'))
        ->post(route('invoices.store'), invoicePayload(['full_number' => '2']))
        ->assertRedirect(route('invoices.create'))
        ->assertSessionHasErrors('full_number');

    $this->from(route('invoices.create'))
        ->post(route('invoices.store'), invoicePayload(['full_number' => 'INVOICE-3']))
        ->assertRedirect(route('invoices.create'))
        ->assertSessionHasErrors('full_number');

    expect(Invoice::count())->toBe(1);
});

test('deleted invoice number can be reentered while an active number remains a duplicate', function () {
    $this->actingAs(User::factory()->create());
    $this->post(route('invoices.store'), invoicePayload(['full_number' => '1 - VTR']))->assertRedirect();
    $this->post(route('invoices.store'), invoicePayload(['full_number' => '2 - VTR']))->assertRedirect();
    $deletedInvoice = Invoice::where('number', 1)->firstOrFail();

    $this->delete(route('invoices.destroy', $deletedInvoice))->assertRedirect(route('invoices.index'));

    $this->post(route('invoices.store'), invoicePayload(['full_number' => '1 - VTR']))->assertRedirect();

    $this->from(route('invoices.create'))
        ->post(route('invoices.store'), invoicePayload(['full_number' => '2 - VTR']))
        ->assertRedirect(route('invoices.create'))
        ->assertSessionHasErrors('full_number');

    expect(Invoice::count())->toBe(2)
        ->and(Invoice::where('number', 1)->value('full_number'))->toBe('1 - VTR')
        ->and(Invoice::where('number', 2)->value('full_number'))->toBe('2 - VTR');
});

test('invoice payment note uses the correct certification assessment term', function () {
    $invoice = new Invoice([
        'description' => 'Sertifikasi Ahli K3U Kemnaker',
        'down_payment' => 100000,
    ]);

    expect($invoice->paymentNote())
        ->toBe('Note : Untuk Sisa Pembayaran Maksimal Saat Training berlangsung/sebelum ujian.');

    $invoice->description = 'Sertifikasi Auditor SMK3 BNSP';

    expect($invoice->paymentNote())
        ->toBe('Note : Untuk Sisa Pembayaran Maksimal Saat Training berlangsung/sebelum asesmen.');

    $invoice->down_payment = null;

    expect($invoice->paymentNote())->toBeNull();
});

test('invoice without down payment does not show payment note in PDF', function () {
    $this->actingAs(User::factory()->create());
    $this->post(route('invoices.store'), invoicePayload(['down_payment' => '']));
    $invoice = Invoice::firstOrFail();

    expect(view('invoices.pdf', compact('invoice'))->render())
        ->not->toContain('Note : Untuk Sisa Pembayaran Maksimal');
});

test('updating an invoice keeps its number and recalculates its total', function () {
    $this->actingAs(User::factory()->create());
    $this->post(route('invoices.store'), invoicePayload());
    $invoice = Invoice::firstOrFail();

    $this->put(route('invoices.update', $invoice), invoicePayload([
        'full_number' => $invoice->full_number,
        'description' => 'Pelatihan lanjutan',
        'quantity' => 2,
        'unit_price' => 3000000,
        'down_payment' => 1000000,
    ]))->assertRedirect(route('invoices.show', $invoice));

    $invoice->refresh();

    expect($invoice->full_number)->toBe('1 - VTR')
        ->and((float) $invoice->amount)->toBe(6000000.0)
        ->and($invoice->description)->toBe('Pelatihan lanjutan');
});

test('invoice number can be changed without allowing duplicates or reusing the updated number', function () {
    $this->actingAs(User::factory()->create());
    $this->post(route('invoices.store'), invoicePayload());
    $invoice = Invoice::firstOrFail();
    $this->post(route('invoices.store'), invoicePayload(['full_number' => '539 - VTR']));
    $otherInvoice = Invoice::whereKeyNot($invoice->id)->firstOrFail();

    $this->get(route('invoices.index'))
        ->assertOk()
        ->assertSee(route('invoices.edit', $invoice));

    $this->put(route('invoices.update', $invoice), invoicePayload(['full_number' => '540 - VTR']))
        ->assertRedirect(route('invoices.show', $invoice));

    $this->from(route('invoices.edit', $otherInvoice))
        ->put(route('invoices.update', $otherInvoice), invoicePayload(['full_number' => '540 - VTR']))
        ->assertRedirect(route('invoices.edit', $otherInvoice))
        ->assertSessionHasErrors('full_number');

    $this->post(route('invoices.store'), invoicePayload())->assertRedirect();

    expect($invoice->fresh()->full_number)->toBe('540 - VTR')
        ->and(Invoice::orderByDesc('number')->first()->full_number)->toBe('541 - VTR');
});

test('invoice uses a stamp only when the remaining balance is five million rupiah or more', function () {
    $this->actingAs(User::factory()->create());

    $this->post(route('invoices.store'), invoicePayload(['unit_price' => 5000000, 'down_payment' => 0]));
    $exactThreshold = Invoice::firstOrFail();
    $exactThresholdPdf = $this->get(route('invoices.pdf', $exactThreshold));
    $exactThresholdHtml = view('invoices.pdf', ['invoice' => $exactThreshold])->render();

    expect($exactThreshold->requiresStamp())->toBeTrue()
        ->and($exactThresholdHtml)->toContain('Nomor&nbsp; : 1 - VTR')
        ->and($exactThresholdHtml)->toContain('Bill To:')
        ->and($exactThresholdHtml)->toContain('>TOTAL<')
        ->and($exactThresholdHtml)->not->toContain('TOTAL SISA')
        ->and($exactThresholdHtml)->toContain(base64_encode(file_get_contents(public_path('images/invoice-signature-stamped-mark.png'))))
        ->and($exactThresholdHtml)->toContain('class="signatory-name">Fitriyah, S.Si., M.Si')
        ->and($exactThresholdHtml)->toContain('class="signatory-title">General Manager')
        ->and($exactThresholdHtml)->not->toContain('General Manager Operasional');

    $exactThresholdPdf->assertOk()
        ->assertHeader('content-type', 'application/pdf')
        ->assertHeader('content-disposition', 'inline; filename="1. inv AK3U KEMNAKER Desiamy Fitria.pdf"');

    $this->post(route('invoices.store'), invoicePayload());
    $aboveThreshold = Invoice::orderByDesc('id')->firstOrFail();
    $aboveThresholdPdf = $this->get(route('invoices.pdf', $aboveThreshold));
    $aboveThresholdHtml = view('invoices.pdf', ['invoice' => $aboveThreshold])->render();

    expect($aboveThreshold->requiresStamp())->toBeTrue()
        ->and($aboveThresholdHtml)->toContain(base64_encode(file_get_contents(public_path('images/invoice-signature-stamped-mark.png'))));

    $aboveThresholdPdf->assertOk()
        ->assertHeader('content-type', 'application/pdf');

    $this->post(route('invoices.store'), invoicePayload([
        'unit_price' => 5200000,
        'down_payment' => 500000,
    ]));
    $belowThreshold = Invoice::orderByDesc('id')->firstOrFail();
    $belowThresholdHtml = view('invoices.pdf', ['invoice' => $belowThreshold])->render();

    expect($belowThreshold->requiresStamp())->toBeFalse()
        ->and($belowThreshold->remainingAmount())->toBe(4700000)
        ->and($belowThresholdHtml)->not->toContain(base64_encode(file_get_contents(public_path('images/invoice-signature-stamped-mark.png'))))
        ->and($belowThresholdHtml)->toContain(base64_encode(file_get_contents(public_path('images/invoice-signature-mark.png'))))
        ->and($belowThresholdHtml)->not->toContain('dengan meterai');
});

test('invoice detail provides a signed Word document download', function () {
    $this->actingAs(User::factory()->create());
    $this->post(route('invoices.store'), invoicePayload([
        'client_type' => 'company',
        'items' => [
            ['training' => 'pppu_bnsp', 'quantity' => 1, 'unit_price' => 2550000],
            [
                'training' => 'custom',
                'description' => 'Sertifikasi khusus BNSP',
                'quantity' => 1,
                'unit_price' => 2650000,
            ],
        ],
    ]));
    $invoice = Invoice::firstOrFail();

    $this->get(route('invoices.show', $invoice))
        ->assertOk()
        ->assertSee(route('invoices.word', $invoice))
        ->assertSee('Unduh Word');
    $showHtml = view('invoices.show', compact('invoice'))->render();
    $indexHtml = view('invoices.index', [
        'invoices' => Invoice::query()->paginate(10),
    ])->render();

    expect($showHtml)
        ->toContain('href="'.route('invoices.word', $invoice).'" class="btn btn-outline-primary" target="_blank" rel="noopener"')
        ->toContain('href="'.route('invoices.pdf', $invoice).'" class="btn btn-primary" target="_blank" rel="noopener"')
        ->and($indexHtml)
        ->toContain('href="'.route('invoices.pdf', $invoice).'" class="btn btn-sm btn-outline-secondary" target="_blank" rel="noopener"');

    $response = $this->get(route('invoices.word', $invoice));

    $response->assertOk()
        ->assertHeader(
            'content-type',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        )
        ->assertHeader(
            'content-disposition',
            'attachment; filename="1. inv PPPU BNSP & Sertifikasi khusus BNSP Desiamy Fitria.docx"'
        );

    $temporaryDocx = tempnam(sys_get_temp_dir(), 'invoice-docx-');
    expect($temporaryDocx)->not->toBeFalse();

    try {
        file_put_contents($temporaryDocx, $response->streamedContent());
        $archive = new ZipArchive;
        $archiveOpened = $archive->open($temporaryDocx) === true;

        expect($archiveOpened)->toBeTrue();
        $containsCombinedImage = false;
        $documentXml = $archive->getFromName('word/document.xml');
        $stylesXml = $archive->getFromName('word/styles.xml');
        $headerTableStart = strpos($documentXml, '<w:tbl>');
        $headerTableEnd = $headerTableStart === false
            ? false
            : strpos($documentXml, '</w:tbl>', $headerTableStart);
        $headerTableXml = $headerTableStart === false || $headerTableEnd === false
            ? ''
            : substr($documentXml, $headerTableStart, $headerTableEnd - $headerTableStart);
        $closingTableStart = strrpos($documentXml, '<w:tbl>');
        $closingTableEnd = $closingTableStart === false
            ? false
            : strpos($documentXml, '</w:tbl>', $closingTableStart);
        $closingTableXml = $closingTableStart === false || $closingTableEnd === false
            ? ''
            : substr($documentXml, $closingTableStart, $closingTableEnd - $closingTableStart);
        for ($index = 0; $index < $archive->numFiles; $index++) {
            $mediaPath = $archive->getNameIndex($index);
            if (str_starts_with($mediaPath, 'word/media/')) {
                if ($archive->getFromIndex($index) === file_get_contents(public_path('images/invoice-signature-stamped-mark.png'))) {
                    $containsCombinedImage = true;
                }
            }
        }

        expect($containsCombinedImage)->toBeTrue()
            ->and($headerTableXml)->toContain('w:color="FFFFFF"')
            ->not->toContain('w:color="111111"')
            ->and($documentXml)->toContain('PT. Veritrust Global Solusindo')
            ->toContain('Tanggal : 07/10/2026')
            ->and($closingTableXml)->toContain('w:color="FFFFFF"')
            ->not->toContain('w:color w:val="111111"')
            ->not->toContain('w:color w:val="000000"')
            ->and($documentXml)->toContain('PPn Nilai Lain')
            ->and($documentXml)->toContain('TOTAL SISA')
            ->and($stylesXml)->toContain('w:tblW w:w="10000" w:type="pct"')
            ->and($documentXml)->toContain('w:tblHeader')
            ->and($documentXml)->toContain('w:fill="C8C8C8"')
            ->and($documentXml)->toContain('<w:tcPr><w:tcW w:w="4600" w:type="dxa"/></w:tcPr><w:p><w:pPr/><w:r><w:rPr/><w:t xml:space="preserve">Penyedia Pelatihan')
            ->and($documentXml)->toContain('Penyedia Pelatihan dan Sertifikasi PPPU BNSP')
            ->and($documentXml)->toContain('Sertifikasi khusus BNSP')
            ->and($documentXml)->toContain('572.000')
            ->and($documentXml)->toContain('5.272.000')
            ->and($documentXml)->toContain('w:w="4600"')
            ->and($documentXml)->toContain('w:w="900"')
            ->and($documentXml)->toContain('w:w="2200"')
            ->and($documentXml)->toContain('w:w="2300"')
            ->and($documentXml)->not->toContain('w:gridSpan')
            ->and($documentXml)->toContain('Fitriyah, S.Si., M.Si')
            ->and($documentXml)->toContain('General Manager')
            ->and($documentXml)->not->toContain('General Manager Operasional');
    } finally {
        if (isset($archive) && $archiveOpened) {
            $archive->close();
            unset($archive);
        }

        unlink($temporaryDocx);
    }
});

test('invoice PDF filename uses the invoice number, training name, and recipient safely', function () {
    $this->actingAs(User::factory()->create());
    $this->post(route('invoices.store'), invoicePayload([
        'full_number' => '505 - VTR',
        'description' => 'AK3U / BNSP',
        'recipient' => 'Muhammad Rizky Wijaya',
    ]));

    $invoice = Invoice::firstOrFail();

    $this->get(route('invoices.pdf', $invoice))
        ->assertOk()
        ->assertHeader('content-disposition', 'inline; filename="505. inv AK3U BNSP Muhammad Rizky Wijaya.pdf"');
});

test('invoice PDF filename joins multiple training names and includes the recipient', function () {
    $this->actingAs(User::factory()->create());
    $this->post(route('invoices.store'), [
        'date' => '2026-10-29',
        'recipient' => 'PT Lancang Kuning Sukses',
        'client_type' => 'company',
        'items' => [
            ['training' => 'mplb3_bnsp', 'quantity' => 1, 'unit_price' => 4700000],
            ['training' => 'oplb3_bnsp', 'quantity' => 1, 'unit_price' => 3700000],
        ],
        'down_payment' => '',
        'status' => 'issued',
    ])->assertRedirect();

    $invoice = Invoice::firstOrFail();

    $this->get(route('invoices.pdf', $invoice))
        ->assertOk()
        ->assertHeader('content-disposition', 'inline; filename="1. inv MPLB3 BNSP & OPLB3 BNSP PT Lancang Kuning Sukses.pdf"');
});

test('invoice export includes billing details and stamp requirement', function () {
    $this->actingAs(User::factory()->create());
    $this->post(route('invoices.store'), invoicePayload(['client_type' => 'company']));

    $response = $this->get(route('invoices.export', ['format' => 'csv']));
    $response->assertOk();

    expect($response->streamedContent())
        ->toContain('description,quantity,unit_price,down_payment,remaining_amount,requires_stamp')
        ->toContain('Penyedia Pelatihan Sertifikasi AK3U KEMNAKER')
        ->toContain('company')
        ->toContain('605000')
        ->toContain('yes');
});
