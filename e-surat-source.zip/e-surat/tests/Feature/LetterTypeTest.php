<?php

use App\Models\DocumentCategory;
use App\Models\Letter;
use App\Models\LetterTemplate;
use App\Models\User;
use App\Services\DocxTemplateRenderer;
use App\Services\TemplateRenderer;
use Illuminate\Foundation\Testing\RefreshDatabase;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\PhpWord;

uses(RefreshDatabase::class);

test('letter creation starts with separate types and the proposal form uses the letter numbering category', function () {
    $letterCategory = DocumentCategory::query()->where('code', 'SRT')->firstOrFail();
    $user = User::factory()->create();

    $this->actingAs($user)
        ->get(route('letters.create'))
        ->assertOk()
        ->assertSee('Pilih jenis surat')
        ->assertSee(route('letters.create.type', 'proposal'))
        ->assertSee(route('letters.create.type', 'instructor_request'))
        ->assertDontSee('name="category_id"', false);

    $this->get(route('letters.create.type', 'proposal'))
        ->assertOk()
        ->assertSee('name="full_number"', false)
        ->assertSee('Kosongkan untuk nomor otomatis, atau isi nomor sendiri')
        ->assertSee('value="'.$letterCategory->id.'" selected', false)
        ->assertSee('name="offer_items[0][scheme]"', false)
        ->assertDontSee('name="instructor_details[training_name]"', false);

    $this->get(route('letters.create.type', 'instructor_request'))
        ->assertOk()
        ->assertSee('name="instructor_details[training_name]"', false)
        ->assertSee('name="attachment_note" class="form-control" value="-"', false)
        ->assertSee('value="2026-11-02"', false)
        ->assertSee('value="Bapak Sri Purwadi"', false)
        ->assertSee('name="instructor_details[agenda][17][activity]"', false)
        ->assertDontSee('name="offer_items[0][scheme]"', false);

    $this->get(route('letters.create.type', 'other'))
        ->assertOk()
        ->assertSee('name="body"', false)
        ->assertDontSee('name="instructor_details[training_name]"', false)
        ->assertDontSee('name="offer_items[0][scheme]"', false);
    $this->get('/letters/create/unknown')->assertNotFound();
});

test('proposal workflow creates the example letter and all selected appendices', function () {
    $category = DocumentCategory::query()->create([
        'name' => 'Surat',
        'code' => 'SRT',
    ]);

    $this->actingAs(User::factory()->create())
        ->get(route('letters.create.type', 'proposal'))
        ->assertOk()
        ->assertSee('Buat Surat Penawaran')
        ->assertSee('Langkah 1 — Surat Penawaran dan penomoran')
        ->assertSee('Rincian paket penawaran')
        ->assertDontSee('Rincian permohonan instruktur dan rundown');

    $this->post(route('letters.store'), [
        'category_id' => $category->id,
        'letter_type' => 'proposal',
        'full_number' => '004/SRT/VGS/XI/2026',
        'date' => '2026-11-01',
        'subject' => 'Penawaran Pelatihan',
        'body' => 'Isi surat penawaran.',
        'offer_items' => [
            ['scheme' => 'mplb3', 'title' => 'Pelatihan MPLB3', 'schedule' => '12-16 November 2026', 'price' => 4900000],
            ['scheme' => 'oplb3', 'title' => 'Pelatihan OPLB3', 'schedule' => '12-16 November 2026', 'price' => 4900000],
            ['scheme' => 'pppa', 'title' => 'Pelatihan PPPA', 'schedule' => '5-9 November 2026', 'price' => 4900000],
            ['scheme' => 'popal', 'title' => 'Pelatihan POPAL', 'schedule' => '26-30 November 2026', 'price' => 4900000],
        ],
    ])->assertRedirect();

    $letter = Letter::query()->firstOrFail();
    expect($letter->attachment_note)->toBe('4 lampiran')
        ->and($letter->full_number)->toBe('004/SRT/VGS/XI/2026');

    $pdfHtml = view('letters.proposal-pdf', [
        'letter' => $letter,
        'proposalSchemes' => config('proposal_schemes'),
        'textSchemes' => ['pppa', 'popal'],
        'chartSchemes' => ['oplb3', 'mplb3'],
    ])->render();

    expect($letter->letter_type)->toBe('proposal')
        ->and($letter->letter_type_label)->toBe('Surat Penawaran')
        ->and(TemplateRenderer::render('{{jenis_surat}}', $letter))->toBe('Surat Penawaran')
        ->and($pdfHtml)->toContain('Manager Pengumpulan Limbah B3')
        ->and($pdfHtml)->toContain('Penanggung Jawab Pengendalian Pencemaran Air')
        ->and($pdfHtml)->toContain('Dokumen Persyaratan')
        ->and(substr_count($pdfHtml, 'data:image/jpeg;base64,'))->toBe(4)
        ->and($pdfHtml)->toContain('12-16 November 2026')
        ->and($pdfHtml)->toContain('Rp 4.900.000')
        ->and($pdfHtml)->toContain('004/SRT/VGS/XI/2026')
        ->and($pdfHtml)->toContain('Syarat dan Kondisi');

    $this->get(route('letters.show', $letter))
        ->assertOk()
        ->assertSee('Surat Penawaran');
    $pdfResponse = $this->get(route('letters.pdf', $letter))
        ->assertOk()
        ->assertHeader('content-type', 'application/pdf');
    $pdfContent = $pdfResponse->getContent();
    preg_match_all('/\/Type\s*\/Page\b/', $pdfContent, $pdfPages);
    preg_match_all('/\/Subtype\s*\/Image\b/', $pdfContent, $pdfImages);
    expect(count($pdfPages[0]))->toBe(5);
    expect(count($pdfImages[0]))->toBeGreaterThanOrEqual(4);

    $wordResponse = $this->post(route('letters.export.docx', $letter));
    $wordResponse->assertOk()
        ->assertHeader(
            'content-type',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        );

    $temporaryDocx = tempnam(sys_get_temp_dir(), 'proposal-docx-');
    expect($temporaryDocx)->not->toBeFalse();

    try {
        file_put_contents($temporaryDocx, $wordResponse->streamedContent());
        $archive = new ZipArchive;
        $archiveOpened = $archive->open($temporaryDocx) === true;

        expect($archiveOpened)->toBeTrue();
        $documentXml = $archive->getFromName('word/document.xml');
        expect($documentXml)->toContain('Manager Pengumpulan Limbah B3')
            ->and($documentXml)->toContain('Penanggung Jawab Pengendalian Pencemaran Air')
            ->and($documentXml)->toContain('Dokumen Persyaratan')
            ->and($documentXml)->toContain('004/SRT/VGS/XI/2026')
            ->and($documentXml)->toContain('12-16 November 2026')
            ->and($documentXml)->toContain('4.900.000');
        $mediaFiles = [];
        for ($index = 0; $index < $archive->numFiles; $index++) {
            $name = $archive->getNameIndex($index);
            if (str_starts_with($name, 'word/media/')) {
                $mediaFiles[] = $name;
            }
        }
        expect(count($mediaFiles))->toBeGreaterThanOrEqual(4);
    } finally {
        if (isset($archive) && $archiveOpened) {
            $archive->close();
        }

        unlink($temporaryDocx);
    }

    $this->get(route('letters.edit', $letter))
        ->assertOk()
        ->assertSee('value="proposal" selected', false)
        ->assertSee('name="full_number" class="form-control" value="004/SRT/VGS/XI/2026"', false)
        ->assertSee('name="offer_items[0][scheme]"', false)
        ->assertSee('name="offer_items[0][title]"', false);

    $this->put(route('letters.update', $letter), [
        'category_id' => $category->id,
        'full_number' => '005/SRT/VGS/XI/2026',
        'letter_type' => 'proposal',
        'date' => '2026-11-01',
        'subject' => 'Penawaran Pelatihan',
        'offer_items' => [
            ['scheme' => 'custom', 'title' => 'Pelatihan Skema Khusus', 'schedule' => '12-16 November 2026', 'price' => 4900000],
            ['scheme' => 'oplb3', 'title' => 'Pelatihan OPLB3', 'schedule' => '12-16 November 2026', 'price' => 4900000],
            ['scheme' => 'pppa', 'title' => 'Pelatihan PPPA', 'schedule' => '5-9 November 2026', 'price' => 4900000],
            ['scheme' => 'popal', 'title' => 'Pelatihan POPAL', 'schedule' => '26-30 November 2026', 'price' => 4900000],
        ],
    ])->assertRedirect(route('letters.show', $letter));

    expect($letter->fresh()->full_number)->toBe('005/SRT/VGS/XI/2026')
        ->and($letter->fresh()->offer_items[0]['scheme'])->toBe('custom')
        ->and($letter->fresh()->offer_items[0]['title'])->toBe('Pelatihan Skema Khusus');
    $customPdfHtml = view('letters.proposal-pdf', [
        'letter' => $letter->fresh(),
        'proposalSchemes' => config('proposal_schemes'),
        'textSchemes' => ['pppa', 'popal'],
        'chartSchemes' => ['oplb3', 'mplb3'],
    ])->render();
    expect($customPdfHtml)->toContain('Pelatihan Skema Khusus')
        ->and($customPdfHtml)->toContain('005/SRT/VGS/XI/2026');
    $this->get(route('letters.show', $letter))
        ->assertOk()
        ->assertSee('Pelatihan Skema Khusus');

    $this->put(route('letters.update', $letter), [
        'category_id' => $category->id,
        'full_number' => '005/SRT/VGS/XI/2026',
        'letter_type' => 'instructor_request',
        'date' => '2026-11-01',
        'subject' => 'Permohonan Instruktur',
    ])->assertRedirect(route('letters.show', $letter));

    expect($letter->fresh()->letter_type_label)->toBe('Surat Permohonan Instruktur');
});

test('letter type must be one of the configured choices', function () {
    $category = DocumentCategory::query()->create([
        'name' => 'Surat',
        'code' => 'SRT',
    ]);

    $this->actingAs(User::factory()->create())
        ->from(route('letters.create'))
        ->post(route('letters.store'), [
            'category_id' => $category->id,
            'letter_type' => 'unknown',
            'date' => '2026-11-01',
            'subject' => 'Surat',
        ])
        ->assertRedirect(route('letters.create'))
        ->assertSessionHasErrors('letter_type');

    $this->from(route('letters.create'))
        ->post(route('letters.store'), [
            'category_id' => $category->id,
            'letter_type' => 'proposal',
            'date' => '2026-11-01',
            'subject' => 'Surat Penawaran',
        ])
        ->assertRedirect(route('letters.create'))
        ->assertSessionHasErrors('offer_items');
});

test('proposal packages require a valid scheme and training schedule', function () {
    $category = DocumentCategory::query()->create([
        'name' => 'Surat',
        'code' => 'SRT-TEST',
    ]);

    $this->actingAs(User::factory()->create())
        ->from(route('letters.create'))
        ->post(route('letters.store'), [
            'category_id' => $category->id,
            'letter_type' => 'proposal',
            'date' => '2026-11-01',
            'subject' => 'Penawaran',
            'offer_items' => [
                ['scheme' => 'unknown', 'schedule' => '', 'price' => 1000000],
            ],
        ])
        ->assertRedirect(route('letters.create'))
        ->assertSessionHasErrors([
            'offer_items.0.scheme',
            'offer_items.0.schedule',
        ]);
});

test('legacy proposal package titles are editable as scheme choices', function () {
    $category = DocumentCategory::query()->where('code', 'SRT')->firstOrFail();
    $letter = Letter::query()->create([
        'category_id' => $category->id,
        'number' => 1,
        'full_number' => 'LEGACY/001',
        'date' => '2026-11-01',
        'subject' => 'Penawaran lama',
        'letter_type' => 'proposal',
        'offer_items' => [
            [
                'title' => 'Pelatihan Skema Penanggung Jawab Operasional Pengolahan Air Limbah (POPAL) Sertifikasi BNSP',
                'schedule' => 'Desember 2026',
                'price' => 1000000,
            ],
        ],
    ]);

    $this->actingAs(User::factory()->create())
        ->get(route('letters.edit', $letter))
        ->assertOk()
        ->assertSee('value="popal" data-package=', false)
        ->assertSee('name="offer_items[0][title]"', false)
        ->assertSee('LEGACY/001');
});

test('default letter templates and exports follow the selected letter type', function () {
    $category = DocumentCategory::query()->create([
        'name' => 'Surat',
        'code' => 'SRT',
    ]);
    $template = LetterTemplate::query()->create([
        'letter_type' => 'instructor_request',
        'name' => 'Format Permohonan Instruktur',
        'content' => '<p>{{jenis_surat}} untuk {{nama_penerima}}</p>',
        'is_default' => true,
    ]);

    $this->actingAs(User::factory()->create())
        ->post(route('letters.store'), [
            'category_id' => $category->id,
            'letter_type' => 'instructor_request',
            'date' => '2026-11-01',
            'subject' => 'Permohonan Instruktur',
            'recipient_name' => 'Budi Santoso',
            'body' => 'Isi surat.',
        ])
        ->assertRedirect();

    $letter = Letter::query()->firstOrFail();
    $this->get(route('letters.show', $letter))
        ->assertOk()
        ->assertSee('Surat Permohonan Instruktur untuk Budi Santoso', false);
    $this->get(route('letters.pdf', $letter))
        ->assertOk()
        ->assertHeader('content-type', 'application/pdf');
    $this->get(route('letters.export.pdf', $letter))
        ->assertOk()
        ->assertHeader('content-type', 'application/pdf');

    $wordResponse = $this->post(route('letters.export.docx', $letter))
        ->assertOk()
        ->assertHeader(
            'content-type',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        );
    $temporaryDocx = tempnam(sys_get_temp_dir(), 'letter-docx-');
    expect($temporaryDocx)->not->toBeFalse();

    try {
        file_put_contents($temporaryDocx, $wordResponse->streamedContent());
        $archive = new ZipArchive;
        $archiveOpened = $archive->open($temporaryDocx) === true;
        expect($archiveOpened)->toBeTrue()
            ->and($archive->getFromName('word/document.xml'))->toContain('Surat Permohonan Instruktur untuk Budi Santoso');
    } finally {
        if (isset($archive) && $archiveOpened) {
            $archive->close();
        }

        unlink($temporaryDocx);
    }

    $this->from(route('letters.create'))
        ->post(route('letters.store'), [
            'category_id' => $category->id,
            'letter_type' => 'proposal',
            'template_id' => $template->id,
            'date' => '2026-11-01',
            'subject' => 'Penawaran',
            'offer_items' => [
                ['scheme' => 'mplb3', 'title' => 'Pelatihan MPLB3', 'schedule' => 'Desember', 'price' => 1000000],
            ],
        ])
        ->assertRedirect(route('letters.create'))
        ->assertSessionHasErrors('template_id');
});

test('docx template renderer escapes XML characters in replacement values', function () {
    $templatesPath = storage_path('app/public/templates');
    if (! is_dir($templatesPath)) {
        mkdir($templatesPath, 0755, true);
    }

    $templatePath = $templatesPath.DIRECTORY_SEPARATOR.'xml-escape-'.uniqid().'.docx';
    $phpWord = new PhpWord;
    $phpWord->addSection()->addText('${subject}');
    IOFactory::createWriter($phpWord, 'Word2007')->save($templatePath);

    try {
        $html = (new DocxTemplateRenderer)->renderToHtml(
            basename($templatePath),
            ['subject' => 'Diskusi & Pembahasan'],
        );

        expect($html)->toContain('Diskusi &amp; Pembahasan');
    } finally {
        unlink($templatePath);
    }
});

test('instructor request letters generate the invitation and editable training rundown', function () {
    $category = DocumentCategory::query()->create([
        'name' => 'Surat',
        'code' => 'SRT-INSTR',
    ]);
    $agenda = config('instructor_request.defaults.details.agenda');
    for ($index = 1; $index < count($agenda); $index++) {
        if ($agenda[$index]['day'] === '') {
            $agenda[$index]['day'] = $agenda[$index - 1]['day'];
        }
    }

    $payload = [
        'category_id' => $category->id,
        'letter_type' => 'instructor_request',
        'full_number' => '012/SRT/VGS/XI/2026',
        'date' => '2026-11-12',
        'subject' => 'Permohonan Menjadi Instruktur',
        'recipient_name' => 'Bapak Sri Purwadi',
        'recipient_title' => 'Instruktur',
        'signer_name' => 'Abdul Darda, S.H., M.H.',
        'signer_title' => 'Direktur Utama',
        'instructor_details' => [
            'training_name' => 'Pelatihan Ahli Hygiene Industri Muda (HIMU) Sertifikasi BNSP',
            'training_schedule' => 'Selasa - Rabu, 3-4 November 2026',
            'training_time' => '08.30 - 16.00 WIB',
            'training_place' => 'Zoom Meeting',
            'agenda' => $agenda,
        ],
    ];

    $this->actingAs(User::factory()->create())
        ->get(route('letters.create.type', 'instructor_request'))
        ->assertOk()
        ->assertSee('Rincian permohonan instruktur dan rundown')
        ->assertSee('instructor_details[training_name]', false)
        ->assertSee('instructor_details[agenda]', false)
        ->assertDontSee('name="offer_items[0][scheme]"', false);

    $this->post(route('letters.store'), $payload)->assertRedirect();
    $letter = Letter::query()->firstOrFail();

    expect($letter->instructor_details['training_name'])
        ->toBe('Pelatihan Ahli Hygiene Industri Muda (HIMU) Sertifikasi BNSP')
        ->and($letter->attachment_note)->toBe('Rundown pelatihan');

    $this->get(route('letters.show', $letter))
        ->assertOk()
        ->assertSee('Rincian pelatihan')
        ->assertSee('Selasa, 3 November 2026')
        ->assertSee('Melakukan Pekerjaan Higiene Industri Secara Professional');

    $pdfResponse = $this->get(route('letters.pdf', $letter))
        ->assertOk()
        ->assertHeader('content-type', 'application/pdf');
    $pdfContent = $pdfResponse->getContent();
    preg_match_all('/\/Subtype\s*\/Image\b/', $pdfContent, $pdfImages);
    preg_match_all('/\/Type\s*\/Page\b/', $pdfContent, $pdfPages);
    expect(count($pdfImages[0]))->toBeGreaterThanOrEqual(2);
    expect(count($pdfPages[0]))->toBe(2);

    $pdfDownload = $this->get(route('letters.export.pdf', $letter))
        ->assertOk()
        ->assertHeader('content-type', 'application/pdf')
        ->assertHeader('content-disposition', 'attachment; filename="surat-permohonan-instruktur-'.$letter->id.'.pdf"');
    preg_match_all('/\/Type\s*\/Page\b/', $pdfDownload->getContent(), $downloadPages);
    expect(count($downloadPages[0]))->toBe(2);

    $wordResponse = $this->post(route('letters.export.docx', $letter))->assertOk();
    $temporaryDocx = tempnam(sys_get_temp_dir(), 'instructor-docx-');
    expect($temporaryDocx)->not->toBeFalse();

    try {
        file_put_contents($temporaryDocx, $wordResponse->streamedContent());
        $archive = new ZipArchive;
        $archiveOpened = $archive->open($temporaryDocx) === true;
        expect($archiveOpened)->toBeTrue();
        $documentXml = $archive->getFromName('word/document.xml');
        preg_match_all('/<w:tr(?:\s|>)/', $documentXml, $tableRows);
        $document = new DOMDocument;
        $document->loadXML($documentXml);
        $xpath = new DOMXPath($document);
        $wordNamespace = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
        $xpath->registerNamespace('w', $wordNamespace);
        $rows = $xpath->query('//w:tbl/w:tr');
        $firstDayMerge = $xpath->query('./w:tc[2]/w:tcPr/w:vMerge', $rows->item(1))->item(0);
        $continuedDayMerge = $xpath->query('./w:tc[2]/w:tcPr/w:vMerge', $rows->item(2))->item(0);
        $separatorCells = $xpath->query('./w:tc/w:tcPr/w:shd[@w:fill="92D050"]', $rows->item(10));
        expect($documentXml)
            ->toContain('HIMU) Sertifikasi BNSP')
            ->toContain('Zoom Meeting')
            ->toContain('RUNDOWN PELATIHAN')
            ->toContain('Melakukan Pekerjaan Higiene Industri Secara Professional')
            ->toContain('Diskusi &amp; Pembahasan')
            ->toContain('Bapak Sri Purwadi')
            ->toContain('w:sz w:val="24"')
            ->toContain('w:pgMar')
            ->and(count($tableRows[0]))->toBe(count($payload['instructor_details']['agenda']) + 2)
            ->and($firstDayMerge->getAttributeNS($wordNamespace, 'val'))->toBe('restart')
            ->and($continuedDayMerge->getAttributeNS($wordNamespace, 'val'))->toBe('continue')
            ->and($separatorCells->length)->toBe(5)
            ->and($archive->getFromName('word/header1.xml'))->toContain('r:embed="rId1"')
            ->and($archive->getFromName('word/footer1.xml'))->toContain('r:embed="rId1"');
        expect($archive->getFromName('word/styles.xml'))->toContain('Times New Roman');

        $convertedHtml = (new DocxTemplateRenderer)->renderDocumentToHtml($temporaryDocx);
        expect($convertedHtml)
            ->toContain("font-family: 'Times New Roman'")
            ->toContain('12pt')
            ->toContain('data:image/');
    } finally {
        if (isset($archive) && $archiveOpened) {
            $archive->close();
        }

        unlink($temporaryDocx);
    }

    $this->get(route('letters.edit', $letter))
        ->assertOk()
        ->assertSee('value="Selasa - Rabu, 3-4 November 2026"', false)
        ->assertSee('name="instructor_details[agenda][0][activity]"', false);

    $payload['instructor_details']['training_place'] = 'Ruang Pelatihan Veritrust';
    $payload['instructor_details']['agenda'][0]['activity'] = 'Materi diperbarui';
    $this->put(route('letters.update', $letter), $payload)
        ->assertRedirect(route('letters.show', $letter));
    expect($letter->fresh()->instructor_details['training_place'])
        ->toBe('Ruang Pelatihan Veritrust')
        ->and($letter->fresh()->instructor_details['agenda'][0]['activity'])
        ->toBe('Materi diperbarui');
});

test('letters can be deleted from the list after confirmation', function () {
    $category = DocumentCategory::query()->create([
        'name' => 'Surat',
        'code' => 'SRT-DELETE',
    ]);
    $letter = Letter::query()->create([
        'category_id' => $category->id,
        'full_number' => 'DELETE/001',
        'date' => '2026-11-02',
        'subject' => 'Surat untuk dihapus',
        'letter_type' => 'other',
        'status' => 'draft',
    ]);

    $this->actingAs(User::factory()->create())
        ->get(route('letters.index'))
        ->assertOk()
        ->assertSee(route('letters.destroy', $letter), false)
        ->assertSee('Yakin ingin menghapus surat ini?', false)
        ->assertSee('name="_method" value="DELETE"', false);

    $this->delete(route('letters.destroy', $letter))
        ->assertRedirect(route('letters.index'))
        ->assertSessionHas('success', 'Surat berhasil dihapus.');

    $this->assertDatabaseMissing('letters', ['id' => $letter->id]);
    $this->get(route('letters.index'))
        ->assertOk()
        ->assertSee('Surat berhasil dihapus.');
});
