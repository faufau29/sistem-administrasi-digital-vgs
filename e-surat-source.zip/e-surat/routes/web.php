<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SequenceController;
use App\Http\Controllers\AuthController;

Route::get('/', function () {
    if (auth()->check()) {
        return redirect('/dashboard');
    }
    return redirect('/login');
});

Route::post('/api/sequence/next', [SequenceController::class, 'generate'])->middleware('auth');

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/register', [AuthController::class, 'showRegistrationForm'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
});

Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth');

Route::get('/dashboard', [App\Http\Controllers\DocumentController::class, 'dashboard'])->middleware('auth');

// Category & Template management
use App\Http\Controllers\DocumentCategoryController;
use App\Http\Controllers\LetterTemplateController;
use App\Http\Controllers\LetterController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\ReceiptController;
use App\Http\Controllers\ImportController;
use App\Http\Controllers\ReportController;

Route::middleware('auth')->group(function () {
    Route::get('reports/monthly', [ReportController::class, 'monthly'])->name('reports.monthly');
    Route::get('reports/monthly/pdf', [ReportController::class, 'monthlyPdf'])->name('reports.monthly.pdf');
    Route::get('letters/create/{letterType}', [LetterController::class, 'create'])->name('letters.create.type');
    Route::resource('letters', LetterController::class);
    Route::get('letters/{letter}/pdf', [LetterController::class, 'pdf'])->name('letters.pdf');
    Route::get('letters-export', [LetterController::class, 'export'])->name('letters.export');
    Route::resource('invoices', InvoiceController::class);
    Route::get('invoices/{invoice}/pdf', [InvoiceController::class, 'pdf'])->name('invoices.pdf');
    Route::get('invoices/{invoice}/word', [InvoiceController::class, 'word'])->name('invoices.word');
    Route::get('invoices-export', [InvoiceController::class, 'export'])->name('invoices.export');
    Route::resource('receipts', ReceiptController::class);
    Route::get('receipts/{receipt}/pdf', [ReceiptController::class, 'pdf'])->name('receipts.pdf');
    Route::get('receipts/{receipt}/word', [ReceiptController::class, 'word'])->name('receipts.word');
    Route::get('receipts-export', [ReceiptController::class, 'export'])->name('receipts.export');
    Route::post('letters/{letter}/export-docx', [App\Http\Controllers\LetterController::class, 'exportDocx'])->name('letters.export.docx');
    Route::get('letters/{letter}/export-pdf', [App\Http\Controllers\LetterController::class, 'exportPdf'])->name('letters.export.pdf');
    Route::get('imports', [ImportController::class, 'index'])->name('imports.index')->middleware('role:admin|direktur');
    Route::post('imports/upload', [ImportController::class, 'upload'])->name('imports.upload')->middleware('role:admin|direktur');
});

Route::resource('categories', DocumentCategoryController::class)->middleware(['auth','role:admin|direktur']);
Route::resource('templates', LetterTemplateController::class)->middleware(['auth','role:admin|direktur']);
