@extends('layouts.app')

@section('title', 'Laporan Bulanan')

@section('content')
<style>
    .report-page {
        --report-ink: #2b194b;
        --report-muted: #786e8b;
        --report-line: #e9e2f2;
        --report-purple: #7136bd;
        --report-lilac: #f3edfb;
    }

    .report-hero {
        position: relative;
        display: flex;
        min-height: 190px;
        align-items: center;
        justify-content: space-between;
        gap: 1.5rem;
        overflow: hidden;
        margin-bottom: 1.35rem;
        padding: 2rem clamp(1.25rem, 4vw, 2.5rem);
        border: 1px solid rgba(255, 255, 255, .16);
        border-radius: 22px;
        background:
            radial-gradient(ellipse at 92% 10%, rgba(183, 133, 255, .33), transparent 25rem),
            linear-gradient(112deg, #1a0648 0%, #310879 58%, #50119a 100%);
        box-shadow: 0 16px 34px rgba(47, 21, 86, .16);
        color: #fff;
    }

    .report-hero::after {
        position: absolute;
        right: 24%;
        bottom: -96px;
        width: 240px;
        height: 240px;
        border: 1px solid rgba(255, 255, 255, .11);
        border-radius: 50%;
        content: "";
        pointer-events: none;
    }

    .report-hero-copy,
    .report-hero-actions {
        position: relative;
        z-index: 1;
    }

    .report-eyebrow {
        margin-bottom: .65rem;
        color: #f5c842;
        font-size: .73rem;
        font-weight: 750;
        letter-spacing: .14em;
        text-transform: uppercase;
    }

    .report-title {
        margin: 0;
        color: #fff !important;
        font-size: clamp(1.65rem, 3.5vw, 2.3rem);
        font-weight: 800;
        letter-spacing: -.04em;
    }

    .report-description {
        max-width: 560px;
        margin: .55rem 0 0;
        color: rgba(255, 255, 255, .78);
        font-size: .93rem;
        line-height: 1.55;
    }

    .report-hero-actions {
        display: flex;
        flex: 0 0 auto;
        flex-wrap: wrap;
        gap: .65rem;
    }

    .report-hero-actions .btn {
        min-height: 42px;
        padding: .6rem .9rem;
    }

    .report-btn-light {
        border: 1px solid rgba(255, 255, 255, .85);
        background: #fff;
        color: #4a237d;
    }

    .report-btn-light:hover {
        border-color: #f5c842;
        background: #fff8df;
        color: #3a1c63;
    }

    .report-btn-outline {
        border: 1px solid rgba(255, 255, 255, .46);
        background: rgba(255, 255, 255, .08);
        color: #fff;
    }

    .report-btn-outline:hover {
        border-color: #f5c842;
        background: rgba(255, 255, 255, .16);
        color: #fff;
    }

    .report-summary {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 1rem;
        margin-bottom: 1.25rem;
    }

    .report-summary-card {
        display: flex;
        min-height: 112px;
        align-items: center;
        gap: .95rem;
        padding: 1.15rem 1.3rem;
        border: 1px solid var(--report-line);
        border-radius: 16px;
        background: #fff;
        box-shadow: 0 6px 18px rgba(47, 21, 86, .045);
    }

    .report-summary-icon {
        display: grid;
        width: 44px;
        height: 44px;
        flex: 0 0 auto;
        place-items: center;
        border-radius: 13px;
        background: var(--report-lilac);
        color: var(--report-purple);
    }

    .report-summary-icon.gold {
        background: #fff5d8;
        color: #9a6a00;
    }

    .report-summary-icon svg {
        width: 22px;
        height: 22px;
    }

    .report-summary-label {
        margin-bottom: .2rem;
        color: var(--report-muted);
        font-size: .82rem;
        font-weight: 600;
    }

    .report-summary-value {
        color: var(--report-ink);
        font-size: 1.65rem;
        font-weight: 800;
        letter-spacing: -.04em;
        line-height: 1.15;
    }

    .report-filter {
        display: flex;
        align-items: end;
        justify-content: space-between;
        gap: 1rem;
        margin-bottom: 1.2rem;
        padding: 1rem 1.2rem;
        border: 1px solid var(--report-line);
        border-radius: 15px;
        background: #fff;
    }

    .report-filter-copy {
        color: var(--report-muted);
        font-size: .84rem;
        line-height: 1.5;
    }

    .report-filter-copy strong {
        display: block;
        margin-bottom: .15rem;
        color: var(--report-ink);
        font-size: .94rem;
    }

    .report-filter-form {
        display: flex;
        align-items: end;
        gap: .6rem;
    }

    .report-filter-form label {
        display: block;
        margin-bottom: .3rem;
        color: #49316b;
        font-size: .78rem;
        font-weight: 700;
    }

    .report-filter-form .form-control {
        width: 118px;
    }

    .report-table-card {
        overflow: hidden;
        border: 1px solid var(--report-line);
        border-radius: 18px;
        background: #fff;
        box-shadow: 0 8px 24px rgba(47, 21, 86, .055);
    }

    .report-table-heading {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        padding: 1.1rem 1.25rem;
        border-bottom: 1px solid var(--report-line);
    }

    .report-table-heading h2 {
        margin: 0;
        color: var(--report-ink);
        font-size: 1rem;
        font-weight: 750;
    }

    .report-table-heading p {
        margin: .22rem 0 0;
        color: var(--report-muted);
        font-size: .8rem;
    }

    .report-period {
        flex: 0 0 auto;
        padding: .38rem .7rem;
        border: 1px solid #e6daf3;
        border-radius: 999px;
        background: #f8f4fc;
        color: #5a3786;
        font-size: .78rem;
        font-weight: 700;
    }

    .report-table-wrap {
        overflow-x: auto;
    }

    .report-table {
        min-width: 650px;
        margin: 0 !important;
    }

    .report-table thead th {
        padding: .85rem 1rem !important;
        border: 0 !important;
        background: #f6f1fb !important;
        color: #5b4478 !important;
        font-size: .76rem !important;
        letter-spacing: .025em;
        text-transform: uppercase;
    }

    .report-table tbody th,
    .report-table tbody td {
        padding: .7rem 1rem !important;
        border-color: #f0ebf5 !important;
        vertical-align: middle;
    }

    .report-table tbody tr:hover {
        background: #fcfaff;
    }

    .report-month {
        width: 19%;
        color: var(--report-ink);
        font-weight: 650;
    }

    .report-count {
        width: 19%;
        color: #49316b;
        font-weight: 650;
    }

    .report-count.total {
        color: var(--report-purple);
        font-weight: 750;
    }

    .report-bar-cell {
        width: 31%;
    }

    .report-bar-track {
        height: 8px;
        overflow: hidden;
        border-radius: 99px;
        background: #f0ebf5;
    }

    .report-bar-fill {
        height: 100%;
        min-width: 0;
        border-radius: inherit;
        background: linear-gradient(90deg, #8b5cf6, #55218c);
    }

    .report-table tfoot th,
    .report-table tfoot td {
        padding: .9rem 1rem !important;
        border: 0 !important;
        border-top: 2px solid #dfd1ee !important;
        background: #f7f2fc !important;
        color: #382254;
        font-size: .9rem;
        font-weight: 800;
    }

    .report-table tfoot .total-highlight {
        color: #5d2798;
        font-size: 1rem;
    }

    .report-note {
        margin: .85rem 0 0;
        color: var(--report-muted);
        font-size: .78rem;
    }

    @media (max-width: 767.98px) {
        .report-hero {
            align-items: flex-start;
            flex-direction: column;
            padding: 1.5rem 1.25rem;
        }

        .report-hero-actions {
            width: 100%;
        }

        .report-hero-actions .btn {
            flex: 1 1 auto;
        }

        .report-summary {
            grid-template-columns: 1fr;
            gap: .7rem;
        }

        .report-summary-card {
            min-height: 88px;
        }

        .report-filter {
            align-items: flex-start;
            flex-direction: column;
        }

        .report-filter-form {
            width: 100%;
        }

        .report-filter-form .form-control {
            flex: 1;
            width: auto;
        }
    }

    @media print {
        body {
            background: #fff !important;
        }

        .app-header,
        .report-hero-actions,
        .report-filter {
            display: none !important;
        }

        .app-main {
            min-height: 0 !important;
            padding: 0 !important;
        }

        .report-hero {
            min-height: 0;
            margin-bottom: 12px;
            padding: 16px 20px;
            border-radius: 10px;
            background: #310879 !important;
            box-shadow: none;
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
        }

        .report-title {
            font-size: 21px;
        }

        .report-description {
            font-size: 10px;
        }

        .report-summary {
            gap: 8px;
            margin-bottom: 12px;
        }

        .report-summary-card {
            min-height: 70px;
            padding: 9px;
            box-shadow: none;
        }

        .report-summary-icon {
            width: 34px;
            height: 34px;
        }

        .report-table-card {
            box-shadow: none;
        }

        .report-table {
            min-width: 0;
        }

        .report-bar-cell,
        .report-table-heading p,
        .report-note {
            display: none;
        }

        .report-table thead th,
        .report-table tfoot th,
        .report-table tfoot td {
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
        }
    }
</style>

@php($maxMonthlyTotal = max(1, $monthlyReports->max('total_count')))

<div class="container report-page">
    <header class="report-hero">
        <div class="report-hero-copy">
            <div class="report-eyebrow">Analisis dokumen</div>
            <h1 class="report-title">Laporan Bulanan Invoice &amp; Kwitansi</h1>
            <p class="report-description">Pantau penerbitan invoice dan kwitansi sepanjang tahun {{ $year }} dalam satu ringkasan.</p>
        </div>
        <div class="report-hero-actions">
            <a href="{{ route('reports.monthly.pdf', ['year' => $year]) }}" class="btn report-btn-light">Unduh PDF</a>
            <button type="button" class="btn report-btn-outline" onclick="window.print()">Cetak laporan</button>
        </div>
    </header>

    <section class="report-summary" aria-label="Ringkasan tahunan">
        <article class="report-summary-card">
            <span class="report-summary-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                    <path d="M7 3.75h7l4.25 4.5v12H7a2 2 0 0 1-2-2v-12a2.5 2.5 0 0 1 2-2.5Z"/>
                    <path d="M14 4v5h4M8.5 13h7M8.5 16.5h7"/>
                </svg>
            </span>
            <div>
                <div class="report-summary-label">Invoice diterbitkan</div>
                <div class="report-summary-value">{{ number_format($totalInvoices, 0, ',', '.') }}</div>
            </div>
        </article>
        <article class="report-summary-card">
            <span class="report-summary-icon gold" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                    <path d="M5 5.5h14v13H5zM8 9h8M8 12.5h5"/>
                    <path d="m14 16 1.5 1.5L19 14"/>
                </svg>
            </span>
            <div>
                <div class="report-summary-label">Kwitansi diterbitkan</div>
                <div class="report-summary-value">{{ number_format($totalReceipts, 0, ',', '.') }}</div>
            </div>
        </article>
        <article class="report-summary-card">
            <span class="report-summary-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                    <path d="M4 19V5m0 14h16M8 15v-4m4 4V7m4 8V9m4 6V5"/>
                </svg>
            </span>
            <div>
                <div class="report-summary-label">Total dokumen tahun {{ $year }}</div>
                <div class="report-summary-value">{{ number_format($totalDocuments, 0, ',', '.') }}</div>
            </div>
        </article>
    </section>

    <section class="report-filter" aria-label="Filter laporan">
        <div class="report-filter-copy">
            <strong>Periode laporan</strong>
            Jumlah dokumen dihitung dari tanggal yang tercantum pada dokumen.
        </div>
        <form class="report-filter-form" method="GET" action="{{ route('reports.monthly') }}">
            <div>
                <label for="year">Tahun</label>
                <input id="year" type="number" name="year" value="{{ $year }}" class="form-control"
                       min="1900" max="9999" required>
            </div>
            <button class="btn btn-primary" type="submit">Tampilkan</button>
        </form>
    </section>

    <section class="report-table-card" aria-labelledby="monthly-table-title">
        <div class="report-table-heading">
            <div>
                <h2 id="monthly-table-title">Rincian per bulan</h2>
                <p>Perbandingan jumlah invoice, kwitansi, dan total dokumen.</p>
            </div>
            <span class="report-period">Januari – Desember {{ $year }}</span>
        </div>
        <div class="report-table-wrap">
            <table class="table table-striped align-middle report-table">
                <thead>
                    <tr>
                        <th scope="col">Bulan</th>
                        <th scope="col" class="text-end">Invoice</th>
                        <th scope="col" class="text-end">Kwitansi</th>
                        <th scope="col" class="text-end">Total</th>
                        <th scope="col" class="report-bar-cell">Aktivitas bulanan</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($monthlyReports as $report)
                        <tr>
                            <th scope="row" class="report-month">{{ $report['month_name'] }}</th>
                            <td class="text-end report-count">{{ number_format($report['invoice_count'], 0, ',', '.') }}</td>
                            <td class="text-end report-count">{{ number_format($report['receipt_count'], 0, ',', '.') }}</td>
                            <td class="text-end report-count total">{{ number_format($report['total_count'], 0, ',', '.') }}</td>
                            <td class="report-bar-cell">
                                <div class="report-bar-track" role="img"
                                     aria-label="{{ $report['total_count'] }} dokumen pada {{ $report['month_name'] }}">
                                    <div class="report-bar-fill"
                                         style="width: {{ ($report['total_count'] / $maxMonthlyTotal) * 100 }}%"></div>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
                <tfoot>
                    <tr>
                        <th scope="row">Total {{ $year }}</th>
                        <td class="text-end">{{ number_format($totalInvoices, 0, ',', '.') }}</td>
                        <td class="text-end">{{ number_format($totalReceipts, 0, ',', '.') }}</td>
                        <td class="text-end total-highlight">{{ number_format($totalDocuments, 0, ',', '.') }}</td>
                        <td class="report-bar-cell"></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </section>
    <p class="report-note">Laporan ini merangkum dokumen berdasarkan tanggal penerbitannya.</p>
</div>
@endsection
