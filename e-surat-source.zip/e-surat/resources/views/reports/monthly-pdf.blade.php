<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Laporan Bulanan Invoice &amp; Kwitansi {{ $year }}</title>
    <style>
        @page {
            margin: 30px 34px;
        }

        body {
            color: #33234d;
            font-family: DejaVu Sans, sans-serif;
            font-size: 10px;
        }

        .hero {
            width: 100%;
            margin-bottom: 16px;
            border-collapse: separate;
            border-spacing: 0;
            background: #310879;
            color: #fff;
        }

        .hero td {
            padding: 20px 22px;
        }

        .eyebrow {
            margin-bottom: 7px;
            color: #f5c842;
            font-size: 8px;
            font-weight: bold;
            letter-spacing: 1.4px;
            text-transform: uppercase;
        }

        h1 {
            margin: 0;
            color: #fff;
            font-size: 21px;
        }

        .description {
            margin: 7px 0 0;
            color: #e6d9f7;
            font-size: 9px;
        }

        .year-badge {
            width: 86px;
            border-left: 1px solid #67419c;
            color: #f5c842;
            font-size: 20px;
            font-weight: bold;
            text-align: center;
        }

        .summary {
            width: 100%;
            margin-bottom: 16px;
            border-collapse: separate;
            border-spacing: 8px 0;
        }

        .summary td {
            width: 33.33%;
            padding: 11px 13px;
            border: 1px solid #e9e2f2;
            background: #faf8fd;
        }

        .summary-label {
            margin-bottom: 5px;
            color: #786e8b;
            font-size: 8px;
        }

        .summary-value {
            color: #382254;
            font-size: 17px;
            font-weight: bold;
        }

        .section-heading {
            margin: 0 0 8px;
            color: #382254;
            font-size: 12px;
        }

        .section-description {
            margin: 0 0 10px;
            color: #786e8b;
            font-size: 8px;
        }

        .report-table {
            width: 100%;
            border-collapse: collapse;
        }

        .report-table th,
        .report-table td {
            padding: 7px 9px;
            border-bottom: 1px solid #e9e2f2;
        }

        .report-table thead th {
            border: 0;
            background: #f1eafa;
            color: #49316b;
            font-size: 8px;
            text-align: left;
        }

        .report-table thead th.number,
        .report-table tbody td.number,
        .report-table tfoot td.number {
            text-align: right;
        }

        .report-table tbody tr:nth-child(even) td {
            background: #fcfaff;
        }

        .report-table tbody td {
            color: #493d5c;
        }

        .report-table tbody td.month {
            color: #33234d;
            font-weight: bold;
        }

        .report-table tfoot th,
        .report-table tfoot td {
            border-top: 2px solid #cbb5e5;
            border-bottom: 0;
            background: #f4eefb;
            color: #382254;
            font-weight: bold;
        }

        .report-table tfoot td.total {
            color: #5d2798;
            font-size: 12px;
        }

        .footer {
            margin-top: 12px;
            color: #786e8b;
            font-size: 8px;
        }
    </style>
</head>
<body>
    <table class="hero">
        <tr>
            <td>
                <div class="eyebrow">Analisis dokumen</div>
                <h1>Laporan Bulanan</h1>
                <p class="description">Ringkasan invoice dan kwitansi yang diterbitkan selama satu tahun.</p>
            </td>
            <td class="year-badge">TAHUN<br>{{ $year }}</td>
        </tr>
    </table>

    <table class="summary">
        <tr>
            <td>
                <div class="summary-label">Invoice diterbitkan</div>
                <div class="summary-value">{{ number_format($totalInvoices, 0, ',', '.') }}</div>
            </td>
            <td>
                <div class="summary-label">Kwitansi diterbitkan</div>
                <div class="summary-value">{{ number_format($totalReceipts, 0, ',', '.') }}</div>
            </td>
            <td>
                <div class="summary-label">Total dokumen</div>
                <div class="summary-value">{{ number_format($totalDocuments, 0, ',', '.') }}</div>
            </td>
        </tr>
    </table>

    <h2 class="section-heading">Rincian per bulan</h2>
    <p class="section-description">Jumlah dokumen dihitung berdasarkan tanggal penerbitan yang tercantum pada dokumen.</p>
    <table class="report-table">
        <thead>
            <tr>
                <th>Bulan</th>
                <th class="number">Invoice</th>
                <th class="number">Kwitansi</th>
                <th class="number">Total dokumen</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($monthlyReports as $report)
                <tr>
                    <td class="month">{{ $report['month_name'] }}</td>
                    <td class="number">{{ number_format($report['invoice_count'], 0, ',', '.') }}</td>
                    <td class="number">{{ number_format($report['receipt_count'], 0, ',', '.') }}</td>
                    <td class="number">{{ number_format($report['total_count'], 0, ',', '.') }}</td>
                </tr>
            @endforeach
        </tbody>
        <tfoot>
            <tr>
                <th>Total {{ $year }}</th>
                <td class="number">{{ number_format($totalInvoices, 0, ',', '.') }}</td>
                <td class="number">{{ number_format($totalReceipts, 0, ',', '.') }}</td>
                <td class="number total">{{ number_format($totalDocuments, 0, ',', '.') }}</td>
            </tr>
        </tfoot>
    </table>
    <p class="footer">E-Surat · Laporan tahunan {{ $year }}</p>
</body>
</html>
