@extends('layouts.app')

@section('content')
<div class="container">
    <div class="mb-4">
        <a href="{{ route('letters.create') }}" class="text-decoration-none">&larr; Pilih jenis surat lain</a>
        <h3 class="mt-2 mb-1">Buat {{ $letterTypes[$letterType] }}</h3>
        <p class="text-muted mb-0">Form ini khusus untuk {{ strtolower($letterTypes[$letterType]) }}. Isi data surat, lalu periksa pratinjau dan unduh PDF atau Word.</p>
    </div>

    @if($errors->any())
        <div class="alert alert-danger" role="alert">
            <strong>Surat belum dapat dibuat.</strong> Periksa kembali bagian yang ditandai:
            <ul class="mb-0 mt-1">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ route('letters.store') }}">
        @csrf
        <input type="hidden" id="letter_type" name="letter_type" value="{{ $letterType }}">
        <section class="card mb-4">
            <div class="card-header"><strong>Langkah 1 — {{ $letterTypes[$letterType] }} dan penomoran</strong></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="category">Kategori arsip</label>
                        <select id="category" name="category_id" class="form-select" required>
                            <option value="">-- pilih kategori nomor --</option>
                            @foreach($categories as $c)
                                <option value="{{ $c->id }}" {{ (string) old('category_id', $defaultCategoryId) === (string) $c->id ? 'selected' : '' }}>{{ $c->name }}</option>
                            @endforeach
                        </select>
                        <div class="form-text">Kategori arsip menentukan pola nomor surat. Format isi mengikuti jenis surat yang dipilih.</div>
                        @error('category_id')<div class="text-danger small">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="full_number">Nomor surat</label>
                        <input id="full_number" name="full_number" class="form-control" value="{{ old('full_number') }}" maxlength="255" placeholder="Kosongkan untuk nomor otomatis, atau isi nomor sendiri">
                        <div class="form-text">Contoh input manual: 001/SRT/VGS/XI/2026. Jika kosong, nomor dibuat otomatis.</div>
                        @error('full_number')<div class="text-danger small">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="date">Tanggal surat</label>
                        <input id="date" type="date" name="date" class="form-control" required value="{{ old('date', $letterType === 'instructor_request' ? $instructorDefaults['date'] : date('Y-m-d')) }}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="subject">Perihal</label>
                        <input id="subject" name="subject" class="form-control" required value="{{ old('subject', $letterType === 'instructor_request' ? $instructorDefaults['subject'] : '') }}" placeholder="{{ $letterType === 'proposal' ? 'Contoh: Penawaran Pelatihan Sertifikasi BNSP' : ($letterType === 'instructor_request' ? 'Permohonan Menjadi Instruktur' : 'Perihal surat') }}">
                    </div>
                </div>
            </div>
        </section>

        <section class="card mb-4">
            <div class="card-header"><strong>Langkah 2 — Penerima dan penanda tangan</strong></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="recipient_title">Jabatan penerima</label>
                        <input id="recipient_title" name="recipient_title" class="form-control" value="{{ old('recipient_title', $letterType === 'instructor_request' ? $instructorDefaults['recipient_title'] : 'Direktur Utama') }}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="recipient_company">Perusahaan penerima</label>
                        <input id="recipient_company" name="recipient_company" class="form-control" value="{{ old('recipient_company', $letterType === 'instructor_request' ? $instructorDefaults['recipient_company'] : '') }}" placeholder="Contoh: PT Sumber Graha Maluku">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" id="recipient-name-label" for="recipient_name">{{ $letterType === 'instructor_request' ? 'Nama instruktur' : 'Nama penerima (opsional)' }}</label>
                        <input id="recipient_name" name="recipient_name" class="form-control" value="{{ old('recipient_name', $letterType === 'instructor_request' ? $instructorDefaults['recipient_name'] : '') }}" {{ $letterType === 'instructor_request' ? 'required' : '' }}>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="recipient_address">Alamat penerima</label>
                        <textarea id="recipient_address" name="recipient_address" class="form-control" rows="2" placeholder="Kosongkan jika ditulis 'di Tempat'">{{ old('recipient_address', $letterType === 'instructor_request' ? $instructorDefaults['recipient_address'] : '') }}</textarea>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="signer_name">Nama penanda tangan</label>
                        <input id="signer_name" name="signer_name" class="form-control" value="{{ old('signer_name', $letterType === 'instructor_request' ? $instructorDefaults['signer_name'] : 'Fitriyah, S.Si., M.Si.') }}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="signer_title">Jabatan penanda tangan</label>
                        <input id="signer_title" name="signer_title" class="form-control" value="{{ old('signer_title', $letterType === 'instructor_request' ? $instructorDefaults['signer_title'] : 'Manager Operasional') }}">
                    </div>
                </div>
            </div>
        </section>

        @if($letterType === 'instructor_request')
            @include('letters._instructor_fields')
        @elseif($letterType === 'proposal')
            @include('letters._offer_items')
        @endif

        @if($letterType === 'other')
            <div class="mb-4" id="template-field">
                <label class="form-label" for="template_select">Template isi surat (opsional)</label>
                <select id="template_select" name="template_id" class="form-select">
                    <option value="">-- tanpa template --</option>
                    @foreach($templates as $t)
                        <option data-category="{{ $t->category_id }}" data-letter-type="{{ $t->letter_type }}" value="{{ $t->id }}" {{ (string) old('template_id') === (string) $t->id ? 'selected' : '' }}>{{ $t->name }} ({{ $t->letter_type ? ($letterTypes[$t->letter_type] ?? 'Surat Umum') : 'umum' }})</option>
                    @endforeach
                </select>
                <button type="button" id="load_template" class="btn btn-sm btn-link">Muat isi template</button>
            </div>

            <section class="card mb-4" id="body-field">
                <div class="card-header"><strong>Langkah 3 — Isi surat</strong></div>
                <div class="card-body">
                    <label class="form-label" for="body">Isi surat</label>
                    <textarea id="body" name="body" class="form-control" rows="5">{{ old('body') }}</textarea>
                    <div class="form-text">Isi dapat ditulis langsung atau dimuat dari template.</div>
                </div>
            </section>
        @endif

        <div class="d-flex justify-content-between align-items-center mb-4">
            <span class="text-muted">Nomor manual digunakan jika diisi; jika tidak, sistem membuat nomor otomatis.</span>
            <button class="btn btn-primary">Simpan dan buat surat</button>
        </div>
    </form>
</div>

<script>
    @if($letterType === 'other')
        const templates = {!! json_encode($templates->map(function($t){return ['id'=>$t->id,'category_id'=>$t->category_id,'content'=>$t->content];})) !!};
        const categorySelect = document.getElementById('category');
        const templateSelect = document.getElementById('template_select');
        const body = document.getElementById('body');
        const updateTemplates = () => {
            Array.from(templateSelect.options).forEach((option) => {
                if (!option.value) return;
                option.hidden = option.dataset.category && option.dataset.category !== categorySelect.value;
                option.disabled = option.hidden;
            });
            if (templateSelect.selectedOptions[0]?.disabled) templateSelect.value = '';
        };
        categorySelect.addEventListener('change', updateTemplates);
        updateTemplates();
        document.getElementById('load_template').addEventListener('click', () => {
            const template = templates.find((item) => String(item.id) === templateSelect.value);
            if (template) body.value = template.content;
        });
    @endif
</script>
@endsection
