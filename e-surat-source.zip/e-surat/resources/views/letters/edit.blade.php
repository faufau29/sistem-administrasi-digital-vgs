@extends('layouts.app')

@section('content')
<div class="container">
    <div class="mb-4">
        <a href="{{ route('letters.show', $letter) }}" class="text-decoration-none">&larr; Kembali ke surat</a>
        <h3 class="mt-2 mb-1">Edit Surat</h3>
        <p class="text-muted mb-0">Ubah nomor surat, pilih skema lain, atau sesuaikan nama paket sebelum membuat ulang PDF/Word.</p>
    </div>
    @if($errors->any())
        <div class="alert alert-danger" role="alert">
            <strong>Perubahan belum disimpan.</strong>
            <ul class="mb-0 mt-1">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <form method="POST" action="{{ route('letters.update', $letter) }}">
        @csrf @method('PUT')
        <section class="card mb-4">
            <div class="card-header"><strong>Langkah 1 — Jenis surat dan penomoran</strong></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="letter_type">Jenis / format surat</label>
                        <select id="letter_type" name="letter_type" class="form-select" required>
                            @foreach($letterTypes as $value => $label)
                                <option value="{{ $value }}" {{ old('letter_type', $letter->letter_type) === $value ? 'selected' : '' }}>{{ $label }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="category_id">Kategori arsip untuk nomor surat</label>
                        <select id="category_id" name="category_id" class="form-select" required>
                            @foreach($categories as $c)
                                <option value="{{ $c->id }}" {{ old('category_id', $letter->category_id) == $c->id ? 'selected' : '' }}>{{ $c->name }}</option>
                            @endforeach
                        </select>
                        <div class="form-text">Kategori menentukan pola nomor, sedangkan jenis surat menentukan format dokumen.</div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="full_number">Nomor surat</label>
                        <input id="full_number" name="full_number" class="form-control" value="{{ old('full_number', $letter->full_number) }}" maxlength="255" required>
                        <div class="form-text">Nomor ini akan dipakai pada pratinjau, PDF, dan Word.</div>
                        @error('full_number')<div class="text-danger small">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="date">Tanggal surat</label>
                        <input id="date" type="date" name="date" class="form-control" required value="{{ old('date', $letter->date) }}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="subject">Perihal</label>
                        <input id="subject" name="subject" class="form-control" required value="{{ old('subject', $letter->subject) }}">
                    </div>
                </div>
            </div>
        </section>

        <section class="card mb-4">
            <div class="card-header"><strong>Langkah 2 — Penerima dan penanda tangan</strong></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="recipient_title">Jabatan penerima</label>
                        <input id="recipient_title" name="recipient_title" class="form-control" value="{{ old('recipient_title', $letter->recipient_title) }}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="recipient_company">Perusahaan penerima</label>
                        <input id="recipient_company" name="recipient_company" class="form-control" value="{{ old('recipient_company', $letter->recipient_company) }}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" id="recipient-name-label" for="recipient_name">Nama penerima (opsional)</label>
                        <input id="recipient_name" name="recipient_name" class="form-control" value="{{ old('recipient_name', $letter->recipient_name) }}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="recipient_address">Alamat penerima</label>
                        <textarea id="recipient_address" name="recipient_address" class="form-control" rows="2">{{ old('recipient_address', $letter->recipient_address) }}</textarea>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="signer_name">Nama penanda tangan</label>
                        <input id="signer_name" name="signer_name" class="form-control" value="{{ old('signer_name', $letter->signer_name) }}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="signer_title">Jabatan penanda tangan</label>
                        <input id="signer_title" name="signer_title" class="form-control" value="{{ old('signer_title', $letter->signer_title) }}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="status">Status</label>
                        <select id="status" name="status" class="form-select">
                            <option value="draft" {{ $letter->status === 'draft' ? 'selected':'' }}>Draft</option>
                            <option value="pending" {{ $letter->status === 'pending' ? 'selected':'' }}>Pending</option>
                            <option value="approved" {{ $letter->status === 'approved' ? 'selected':'' }}>Approved</option>
                            <option value="published" {{ $letter->status === 'published' ? 'selected':'' }}>Published</option>
                        </select>
                    </div>
                </div>
            </div>
        </section>

        @include('letters._instructor_fields')
        @include('letters._offer_items')

        <div class="mb-3" id="template-field">
            <label class="form-label" for="template_select">Template isi surat (opsional)</label>
            <select id="template_select" name="template_id" class="form-select">
                <option value="">-- tanpa template --</option>
                @foreach($templates as $t)
                    <option data-category="{{ $t->category_id }}" data-letter-type="{{ $t->letter_type }}" value="{{ $t->id }}" {{ old('template_id', $letter->template_id) == $t->id ? 'selected' : '' }}>{{ $t->name }} ({{ $t->letter_type ? ($letterTypes[$t->letter_type] ?? 'Surat Umum') : 'umum' }})</option>
                @endforeach
            </select>
            <button type="button" id="load_template" class="btn btn-sm btn-link">Muat isi template</button>
        </div>

        <div class="card mb-4" id="body-field">
            <div class="card-header"><strong id="body-heading">Langkah 3 — Isi surat</strong></div>
            <div class="card-body">
                <label class="form-label" id="body-label" for="body">Isi surat</label>
                <textarea id="body" name="body" class="form-control" rows="5">{{ old('body', $letter->body) }}</textarea>
                <div class="form-text" id="body-help"></div>
            </div>
        </div>

        <script>
            const templates = {!! json_encode($templates->map(function($t){return ['id'=>$t->id,'category_id'=>$t->category_id,'letter_type'=>$t->letter_type,'content'=>$t->content];})) !!};
            const typeSelect = document.querySelector('[name="letter_type"]');
            const categorySelect = document.querySelector('[name="category_id"]');
            const templateSelect = document.getElementById('template_select');
            const templateField = document.getElementById('template-field');
            const bodyField = document.getElementById('body-field');
            const bodyLabel = document.getElementById('body-label');
            const bodyHeading = document.getElementById('body-heading');
            const bodyHelp = document.getElementById('body-help');
            const body = document.getElementById('body');
            const recipientNameLabel = document.getElementById('recipient-name-label');
            const recipientName = document.getElementById('recipient_name');
            const recipientTitle = document.getElementById('recipient_title');

            function updateLetterFormat() {
                const type = typeSelect.value;
                const category = categorySelect.value;
                const isProposal = type === 'proposal';
                const isInstructorRequest = type === 'instructor_request';
                templateField.hidden = isProposal || isInstructorRequest;
                templateSelect.disabled = isProposal || isInstructorRequest;
                bodyField.hidden = isProposal || isInstructorRequest;
                Array.from(templateSelect.options).forEach((option) => {
                    if (!option.value) return;
                    const typeMatches = !option.dataset.letterType || option.dataset.letterType === type;
                    const categoryMatches = !option.dataset.category || option.dataset.category === category;
                    option.hidden = !typeMatches || !categoryMatches;
                    option.disabled = option.hidden;
                });
                if (templateSelect.selectedOptions[0]?.disabled) templateSelect.value = '';
                bodyHeading.textContent = isProposal ? 'Langkah 4 — Pembuka surat (opsional)' : 'Langkah 3 — Isi surat';
                bodyLabel.textContent = isProposal ? 'Pembuka surat penawaran' : 'Isi surat';
                bodyHelp.textContent = isProposal
                    ? 'Kosongkan untuk menggunakan pembuka standar seperti pada contoh.'
                    : 'Isi dapat ditulis langsung atau dimuat dari template.';
                body.placeholder = isProposal
                    ? 'Kosongkan untuk menggunakan pembuka surat standar.'
                    : 'Tuliskan isi surat.';
                const subject = document.getElementById('subject');
                if (isInstructorRequest && !subject.value.trim()) subject.value = 'Permohonan Menjadi Instruktur';
                recipientNameLabel.textContent = isInstructorRequest ? 'Nama instruktur' : 'Nama penerima (opsional)';
                recipientName.required = isInstructorRequest;
                if (isInstructorRequest && recipientTitle.value === 'Direktur Utama') recipientTitle.value = 'Instruktur';
            }

            typeSelect.addEventListener('change', updateLetterFormat);
            categorySelect.addEventListener('change', updateLetterFormat);
            updateLetterFormat();

            document.getElementById('load_template').addEventListener('click', function(){
                const sel = document.getElementById('template_select');
                const id = sel.value;
                const t = templates.find(x=>String(x.id)===id);
                if(t) body.value = t.content;
            });
        </script>

        <div class="d-flex justify-content-end">
            <button class="btn btn-primary">Simpan perubahan</button>
        </div>
    </form>
</div>
@endsection
