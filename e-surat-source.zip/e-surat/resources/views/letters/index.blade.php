@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Daftar Surat</h3>
        <div>
            <a href="{{ route('letters.create') }}" class="btn btn-primary">Buat Surat</a>
            <a href="{{ route('letters.export', ['format'=>'csv','search'=>request('search')]) }}" class="btn btn-outline-secondary">Ekspor CSV</a>
            <a href="{{ route('letters.export', ['format'=>'xlsx','search'=>request('search')]) }}" class="btn btn-outline-secondary">Ekspor Excel</a>
        </div>
    </div>

    @if (session('success'))
        <div class="alert alert-success" role="alert">{{ session('success') }}</div>
    @endif

    <form class="mb-3" method="GET">
        <div class="input-group">
            <input name="search" value="{{ request('search') }}" class="form-control" placeholder="Cari nomor, jenis surat, perihal, atau perusahaan">
            <button class="btn btn-outline-secondary">Cari</button>
        </div>
    </form>

    <table class="table table-striped">
        <thead><tr><th>Nomor Surat</th><th>Tanggal</th><th>Jenis Surat</th><th>Perihal</th><th>Perusahaan</th><th>Status</th><th></th></tr></thead>
        <tbody>
        @foreach($letters as $l)
            <tr>
                <td>{{ $l->full_number }}</td>
                <td>{{ $l->date }}</td>
                <td>{{ $l->letter_type_label }}</td>
                <td>{{ $l->subject }}</td>
                <td>{{ $l->recipient_company }}</td>
                <td>{{ $l->status }}</td>
                <td>
                    <a href="{{ route('letters.show', $l) }}" class="btn btn-sm btn-primary">Lihat / Unduh</a>
                    <a href="{{ route('letters.edit', $l) }}" class="btn btn-sm btn-secondary">Edit</a>
                    <form action="{{ route('letters.destroy', $l) }}" method="POST" class="mt-1"
                          onsubmit="return confirm('Yakin ingin menghapus surat ini?')">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-sm btn-outline-danger" type="submit">Hapus</button>
                    </form>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>

    {{ $letters->links() }}
</div>
@endsection
