@extends('layouts.app')

@section('content')
<div class="container">
    <div class="mb-4">
        <a href="{{ route('letters.index') }}" class="text-decoration-none">&larr; Kembali ke daftar surat</a>
        <h3 class="mt-2 mb-1">Pilih jenis surat</h3>
        <p class="text-muted mb-0">Setiap jenis surat memiliki form dan susunan dokumen tersendiri.</p>
    </div>

    <div class="row g-3">
        @foreach($letterTypes as $type => $label)
            <div class="col-md-4">
                <a href="{{ route('letters.create.type', $type) }}" class="card h-100 text-decoration-none text-reset">
                    <div class="card-body">
                        <h5 class="card-title">{{ $label }}</h5>
                        <p class="card-text text-muted mb-0">
                            @if($type === 'proposal')
                                Isi rincian paket pelatihan dan skema penawaran.
                            @elseif($type === 'instructor_request')
                                Isi data undangan instruktur dan rundown pelatihan.
                            @else
                                Buat surat umum menggunakan isi sendiri atau template.
                            @endif
                        </p>
                    </div>
                </a>
            </div>
        @endforeach
    </div>
</div>
@endsection
