@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h3 class="mb-1">Pratinjau Surat</h3>
            <p class="text-muted mb-0">Nomor surat: {{ $letter->full_number }}. Periksa hasilnya, lalu unduh PDF atau Word.</p>
        </div>
        <div>
            <a href="{{ route('letters.edit', $letter) }}" class="btn btn-outline-secondary">Edit Data</a>
        </div>
    </div>
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="card mb-3">
        <div class="card-body">
            <h5>Pratinjau — {{ $letter->letter_type_label }}</h5>
            <p><strong>Tanggal:</strong> {{ \Carbon\Carbon::parse($letter->date)->format('d/m/Y') }}</p>
            <p><strong>Penerima:</strong> {{ $letter->recipient_title }} {{ $letter->recipient_name }} {{ $letter->recipient_company }}</p>
            <p><strong>Perihal:</strong> {{ $letter->subject }}</p>
            @if($letter->letter_type === 'proposal')
                <h6>Rincian paket yang akan masuk ke surat</h6>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr><th>No</th><th>Skema pelatihan</th><th>Jadwal training</th><th>Harga per peserta</th></tr>
                        </thead>
                        <tbody>
                            @foreach($letter->offer_items ?? [] as $index => $item)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $item['title'] ?? config('proposal_schemes.'.($item['scheme'] ?? '').'.name', '') }}</td>
                                    <td>{{ $item['schedule'] ?: '-' }}</td>
                                    <td>Rp {{ number_format((float) $item['price'], 0, ',', '.') }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="alert alert-info mb-0">
                    <strong>Output otomatis:</strong> surat penawaran, syarat dan kondisi, daftar kompetensi sesuai skema yang dipilih, serta lampiran persyaratan dan fasilitas.
                </div>
            @elseif($letter->letter_type === 'instructor_request' && $letter->instructor_details)
                <h6>Rincian pelatihan</h6>
                <dl class="row">
                    <dt class="col-sm-3">Nama pelatihan</dt>
                    <dd class="col-sm-9">{{ $letter->instructor_details['training_name'] }}</dd>
                    <dt class="col-sm-3">Hari dan tanggal</dt>
                    <dd class="col-sm-9">{{ $letter->instructor_details['training_schedule'] }}</dd>
                    <dt class="col-sm-3">Waktu</dt>
                    <dd class="col-sm-9">{{ $letter->instructor_details['training_time'] }}</dd>
                    <dt class="col-sm-3">Tempat</dt>
                    <dd class="col-sm-9">{{ $letter->instructor_details['training_place'] }}</dd>
                </dl>
                <h6>Rundown pelatihan</h6>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr><th>No</th><th>Hari/Tanggal</th><th>Pukul</th><th>Kegiatan / Materi</th><th>PIC</th></tr>
                        </thead>
                        <tbody>
                            @foreach($letter->instructor_details['agenda'] as $index => $item)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $item['day'] }}</td>
                                    <td>{{ $item['time'] }}</td>
                                    <td>{{ $item['activity'] }}</td>
                                    <td>{{ $item['pic'] }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="alert alert-info mb-0">
                    <strong>Output otomatis:</strong> isi permohonan instruktur dan tabel rundown akan disertakan pada hasil PDF dan Word.
                </div>
            @else
                <hr>
                <div>{!! $renderedBody !!}</div>
                <hr>
            @endif
            <p><strong>Penanda tangan:</strong> {{ $letter->signer_name }} ({{ $letter->signer_title }})</p>
        </div>
    </div>
    <div class="mb-3">
        <a class="btn btn-outline-primary" href="{{ route('letters.pdf', $letter) }}">Unduh / Cetak PDF</a>
        <form method="POST" action="{{ route('letters.export.docx', $letter) }}" style="display:inline">
            @csrf
            <button class="btn btn-outline-success">Unduh Word</button>
        </form>
    </div>
</div>
@endsection
