@php
    $offerItems = old('offer_items', $letter->offer_items ?? [['scheme' => '', 'title' => '', 'schedule' => '', 'price' => '']]);
@endphp
<section class="card mb-4" id="proposal-fields" hidden>
    <div class="card-header">
        <strong>Langkah 3 — Rincian paket penawaran</strong>
    </div>
    <div class="card-body">
        <p class="text-muted">
            Pilih atau ganti skema. Nama paket dapat diedit untuk surat ini saja; isi jadwal dan harga per peserta.
        </p>
        <div class="table-responsive">
            <table class="table table-bordered align-middle mb-2">
                <thead class="table-light">
                    <tr>
                        <th>Pilihan skema</th>
                        <th>Nama paket pada surat (dapat diedit)</th>
                        <th>Jadwal training</th>
                        <th>Harga per peserta (Rp)</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody id="offer-items">
                    @foreach($offerItems as $index => $item)
                        <tr>
                            <td>
                                <select class="form-select" name="offer_items[{{ $index }}][scheme]">
                                    <option value="">-- pilih skema --</option>
                                    @foreach($proposalSchemes as $key => $scheme)
                                        <option value="{{ $key }}" data-package="{{ $scheme['package'] }}" {{ ($item['scheme'] ?? '') === $key ? 'selected' : '' }}>{{ $scheme['name'] }}</option>
                                    @endforeach
                                    <option value="custom" {{ ($item['scheme'] ?? '') === 'custom' ? 'selected' : '' }}>Skema lainnya (isi nama sendiri)</option>
                                </select>
                            </td>
                            <td>
                                <input class="form-control" name="offer_items[{{ $index }}][title]" value="{{ $item['title'] ?? ($proposalSchemes[$item['scheme'] ?? '']['package'] ?? '') }}" placeholder="Nama paket yang dicetak" maxlength="500">
                            </td>
                            <td>
                                <input class="form-control" name="offer_items[{{ $index }}][schedule]" value="{{ $item['schedule'] ?? '' }}" placeholder="Contoh: 12-16 November 2026" maxlength="255">
                            </td>
                            <td>
                                <input class="form-control" type="number" min="0" step="1" name="offer_items[{{ $index }}][price]" value="{{ $item['price'] ?? '' }}" placeholder="Contoh: 4.900.000">
                            </td>
                            <td>
                                <button class="btn btn-outline-danger btn-sm remove-offer-item" type="button" aria-label="Hapus paket">&times;</button>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <button class="btn btn-outline-primary btn-sm" id="add-offer-item" type="button">Tambah skema</button>
        <div class="form-text mt-2">Pilih skema lain untuk mengganti pilihan. Untuk skema yang belum tersedia, pilih “Skema lainnya” dan isi namanya.</div>
    </div>
</section>

<template id="offer-item-template">
    <tr>
        <td>
            <select class="form-select" data-field="scheme">
                <option value="">-- pilih skema --</option>
                @foreach($proposalSchemes as $key => $scheme)
                    <option value="{{ $key }}" data-package="{{ $scheme['package'] }}">{{ $scheme['name'] }}</option>
                @endforeach
                <option value="custom">Skema lainnya (isi nama sendiri)</option>
            </select>
        </td>
        <td><input class="form-control" data-field="title" placeholder="Nama paket yang dicetak" maxlength="500"></td>
        <td><input class="form-control" data-field="schedule" placeholder="Contoh: 12-16 November 2026" maxlength="255"></td>
        <td><input class="form-control" type="number" min="0" step="1" data-field="price" placeholder="Contoh: 4.900.000"></td>
        <td><button class="btn btn-outline-danger btn-sm remove-offer-item" type="button" aria-label="Hapus paket">&times;</button></td>
    </tr>
</template>

<script>
    (() => {
        const typeSelect = document.querySelector('[name="letter_type"]');
        const proposalFields = document.getElementById('proposal-fields');
        const rows = document.getElementById('offer-items');
        const template = document.getElementById('offer-item-template');

        if (!typeSelect || !proposalFields || !rows || !template) return;

        const updateVisibility = () => {
            const isProposal = typeSelect.value === 'proposal';
            proposalFields.hidden = !isProposal;
            proposalFields.querySelectorAll('input, select').forEach((input) => {
                input.disabled = !isProposal;
                input.required = isProposal && (
                    input.name.endsWith('[scheme]')
                    || input.name.endsWith('[title]')
                    || input.name.endsWith('[schedule]')
                    || input.name.endsWith('[price]')
                );
            });
        };

        const addRow = () => {
            const index = rows.children.length
                ? Math.max(...Array.from(rows.querySelectorAll('[name]')).map((input) => {
                    const match = input.name.match(/offer_items\[(\d+)\]/);
                    return match ? Number(match[1]) : -1;
                })) + 1
                : 0;
            const row = template.content.firstElementChild.cloneNode(true);
            row.querySelectorAll('[data-field]').forEach((input) => {
                input.name = `offer_items[${index}][${input.dataset.field}]`;
            });
            rows.append(row);
            updateVisibility();
        };

        document.getElementById('add-offer-item').addEventListener('click', addRow);
        rows.addEventListener('change', (event) => {
            if (!event.target.matches('select[name$="[scheme]"]')) return;
            const titleInput = event.target.closest('tr').querySelector('input[name$="[title]"]');
            titleInput.value = event.target.selectedOptions[0]?.dataset.package || '';
        });
        rows.addEventListener('click', (event) => {
            if (!event.target.closest('.remove-offer-item')) return;
            if (rows.children.length === 1) {
                rows.querySelectorAll('input').forEach((input) => input.value = '');
                rows.querySelectorAll('select').forEach((input) => input.value = '');
                return;
            }
            event.target.closest('tr').remove();
        });
        typeSelect.addEventListener('change', updateVisibility);
        updateVisibility();
    })();
</script>
