<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Surat Penawaran {{ $letter->full_number }}</title>
    <style>
        @page {
            margin: 28mm 13mm 25mm;
        }

        body {
            color: #171717;
            font-family: "DejaVu Serif", serif;
            font-size: 9pt;
            line-height: 1.28;
        }

        .letterhead {
            position: fixed;
            top: -61pt;
            left: 0;
            width: 100%;
            height: 46pt;
        }

        .footer-art {
            position: fixed;
            bottom: -64pt;
            left: 0;
            width: 100%;
            height: auto;
        }

        .meta {
            width: 100%;
            margin: 2pt 0 15pt;
            border-collapse: collapse;
        }

        .meta td {
            padding: 1pt 2pt;
            vertical-align: top;
        }

        .meta-label {
            width: 53pt;
        }

        .date {
            text-align: right;
            white-space: nowrap;
        }

        .recipient {
            margin: 0 0 12pt 25pt;
        }

        .body-copy {
            margin: 10pt 0;
            text-align: justify;
            white-space: pre-line;
        }

        .offer {
            width: 100%;
            border-collapse: collapse;
            font-size: 8pt;
        }

        .offer th,
        .offer td {
            border: 1px solid #444;
            padding: 5pt;
            vertical-align: top;
        }

        .offer th {
            background: #d7d7d7;
            text-align: center;
        }

        .number,
        .price {
            text-align: center;
            white-space: nowrap;
        }

        .schedule {
            text-align: center;
            white-space: pre-line;
        }

        .page-break {
            page-break-before: always;
        }

        .conditions {
            padding-left: 22pt;
        }

        .conditions li {
            margin-bottom: 8pt;
            padding-left: 3pt;
        }

        .closing {
            margin-top: 20pt;
            text-align: right;
        }

        .signature {
            margin-top: 50pt;
            font-weight: bold;
            text-decoration: underline;
        }

        .appendix-title {
            margin: 0 0 10pt;
            font-size: 11pt;
            text-align: center;
        }

        .scheme-title {
            margin: 9pt 0 4pt;
            font-size: 9pt;
        }

        .competencies,
        .list-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 8pt;
        }

        .competencies th,
        .competencies td,
        .list-table th,
        .list-table td {
            border: 1px solid #555;
            padding: 3pt 5pt;
            vertical-align: top;
        }

        .competencies th,
        .list-table th {
            background: #d8d8d8;
            text-align: center;
        }

        .chart {
            display: block;
            width: 100%;
            height: auto;
            margin-bottom: 8pt;
        }

        .list-table {
            margin-bottom: 12pt;
        }
    </style>
</head>
<body>
    <img class="letterhead" src="data:image/jpeg;base64,{{ base64_encode(file_get_contents(public_path('images/proposal-letterhead.jpg'))) }}" alt="">
    <img class="footer-art" src="data:image/jpeg;base64,{{ base64_encode(file_get_contents(public_path('images/proposal-footer.jpg'))) }}" alt="">

    <table class="meta">
        <tr>
            <td class="meta-label">Nomor</td>
            <td>: {{ $letter->full_number }}</td>
            <td class="date">Serang, {{ \Carbon\Carbon::parse($letter->date)->locale('id')->translatedFormat('d F Y') }}</td>
        </tr>
        <tr>
            <td class="meta-label">Lampiran</td>
            <td colspan="2">: {{ $letter->attachment_note ?: '-' }}</td>
        </tr>
        <tr>
            <td class="meta-label">Perihal</td>
            <td colspan="2">: <strong>{{ $letter->subject }}</strong></td>
        </tr>
    </table>

    <div class="recipient">
        Yth,<br>
        <strong>{{ $letter->recipient_title ?: 'Direktur Utama' }}</strong><br>
        <strong>{{ $letter->recipient_company ?: $letter->recipient_name }}</strong><br>
        {{ $letter->recipient_address ?: 'di Tempat.' }}
    </div>

    <p>Dengan hormat,</p>
    <div class="body-copy">{{ $letter->body ?: 'PT Veritrust Global Solusindo sebagai perusahaan di bidang pelayanan jasa pelatihan dan konsultasi manajemen K3 dan Lingkungan. Dengan ini menawarkan pelatihan dan sertifikasi BNSP sebagai berikut:' }}</div>

    <table class="offer">
        <thead>
            <tr>
                <th style="width: 6%">No</th>
                <th style="width: 48%">Ruang Lingkup</th>
                <th style="width: 26%">Jadwal Training</th>
                <th style="width: 20%">Harga</th>
            </tr>
        </thead>
        <tbody>
            @foreach($letter->offer_items ?? [] as $index => $item)
                <tr>
                    <td class="number">{{ $index + 1 }}</td>
                    <td>{{ $item['title'] ?? config('proposal_schemes.'.($item['scheme'] ?? '').'.package', '') }}</td>
                    <td class="schedule">{{ $item['schedule'] ?: '-' }}</td>
                    <td class="price">Rp {{ number_format((float) $item['price'], 0, ',', '.') }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <section class="page-break">
        <strong>Syarat dan Kondisi:</strong>
        <ol class="conditions">
            <li>Harga belum termasuk PPn.</li>
            <li>Pembayaran dilakukan 50% saat SPK/PO dikeluarkan oleh Customer.</li>
            <li>Sisa pembayaran dilakukan sebelum Uji Kompetensi dilakukan.</li>
            <li>Pembayaran dilakukan ke Nomor Rek. Bank Mandiri - 163-00-0332556-3 dan BCA - 5421-1822-22 atas nama PT VERITRUST GLOBAL SOLUSINDO.</li>
        </ol>
        <p>Demikianlah Surat Penawaran ini kami buat, atas perhatian dan kerjasamanya, kami ucapkan Terimakasih.</p>
        <div class="closing">
            Hormat kami,
            <div class="signature">{{ $letter->signer_name ?: 'Fitriyah, S.Si., M.Si.' }}</div>
            <div>{{ $letter->signer_title ?: 'Manager Operasional' }}</div>
        </div>
    </section>

    @if($textSchemes)
        <section class="page-break">
            <h1 class="appendix-title">DAFTAR SKEMA LINGKUNGAN SERTIFIKASI BNSP<br>PT VERITRUST GLOBAL SOLUSINDO - {{ \Carbon\Carbon::parse($letter->date)->format('Y') }}</h1>
            @foreach($textSchemes as $schemeKey)
                <h2 class="scheme-title">{{ $proposalSchemes[$schemeKey]['appendix_title'] }}</h2>
                <table class="competencies">
                    <thead><tr><th style="width: 8%">No</th><th>Judul Unit Kompetensi</th></tr></thead>
                    <tbody>
                        @foreach($proposalSchemes[$schemeKey]['competencies'] as $index => $competency)
                            <tr><td class="number">{{ $index + 1 }}.</td><td>{{ $competency }}</td></tr>
                        @endforeach
                    </tbody>
                </table>
            @endforeach
        </section>
    @endif

    @if($chartSchemes)
        <section class="page-break">
            <h1 class="appendix-title">UNIT KOMPETENSI SKEMA LIMBAH B3</h1>
            @foreach($chartSchemes as $schemeKey)
                <h2 class="scheme-title">{{ $proposalSchemes[$schemeKey]['appendix_title'] }}</h2>
                <img class="chart" src="data:image/jpeg;base64,{{ base64_encode(file_get_contents(public_path($proposalSchemes[$schemeKey]['chart']))) }}" alt="{{ $proposalSchemes[$schemeKey]['appendix_title'] }}">
            @endforeach
        </section>
    @endif

    <section class="page-break">
        <h1 class="appendix-title">Lampiran Skema Lingkungan BNSP</h1>
        @foreach([
            'Dokumen Persyaratan' => [
                'KTP',
                'Pas Foto Background Merah',
                'Ijazah',
                'CV',
                'Surat aktif kerja (jika utusan Perusahaan)',
                'Jobdesk',
                'Laporan Kerja',
                'Registrasi akun SIAP KERJA',
            ],
            'Fasilitas' => [
                'Sertifikat SKKNI (sesuai Skema)',
                'Sertifikat Digital/Softcopy Kompetensi BNSP',
                'Sertifikat Penunjang Internal Veritrust',
                'Training Record',
                'Modul Materi (Softfile)',
                'Eco Tumbler Eksklusif Veritrust',
                'Souvenir',
                'T-Shirt',
                'Akses Grup Alumni',
            ],
        ] as $heading => $items)
            <table class="list-table">
                <thead><tr><th style="width: 8%">No</th><th>{{ $heading }}</th></tr></thead>
                <tbody>
                    @foreach($items as $index => $item)
                        <tr><td class="number">{{ $index + 1 }}</td><td>{{ $item }}</td></tr>
                    @endforeach
                </tbody>
            </table>
        @endforeach
    </section>
</body>
</html>
