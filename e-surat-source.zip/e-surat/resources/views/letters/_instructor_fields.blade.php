@php
    $instructorDetails = old('instructor_details', isset($letter) ? ($letter->instructor_details ?? []) : config('instructor_request.defaults.details'));
    $agendaItems = $instructorDetails['agenda'] ?? [['day' => '', 'time' => '', 'activity' => '', 'pic' => '']];
@endphp
<section class="card mb-4" id="instructor-fields" hidden>
    <div class="card-header"><strong>Rincian permohonan instruktur dan rundown</strong></div>
    <div class="card-body">
        <p class="text-muted">Form diisi awal berdasarkan surat HIMU BNSP contoh. Silakan sesuaikan data, termasuk rundown; semua baris dapat ditambah, diubah, atau dihapus.</p>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label" for="attachment_note">Lampiran</label>
                <input id="attachment_note" name="attachment_note" class="form-control" value="{{ old('attachment_note', isset($letter) ? $letter->attachment_note : config('instructor_request.defaults.attachment_note')) }}" maxlength="255">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="training_name">Nama pelatihan</label>
                <input id="training_name" name="instructor_details[training_name]" class="form-control" value="{{ $instructorDetails['training_name'] ?? '' }}" placeholder="Contoh: Pelatihan Ahli Hygiene Industri Muda (HIMU) Sertifikasi BNSP" maxlength="255">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="training_schedule">Hari dan tanggal pelatihan</label>
                <input id="training_schedule" name="instructor_details[training_schedule]" class="form-control" value="{{ $instructorDetails['training_schedule'] ?? '' }}" placeholder="Contoh: Selasa - Rabu, 3-4 November 2026" maxlength="255">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="training_time">Waktu</label>
                <input id="training_time" name="instructor_details[training_time]" class="form-control" value="{{ $instructorDetails['training_time'] ?? '' }}" placeholder="Contoh: 08.30 - 16.00 WIB" maxlength="100">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="training_place">Tempat pelatihan</label>
                <input id="training_place" name="instructor_details[training_place]" class="form-control" value="{{ $instructorDetails['training_place'] ?? '' }}" placeholder="Contoh: Zoom Meeting" maxlength="255">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="rundown_title">Judul rundown</label>
                <input id="rundown_title" name="instructor_details[rundown_title]" class="form-control" value="{{ $instructorDetails['rundown_title'] ?? '' }}" placeholder="Contoh: HIMU BNSP" maxlength="255">
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered align-middle mb-2">
                <thead class="table-light">
                    <tr><th>Hari/Tanggal</th><th>Pukul</th><th>Kegiatan / Materi</th><th>PIC</th><th></th></tr>
                </thead>
                <tbody id="instructor-agenda">
                    @foreach($agendaItems as $index => $item)
                        <tr>
                            <td><input class="form-control" data-field="day" name="instructor_details[agenda][{{ $index }}][day]" value="{{ $item['day'] ?? '' }}" placeholder="Contoh: Selasa, 3 November 2026" maxlength="100"></td>
                            <td><input class="form-control" data-field="time" name="instructor_details[agenda][{{ $index }}][time]" value="{{ $item['time'] ?? '' }}" placeholder="08.30-09.30" maxlength="50"></td>
                            <td><input class="form-control" data-field="activity" name="instructor_details[agenda][{{ $index }}][activity]" value="{{ $item['activity'] ?? '' }}" placeholder="Materi atau kegiatan" maxlength="500"></td>
                            <td><input class="form-control" data-field="pic" name="instructor_details[agenda][{{ $index }}][pic]" value="{{ $item['pic'] ?? '' }}" placeholder="Instruktur / MC / All" maxlength="150"></td>
                            <td><button class="btn btn-outline-danger btn-sm remove-agenda-item" type="button" aria-label="Hapus baris rundown">&times;</button></td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <button class="btn btn-outline-primary btn-sm" id="add-agenda-item" type="button">Tambah baris rundown</button>
    </div>
</section>

<template id="instructor-agenda-template">
    <tr>
        <td><input class="form-control" data-field="day" placeholder="Hari dan tanggal" maxlength="100"></td>
        <td><input class="form-control" data-field="time" placeholder="08.30-09.30" maxlength="50"></td>
        <td><input class="form-control" data-field="activity" placeholder="Materi atau kegiatan" maxlength="500"></td>
        <td><input class="form-control" data-field="pic" placeholder="Instruktur / MC / All" maxlength="150"></td>
        <td><button class="btn btn-outline-danger btn-sm remove-agenda-item" type="button" aria-label="Hapus baris rundown">&times;</button></td>
    </tr>
</template>

<script>
    (() => {
        const typeSelect = document.querySelector('[name="letter_type"]');
        const instructorFields = document.getElementById('instructor-fields');
        const agendaRows = document.getElementById('instructor-agenda');
        const agendaTemplate = document.getElementById('instructor-agenda-template');
        if (!typeSelect || !instructorFields || !agendaRows || !agendaTemplate) return;

        const updateInstructorFields = () => {
            const active = typeSelect.value === 'instructor_request';
            instructorFields.hidden = !active;
            instructorFields.querySelectorAll('input').forEach((input) => {
                input.disabled = !active;
                input.required = active;
            });
        };

        const addAgendaRow = () => {
            const indexes = Array.from(agendaRows.querySelectorAll('[name]'))
                .map((input) => Number(input.name.match(/agenda\]\[(\d+)\]/)?.[1] ?? -1));
            const index = indexes.length ? Math.max(...indexes) + 1 : 0;
            const row = agendaTemplate.content.firstElementChild.cloneNode(true);
            row.querySelectorAll('[data-field]').forEach((input) => {
                input.name = `instructor_details[agenda][${index}][${input.dataset.field}]`;
                input.required = typeSelect.value === 'instructor_request';
                input.disabled = typeSelect.value !== 'instructor_request';
            });
            agendaRows.append(row);
        };

        document.getElementById('add-agenda-item').addEventListener('click', addAgendaRow);
        agendaRows.addEventListener('click', (event) => {
            if (!event.target.closest('.remove-agenda-item')) return;
            if (agendaRows.children.length === 1) {
                agendaRows.querySelectorAll('input').forEach((input) => input.value = '');
                return;
            }
            event.target.closest('tr').remove();
        });
        typeSelect.addEventListener('change', updateInstructorFields);
        updateInstructorFields();
    })();
</script>
