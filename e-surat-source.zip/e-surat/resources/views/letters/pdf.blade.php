<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size:12px; }
        .header { text-align:center; margin-bottom:20px }
        .meta { margin-bottom:10px }
        .content { white-space: pre-wrap; }
        .sign { margin-top:40px }
    </style>
</head>
<body>
    <div class="header">
        <h2>PT Veritrust Global Solusindo</h2>
        <p>{{ $letter->letter_type_label }}</p>
    </div>

    <div class="meta">
        <div><strong>Nomor:</strong> {{ $letter->full_number }}</div>
        <div><strong>Tanggal:</strong> {{ $letter->date }}</div>
        <div><strong>Perihal:</strong> {{ $letter->subject }}</div>
    </div>

    <div>
        <strong>Kepada Yth:</strong>
        <div>{{ $letter->recipient_name }}</div>
        <div>{{ $letter->recipient_title }}</div>
        <div>{{ $letter->recipient_company }}</div>
        <div>{{ $letter->recipient_address }}</div>
    </div>

    <hr>

    <div class="content">{!! $renderedBody !!}</div>

    <div class="sign">
        <div>{{ $letter->signer_name }}</div>
        <div>{{ $letter->signer_title }}</div>
    </div>

</body>
</html>
