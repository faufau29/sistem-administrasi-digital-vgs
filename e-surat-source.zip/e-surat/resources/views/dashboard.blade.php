@extends('layouts.app')

@section('content')
<style>
    .dashboard-page {
        --dashboard-ink: #2b194b;
        --dashboard-muted: #786e8b;
        --dashboard-line: #e9e2f2;
        --dashboard-surface: #fff;
        --dashboard-canvas: #faf8fd;
        background:
            radial-gradient(ellipse at 92% 0%, rgba(124, 58, 237, .07), transparent 34rem),
            var(--dashboard-canvas);
        min-height: calc(100vh - 64px);
        padding: .25rem 0 1rem;
    }

    .dashboard-page .container {
        max-width: 1280px;
    }

    .dashboard-heading {
        align-items: flex-end;
        display: flex;
        gap: 1rem;
        justify-content: space-between;
        margin-bottom: 1.75rem;
    }

    .dashboard-eyebrow {
        color: #7136bd;
        font-size: .75rem;
        font-weight: 700;
        letter-spacing: .12em;
        margin-bottom: .55rem;
        text-transform: uppercase;
    }

    .dashboard-title {
        color: var(--dashboard-ink);
        font-size: clamp(1.8rem, 3vw, 2.4rem);
        font-weight: 800;
        letter-spacing: -.04em;
        margin: 0;
    }

    .dashboard-subtitle {
        color: var(--dashboard-muted);
        margin: .45rem 0 0;
    }

    .dashboard-date {
        color: var(--dashboard-muted);
        font-size: .9rem;
        padding-bottom: .25rem;
        white-space: nowrap;
    }

    .dashboard-stats {
        display: grid;
        gap: 1rem;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        margin-bottom: 2rem;
    }

    .dashboard-card {
        background: var(--dashboard-surface);
        border: 1px solid var(--dashboard-line);
        border-radius: 18px;
        box-shadow: 0 7px 22px rgb(47 21 86 / 5%);
    }

    .stat-card {
        align-items: center;
        display: flex;
        gap: 1rem;
        min-height: 132px;
        padding: 1.35rem 1.5rem;
    }

    .stat-icon,
    .module-icon {
        align-items: center;
        border-radius: 12px;
        display: inline-flex;
        flex: 0 0 auto;
        height: 48px;
        justify-content: center;
        width: 48px;
    }

    .stat-icon svg,
    .module-icon svg {
        height: 23px;
        width: 23px;
    }

    .stat-icon.teal,
    .module-icon.teal {
        background: #f0e8fa;
        color: #7136bd;
    }

    .stat-icon.blue,
    .module-icon.blue {
        background: #eee8f8;
        color: #7136bd;
    }

    .stat-icon.amber,
    .module-icon.amber {
        background: #fff5d8;
        color: #a87810;
    }

    .stat-label {
        color: var(--dashboard-muted);
        font-size: .9rem;
        font-weight: 600;
        margin-bottom: .25rem;
    }

    .stat-value {
        color: var(--dashboard-ink);
        font-size: 2rem;
        font-weight: 700;
        letter-spacing: -.04em;
        line-height: 1.1;
    }

    .dashboard-section-heading {
        align-items: end;
        display: flex;
        justify-content: space-between;
        margin-bottom: 1rem;
    }

    .dashboard-section-heading h2 {
        color: var(--dashboard-ink);
        font-size: 1.2rem;
        font-weight: 700;
        margin: 0;
    }

    .dashboard-section-heading p {
        color: var(--dashboard-muted);
        font-size: .9rem;
        margin: .3rem 0 0;
    }

    .module-grid {
        display: grid;
        gap: 1rem;
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }

    .module-card {
        color: inherit;
        display: flex;
        flex-direction: column;
        min-height: 208px;
        padding: 1.35rem 1.5rem;
        text-decoration: none;
        transition: border-color .15s ease, box-shadow .15s ease, transform .15s ease;
    }

    .module-card:hover {
        border-color: #c9afe8;
        box-shadow: 0 12px 28px rgb(47 21 86 / 10%);
        color: inherit;
        transform: translateY(-2px);
    }

    .module-card:focus-visible,
    .action-link:focus-visible {
        outline: 3px solid rgba(124, 58, 237, .42);
        outline-offset: 3px;
    }

    .module-card-top {
        align-items: center;
        display: flex;
        justify-content: space-between;
    }

    .module-card h3 {
        color: var(--dashboard-ink);
        font-size: 1.05rem;
        font-weight: 700;
        margin: 1rem 0 .4rem;
    }

    .module-card p {
        color: var(--dashboard-muted);
        font-size: .9rem;
        line-height: 1.5;
        margin: 0;
    }

    .module-link {
        color: #7136bd;
        font-size: .88rem;
        font-weight: 700;
        margin-top: auto;
        padding-top: 1.15rem;
    }

    .dashboard-bottom {
        display: grid;
        gap: 1rem;
        grid-template-columns: 1.15fr .85fr;
        margin-top: 2rem;
    }

    .activity-card,
    .actions-card {
        padding: 1.4rem 1.5rem;
    }

    .activity-card h2,
    .actions-card h2 {
        color: var(--dashboard-ink);
        font-size: 1.05rem;
        font-weight: 700;
        margin: 0 0 1rem;
    }

    .activity-row {
        align-items: center;
        border-top: 1px solid var(--dashboard-line);
        display: flex;
        gap: 1rem;
        justify-content: space-between;
        padding: .9rem 0;
    }

    .activity-row:first-of-type {
        border-top: 0;
        padding-top: 0;
    }

    .activity-label {
        color: var(--dashboard-muted);
        font-size: .9rem;
    }

    .activity-value {
        color: var(--dashboard-ink);
        font-size: 1.1rem;
        font-weight: 700;
    }

    .action-list {
        display: grid;
        gap: .65rem;
    }

    .action-link {
        align-items: center;
        border: 1px solid var(--dashboard-line);
        border-radius: 9px;
        color: var(--dashboard-ink);
        display: flex;
        font-size: .9rem;
        font-weight: 600;
        justify-content: space-between;
        padding: .7rem .85rem;
        text-decoration: none;
        transition: background .15s ease, border-color .15s ease;
    }

    .action-link:hover {
        background: #f7f2fc;
        border-color: #c9afe8;
        color: #7136bd;
    }

    .action-arrow {
        color: #8795a9;
        font-size: 1.1rem;
    }

    @media (max-width: 767.98px) {
        .dashboard-page {
            padding-top: 1.25rem;
        }

        .dashboard-heading {
            align-items: flex-start;
            flex-direction: column;
            margin-bottom: 1.25rem;
        }

        .dashboard-date {
            padding: 0;
        }

        .dashboard-stats,
        .module-grid {
            grid-template-columns: 1fr;
        }

        .stat-card {
            min-height: 100px;
        }

        .module-card {
            min-height: 180px;
        }

        .dashboard-bottom {
            grid-template-columns: 1fr;
            margin-top: 1.5rem;
        }
    }
</style>

<div class="dashboard-page">
    <div class="container">
        <header class="dashboard-heading">
            <div>
                <div class="dashboard-eyebrow">Pusat administrasi</div>
                <h1 class="dashboard-title">Dashboard</h1>
                <p class="dashboard-subtitle">Selamat datang, {{ auth()->user()->name }}. Berikut ringkasan dokumen dan akses cepat ke modul E-Surat.</p>
            </div>
            <div class="dashboard-date">{{ now()->locale('id')->translatedFormat('l, d F Y') }}</div>
        </header>

        <section class="dashboard-stats" aria-label="Ringkasan dokumen">
            <article class="dashboard-card stat-card">
                <span class="stat-icon teal" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                        <path d="M7 3.75h7l4.25 4.5v12H7a2 2 0 0 1-2-2v-12a2.5 2.5 0 0 1 2-2.5Z"/>
                        <path d="M14 4v5h4M8.5 13h7M8.5 16.5h7"/>
                    </svg>
                </span>
                <div>
                    <div class="stat-label">Total surat</div>
                    <div class="stat-value">{{ number_format($letters) }}</div>
                </div>
            </article>

            <article class="dashboard-card stat-card">
                <span class="stat-icon blue" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                        <path d="M6 3.75h8l4 4v12.5H6a2 2 0 0 1-2-2v-12a2.5 2.5 0 0 1 2-2.5Z"/>
                        <path d="M14 4v4.5h4M8 12h8M8 15.5h8"/>
                    </svg>
                </span>
                <div>
                    <div class="stat-label">Total invoice</div>
                    <div class="stat-value">{{ number_format($invoices) }}</div>
                </div>
            </article>

            <article class="dashboard-card stat-card">
                <span class="stat-icon amber" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                        <path d="M5 5.5h14v13H5zM8 9h8M8 12.5h5"/>
                        <path d="m14 16 1.5 1.5L19 14"/>
                    </svg>
                </span>
                <div>
                    <div class="stat-label">Total kwitansi</div>
                    <div class="stat-value">{{ number_format($receipts) }}</div>
                </div>
            </article>
        </section>

        <section aria-labelledby="modules-heading">
            <div class="dashboard-section-heading">
                <div>
                    <h2 id="modules-heading">Modul dokumen</h2>
                    <p>Pilih modul untuk melihat, membuat, dan mengelola dokumen.</p>
                </div>
            </div>

            <div class="module-grid">
                <a class="dashboard-card module-card" href="{{ route('letters.index') }}">
                    <div class="module-card-top">
                        <span class="module-icon teal" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                <path d="M7 3.75h7l4.25 4.5v12H7a2 2 0 0 1-2-2v-12a2.5 2.5 0 0 1 2-2.5Z"/>
                                <path d="M14 4v5h4M8.5 13h7M8.5 16.5h7"/>
                            </svg>
                        </span>
                        <span class="activity-value">{{ number_format($letters) }}</span>
                    </div>
                    <h3>Surat</h3>
                    <p>Kelola surat keluar dan dokumen korespondensi.</p>
                    <span class="module-link">Buka modul <span aria-hidden="true">&rarr;</span></span>
                </a>

                <a class="dashboard-card module-card" href="{{ route('invoices.index') }}">
                    <div class="module-card-top">
                        <span class="module-icon blue" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                <path d="M6 3.75h8l4 4v12.5H6a2 2 0 0 1-2-2v-12a2.5 2.5 0 0 1 2-2.5Z"/>
                                <path d="M14 4v4.5h4M8 12h8M8 15.5h8"/>
                            </svg>
                        </span>
                        <span class="activity-value">{{ number_format($invoices) }}</span>
                    </div>
                    <h3>Invoice</h3>
                    <p>Buat dan pantau invoice beserta status pembayarannya.</p>
                    <span class="module-link">Buka modul <span aria-hidden="true">&rarr;</span></span>
                </a>

                <a class="dashboard-card module-card" href="{{ route('receipts.index') }}">
                    <div class="module-card-top">
                        <span class="module-icon amber" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                <path d="M5 5.5h14v13H5zM8 9h8M8 12.5h5"/>
                                <path d="m14 16 1.5 1.5L19 14"/>
                            </svg>
                        </span>
                        <span class="activity-value">{{ number_format($receipts) }}</span>
                    </div>
                    <h3>Kwitansi</h3>
                    <p>Kelola bukti pembayaran dan riwayat penerimaan.</p>
                    <span class="module-link">Buka modul <span aria-hidden="true">&rarr;</span></span>
                </a>
            </div>
        </section>

        <section class="dashboard-bottom" aria-label="Aktivitas dan pengaturan">
            <article class="dashboard-card activity-card">
                <h2>Aktivitas dokumen</h2>
                <div class="activity-row">
                    <span class="activity-label">Surat dibuat bulan ini</span>
                    <span class="activity-value">{{ number_format($lettersThisMonth) }}</span>
                </div>
                <div class="activity-row">
                    <span class="activity-label">Semua dokumen tahun ini</span>
                    <span class="activity-value">{{ number_format($documentsThisYear) }}</span>
                </div>
            </article>

            <article class="dashboard-card actions-card">
                <h2>Pengaturan &amp; data</h2>
                <nav class="action-list" aria-label="Pengaturan dashboard">
                    <a class="action-link" href="{{ route('categories.index') }}">
                        <span>Kelola kategori</span><span class="action-arrow" aria-hidden="true">&rarr;</span>
                    </a>
                    <a class="action-link" href="{{ route('templates.index') }}">
                        <span>Kelola template</span><span class="action-arrow" aria-hidden="true">&rarr;</span>
                    </a>
                    <a class="action-link" href="{{ route('imports.index') }}">
                        <span>Riwayat impor</span><span class="action-arrow" aria-hidden="true">&rarr;</span>
                    </a>
                </nav>
            </article>
        </section>
    </div>
</div>
@endsection
