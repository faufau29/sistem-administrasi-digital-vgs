@extends('layouts.app')

@section('content')
<div class="container">
    <h3>Import Historical Numbers</h3>

    @if($errors->any())
        <div class="alert alert-danger">{{ $errors->first() }}</div>
    @endif
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="card mb-3">
        <div class="card-body">
            <p>Upload an Excel (.xlsx/.xls) or CSV file with header row. Expected columns (case-insensitive):</p>
            <ul>
                <li><strong>document_type</strong> (letter, invoice, receipt)</li>
                <li><strong>category_code</strong> or <strong>category</strong></li>
                <li><strong>number</strong> (numeric or part of full_number)</li>
                <li><strong>full_number</strong></li>
                <li><strong>date</strong> (optional)</li>
                <li><strong>notes</strong> (optional)</li>
            </ul>
            <form method="POST" action="{{ route('imports.upload') }}" enctype="multipart/form-data">
                @csrf
                <div class="mb-3">
                    <input type="file" name="file" class="form-control" required>
                </div>
                <button class="btn btn-primary">Upload & Import</button>
            </form>
        </div>
    </div>
    <p>Note: For better Excel support install <code>phpoffice/phpspreadsheet</code> via Composer.</p>
    <pre>composer require phpoffice/phpspreadsheet</pre>
</div>
@endsection
