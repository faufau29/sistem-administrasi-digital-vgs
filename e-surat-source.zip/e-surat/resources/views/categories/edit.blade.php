@extends('layouts.app')

@section('content')
<div class="container">
    <h3>Edit Category</h3>
    <form method="POST" action="{{ route('categories.update', $category) }}">
        @csrf @method('PUT')
        <div class="mb-3">
            <label class="form-label">Name</label>
            <input name="name" class="form-control" required value="{{ $category->name }}">
        </div>
        <div class="mb-3">
            <label class="form-label">Code</label>
            <input name="code" class="form-control" value="{{ $category->code }}">
        </div>
        <div class="form-check mb-3">
            <input type="checkbox" name="is_active" class="form-check-input" {{ $category->is_active ? 'checked':'' }}>
            <label class="form-check-label">Active</label>
        </div>
        <button class="btn btn-primary">Update</button>
    </form>
</div>
@endsection
