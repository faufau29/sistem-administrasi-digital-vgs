@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Document Categories</h3>
        <a href="{{ route('categories.create') }}" class="btn btn-primary">New Category</a>
    </div>

    @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif

    <table class="table table-striped">
        <thead><tr><th>Name</th><th>Code</th><th>Active</th><th></th></tr></thead>
        <tbody>
        @foreach($categories as $c)
            <tr>
                <td>{{ $c->name }}</td>
                <td>{{ $c->code }}</td>
                <td>{{ $c->is_active ? 'Yes':'No' }}</td>
                <td>
                    <a href="{{ route('categories.edit', $c) }}" class="btn btn-sm btn-secondary">Edit</a>
                    <form action="{{ route('categories.destroy', $c) }}" method="POST" style="display:inline-block;" onsubmit="return confirm('Delete?')">
                        @csrf @method('DELETE')
                        <button class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>

    {{ $categories->links() }}
</div>
@endsection
