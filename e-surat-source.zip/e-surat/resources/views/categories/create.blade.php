@extends('layouts.app')

@section('content')
<div class="container">
    <h3>New Category</h3>
    <form method="POST" action="{{ route('categories.store') }}">
        @csrf
        <div class="mb-3">
            <label class="form-label">Name</label>
            <input name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Code</label>
            <input name="code" class="form-control">
        </div>
        <div class="form-check mb-3">
            <input type="checkbox" name="is_active" class="form-check-input" checked>
            <label class="form-check-label">Active</label>
        </div>
        <button class="btn btn-primary">Create</button>
    </form>
</div>
@endsection
