@extends('layouts.app')

@section('content')
<div class="container">
    <h3>Category Details</h3>
    <div class="card mb-3">
        <div class="card-body">
            <p><strong>Name:</strong> {{ $category->name }}</p>
            <p><strong>Code:</strong> {{ $category->code }}</p>
            <p><strong>Active:</strong> {{ $category->is_active ? 'Yes' : 'No' }}</p>
            <div class="mt-3">
                <a href="{{ route('categories.edit', $category) }}" class="btn btn-secondary">Edit</a>
                <form method="POST" action="{{ route('categories.destroy', $category) }}" style="display:inline-block;" onsubmit="return confirm('Delete this category?')">
                    @csrf @method('DELETE')
                    <button class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
