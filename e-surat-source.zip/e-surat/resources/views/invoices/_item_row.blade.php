<div class="invoice-item-row border rounded p-3">
    <div class="row g-2 align-items-end">
        <div class="col-lg-4">
            <label class="form-label">Skema pelatihan</label>
            <select name="items[{{ $index }}][training]" class="form-select" data-training required>
                <option value="">Pilih skema pelatihan</option>
                @foreach ($catalog as $code => $training)
                    <option value="{{ $code }}" @selected(($item['training'] ?? '') === $code)>{{ $training['name'] }}</option>
                @endforeach
                <option value="custom" @selected(($item['training'] ?? '') === 'custom')>Pelatihan lain / harga manual</option>
            </select>
        </div>
        <div class="col-lg-2 d-none" data-custom-fields>
            <label class="form-label">Nama pelatihan</label>
            <input name="items[{{ $index }}][description]" class="form-control" data-custom-description
                   value="{{ ($item['training'] ?? '') === 'custom' ? ($item['description'] ?? '') : '' }}"
                   maxlength="1000" placeholder="Nama skema atau pelatihan" disabled>
        </div>
        <div class="col-sm-4 col-lg-1">
            <label class="form-label">Qty</label>
            <input name="items[{{ $index }}][quantity]" type="number" min="1" max="999999" step="1"
                   class="form-control" data-quantity required value="{{ $item['quantity'] ?? 1 }}">
        </div>
        <div class="col-sm-8 col-lg-2">
            <label class="form-label">Harga per unit (Rp)</label>
            <input name="items[{{ $index }}][unit_price]" type="number" min="1" max="999999999999"
                   step="1" class="form-control" data-price
                   value="{{ ($item['training'] ?? '') === 'custom' ? ($item['unit_price'] ?? '') : ($catalog[$item['training'] ?? '']['price'] ?? '') }}"
                   placeholder="Otomatis dari skema">
        </div>
        <div class="col-sm-8 col-lg-2 text-nowrap">
            <div class="form-label">Total</div>
            <strong class="text-nowrap" data-line-total>Rp 0</strong>
        </div>
        <div class="col-sm-4 col-lg-1 text-end">
            <button type="button" class="btn btn-sm btn-outline-danger" data-remove-item>Hapus baris</button>
        </div>
    </div>
</div>
