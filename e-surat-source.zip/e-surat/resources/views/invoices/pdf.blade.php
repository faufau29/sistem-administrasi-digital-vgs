<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Invoice {{ $invoice->full_number }}</title>
    <style>
        @page {
            margin: 96px 76px 60px;
        }

        body {
            margin: 0;
            color: #111;
            font-family: "DejaVu Serif", serif;
            font-size: 12px;
            line-height: 1.25;
        }

        .company-name {
            font-size: 16px;
            font-weight: bold;
        }

        .company-info {
            font-size: 11px;
        }

        .meta {
            width: 38%;
            margin: 6px 0 28px auto;
            line-height: 1.25;
        }

        .recipient {
            margin-bottom: 18px;
            line-height: 1.35;
        }

        .invoice-title {
            margin: 12px 0 18px;
            font-size: 15px;
            text-align: center;
        }

        table {
            width: 114%;
            margin-left: -7%;
            border-collapse: collapse;
            font-size: 12px;
        }

        th,
        td {
            border: 1px solid #111;
            padding: 5px 7px;
        }

        th {
            background: #c8c8c8;
            text-align: center;
        }

        th.price,
        th.total {
            text-align: center;
        }

        .description {
            width: 46%;
        }

        .qty {
            width: 9%;
            text-align: center;
        }

        .price {
            width: 22%;
            text-align: right;
            white-space: nowrap;
        }

        .total {
            width: 23%;
            text-align: right;
            white-space: nowrap;
        }

        .summary-label {
            background: #c8c8c8;
            font-weight: bold;
            text-align: center;
        }

        .bank-info {
            background: #c8c8c8;
            font-size: 11px;
            font-weight: bold;
            line-height: 1.25;
        }

        .spacer-row td {
            height: 28px;
            padding: 0;
        }

        .remaining {
            background: #c8c8c8;
            font-weight: bold;
            text-align: right;
        }

        .note {
            margin: 5px 0 0 4px;
        }

        .closing {
            width: 40%;
            margin: 16px 0 0 auto;
            text-align: center;
        }

        .signature-space {
            height: 12px;
        }

        .signature-image {
            display: block;
            width: 190px;
            height: auto;
            margin: 0 auto;
        }

        .signatory-name {
            font-family: "DejaVu Serif", serif;
            font-size: 14px;
            font-weight: bold;
            line-height: 1.2;
            text-decoration: underline;
        }

        .signatory-title {
            font-family: Arial, sans-serif;
            font-size: 13px;
            line-height: 1.2;
        }
    </style>
</head>
<body>
    @php
        $total = (float) $invoice->amount;
        $tax = $invoice->taxAmount();
        $lineItems = $invoice->lineItems();
        $downPayment = (float) ($invoice->down_payment ?? 0);
        $grossTotal = $invoice->totalWithTax();
        $remaining = max(0, $grossTotal - $downPayment);
    @endphp

    <div class="company-name">PT. Veritrust Global Solusindo</div>
    <div class="company-info">
        Komplek NABE Blok A2 No 6 Banjar Agung Cipocok Jaya Kota Serang<br>
        Phone: 0818 1881 0021<br>
        office@veritrust.id
    </div>

    <div class="meta">
        Nomor&nbsp; : {{ $invoice->full_number }}<br>
        Tanggal : {{ \Carbon\Carbon::parse($invoice->date)->format('d/m/Y') }}
    </div>

    <div class="recipient">
        <strong>Bill To:</strong><br>
        <strong>{{ $invoice->recipient }}</strong><br><br>
        Di<br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tempat
    </div>

    <h1 class="invoice-title">INVOICE</h1>

    <table>
        <thead>
            <tr>
                <th class="description">Item Description</th>
                <th class="qty">Qty</th>
                <th class="price">Price Per</th>
                <th class="total">Total</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($lineItems as $item)
                <tr>
                    <td>{!! nl2br(e($item->description)) !!}</td>
                    <td class="qty">{{ number_format($item->quantity, 0, ',', '.') }}</td>
                    <td class="price">Rp. {{ number_format((float) $item->unit_price, 0, ',', '.') }}</td>
                    <td class="total">Rp. {{ number_format((float) $item->line_total, 0, ',', '.') }}</td>
                </tr>
            @endforeach
            @if ($tax > 0)
                <tr>
                    <td style="text-align: right">PPn Nilai Lain</td>
                    <td></td>
                    <td></td>
                    <td class="total">Rp. {{ number_format($tax, 0, ',', '.') }}</td>
                </tr>
            @endif
            @if ($downPayment > 0)
                <tr>
                    <td style="text-align: right">DP</td>
                    <td></td>
                    <td></td>
                    <td class="total">-Rp. {{ number_format($downPayment, 0, ',', '.') }}</td>
                </tr>
            @endif
            <tr class="spacer-row">
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td class="bank-info">
                    Bank BCA : 5421-1822-22<br>
                    Bank Mandiri : 163-00-0332556-3<br>
                    a.n. PT VERITRUST GLOBAL SOLUSINDO
                </td>
                <td class="bank-info"></td>
                <td class="summary-label">{{ $downPayment > 0 ? 'TOTAL SISA' : 'TOTAL' }}</td>
                <td class="remaining">Rp. {{ number_format($downPayment > 0 ? $remaining : $grossTotal, 0, ',', '.') }}</td>
            </tr>
        </tbody>
    </table>

    @if ($invoice->paymentNote())
        <p class="note">{{ $invoice->paymentNote() }}</p>
    @endif

    <div class="closing">
        Hormat Kami,
        <div class="signature-space"></div>
        <img class="signature-image"
             src="data:image/png;base64,{{ base64_encode(file_get_contents(public_path($invoice->requiresStamp()
                 ? 'images/invoice-signature-stamped-mark.png'
                 : 'images/invoice-signature-mark.png'))) }}"
             alt="Tanda tangan Fitriyah, S.Si., M.Si{{ $invoice->requiresStamp() ? ' dengan meterai' : '' }}">
        <div class="signatory-name">Fitriyah, S.Si., M.Si</div>
        <div class="signatory-title">General Manager</div>
    </div>
</body>
</html>
