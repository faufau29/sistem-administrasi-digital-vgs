<form method="POST" action="{{ $invoice ? route('invoices.update', $invoice) : route('invoices.store') }}">
    @csrf
    @if ($invoice)
        @method('PUT')
    @endif

    @if ($errors->any())
        <div class="alert alert-danger" role="alert">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @php
        $catalog = $trainingCatalog ?? config('invoice_trainings');
        $formItems = old('items');

        if (! is_array($formItems)) {
            $formItems = $invoice
                ? $invoice->lineItems()->map(fn ($item) => [
                    'training' => $item->training_code && isset($catalog[$item->training_code]) ? $item->training_code : 'custom',
                    'description' => $item->description,
                    'quantity' => $item->quantity,
                    'unit_price' => $item->unit_price,
                ])->all()
                : [['training' => '', 'description' => '', 'quantity' => 1, 'unit_price' => '']];
        }

        if ($formItems === []) {
            $formItems = [['training' => '', 'description' => '', 'quantity' => 1, 'unit_price' => '']];
        }
    @endphp

    <div class="card">
        <div class="card-body p-4">
            <div class="row g-3">
                <div class="col-md-6">
                    <label for="recipient" class="form-label">Ditagihkan kepada</label>
                    <input id="recipient" name="recipient" class="form-control" required maxlength="255"
                           value="{{ old('recipient', $invoice?->recipient) }}" placeholder="Nama pelanggan">
                </div>
                <div class="col-md-6">
                    <label for="client_type" class="form-label">Jenis klien</label>
                    <select id="client_type" name="client_type" class="form-select" required>
                        @foreach (['individual' => 'Perorangan (tanpa PPn)', 'company' => 'Perusahaan (PPn Nilai Lain 11%)'] as $value => $label)
                            <option value="{{ $value }}" @selected(old('client_type', $invoice?->client_type ?? 'individual') === $value)>
                                {{ $label }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="date" class="form-label">Tanggal invoice</label>
                    <input id="date" type="date" name="date" class="form-control" required
                           value="{{ old('date', $invoice?->date ?? now()->toDateString()) }}">
                </div>
                <div class="col-md-6">
                    <label for="full_number" class="form-label">Nomor invoice</label>
                    <input id="full_number" name="full_number" class="form-control" maxlength="30"
                           value="{{ old('full_number', $invoice?->full_number ?? $nextNumber ?? '') }}"
                           placeholder="Contoh: 539 - VTR" aria-describedby="invoice-number-help"
                           @required($invoice)>
                    <div id="invoice-number-help" class="form-text">
                        Format nomor: angka - VTR. Nomor awal dibuat otomatis dan dapat diedit; nomor yang sudah digunakan ditolak.
                    </div>
                </div>
                <div class="col-12">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                        <div>
                            <label class="form-label mb-0">Daftar pelatihan / skema</label>
                            <div class="form-text mt-0">Pilih skema untuk mengisi harga otomatis seperti contoh invoice.</div>
                        </div>
                        <button id="add-invoice-item" type="button" class="btn btn-sm btn-outline-primary">Tambah pelatihan</button>
                    </div>
                    <div id="invoice-items" class="d-flex flex-column gap-2">
                        @foreach ($formItems as $index => $item)
                            @include('invoices._item_row', ['index' => $index, 'item' => $item, 'catalog' => $catalog])
                        @endforeach
                    </div>
                    <div class="text-end mt-3">
                        <div>Subtotal: <strong class="text-nowrap" id="invoice-subtotal">Rp 0</strong></div>
                        <div id="invoice-tax-row" class="d-none">PPn Nilai Lain (11%): <strong class="text-nowrap" id="invoice-tax">Rp 0</strong></div>
                        <div class="fs-5">Total invoice: <strong class="text-nowrap" id="invoice-total">Rp 0</strong></div>
                    </div>
                </div>
                <div class="col-md-4">
                    <label for="down_payment" class="form-label">Uang muka / DP (Rp)</label>
                    <input id="down_payment" type="number" name="down_payment" class="form-control" min="0"
                           max="999999999999999999" step="1"
                           value="{{ old('down_payment', $invoice?->down_payment ?: '') }}"
                           placeholder="Kosongkan jika tidak ada DP">
                </div>
                <div class="col-md-6">
                    <label for="status" class="form-label">Status</label>
                    <select id="status" name="status" class="form-select" required>
                        @foreach (['draft' => 'Draft', 'issued' => 'Diterbitkan', 'paid' => 'Lunas'] as $value => $label)
                            <option value="{{ $value }}" @selected(old('status', $invoice?->status ?? 'draft') === $value)>
                                {{ $label }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>
        </div>
        <div class="card-footer bg-white d-flex justify-content-end gap-2 p-3">
            <a href="{{ $invoice ? route('invoices.show', $invoice) : route('invoices.index') }}"
               class="btn btn-outline-secondary">Batal</a>
            <button class="btn btn-primary" type="submit">{{ $invoice ? 'Simpan Perubahan' : 'Buat Invoice' }}</button>
        </div>
    </div>
</form>

<template id="invoice-item-template">
    @include('invoices._item_row', [
        'index' => '__INDEX__',
        'item' => ['training' => '', 'description' => '', 'quantity' => 1, 'unit_price' => ''],
        'catalog' => $catalog,
    ])
</template>

<script>
    const trainingCatalog = @json($catalog);
    const itemList = document.getElementById('invoice-items');
    let nextItemIndex = {{ max(array_map('intval', array_keys($formItems))) + 1 }};

    function formatRupiah(value) {
        return 'Rp ' + new Intl.NumberFormat('id-ID').format(value || 0);
    }

    function updateInvoiceTotals() {
        let subtotal = 0;
        itemList.querySelectorAll('.invoice-item-row').forEach((row) => {
            const quantity = Number(row.querySelector('[data-quantity]').value) || 0;
            const price = Number(row.querySelector('[data-price]').value) || 0;
            const lineTotal = quantity * price;
            subtotal += lineTotal;
            row.querySelector('[data-line-total]').textContent = formatRupiah(lineTotal);
        });

        const isCompany = document.getElementById('client_type').value === 'company';
        const tax = isCompany ? Math.round(subtotal * 0.11) : 0;
        document.getElementById('invoice-subtotal').textContent = formatRupiah(subtotal);
        document.getElementById('invoice-tax').textContent = formatRupiah(tax);
        document.getElementById('invoice-tax-row').classList.toggle('d-none', !isCompany || tax === 0);
        document.getElementById('invoice-total').textContent = formatRupiah(subtotal + tax);
    }

    function configureInvoiceItem(row) {
        const training = row.querySelector('[data-training]');
        const description = row.querySelector('[data-custom-description]');
        const price = row.querySelector('[data-price]');
        const custom = training.value === 'custom';
        const selectedTraining = trainingCatalog[training.value];

        row.querySelector('[data-custom-fields]').classList.toggle('d-none', !custom);
        description.disabled = !custom;
        description.required = custom;
        price.readOnly = false;
        price.required = Boolean(training.value);

        updateInvoiceTotals();
    }

    itemList.addEventListener('change', (event) => {
        const row = event.target.closest('.invoice-item-row');
        if (row && event.target.matches('[data-training]')) {
            configureInvoiceItem(row);
            const selectedTraining = trainingCatalog[event.target.value];
            if (selectedTraining) {
                row.querySelector('[data-price]').value = selectedTraining.price;
                updateInvoiceTotals();
            } else if (event.target.value === 'custom') {
                row.querySelector('[data-price]').value = '';
                updateInvoiceTotals();
            }
        } else {
            updateInvoiceTotals();
        }
    });
    itemList.addEventListener('input', updateInvoiceTotals);
    itemList.addEventListener('click', (event) => {
        if (event.target.matches('[data-remove-item]')) {
            const row = event.target.closest('.invoice-item-row');
            if (itemList.querySelectorAll('.invoice-item-row').length === 1) {
                row.querySelector('[data-training]').value = '';
                row.querySelector('[data-custom-description]').value = '';
                row.querySelector('[data-quantity]').value = 1;
                row.querySelector('[data-price]').value = '';
                configureInvoiceItem(row);
            } else {
                row.remove();
            }
            updateInvoiceTotals();
        }
    });

    document.getElementById('add-invoice-item').addEventListener('click', () => {
        const html = document.getElementById('invoice-item-template').innerHTML.replaceAll('__INDEX__', nextItemIndex++);
        itemList.insertAdjacentHTML('beforeend', html);
        configureInvoiceItem(itemList.lastElementChild);
    });
    document.getElementById('client_type').addEventListener('change', updateInvoiceTotals);
    document.querySelectorAll('.invoice-item-row').forEach(configureInvoiceItem);
    updateInvoiceTotals();
</script>
