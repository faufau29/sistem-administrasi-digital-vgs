@extends('layouts.app')

@section('content')
<div class="container">
    <div class="mb-4">
        <a href="{{ route('invoices.show', $invoice) }}" class="text-decoration-none">&larr; Kembali ke invoice</a>
        <h3 class="mt-2 mb-1">Edit Invoice</h3>
        <p class="text-muted mb-0">Nomor invoice dapat diperbarui selama belum digunakan invoice lain.</p>
    </div>

    @include('invoices._form', ['invoice' => $invoice])
</div>
@endsection
