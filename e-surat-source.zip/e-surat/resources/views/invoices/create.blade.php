@extends('layouts.app')

@section('content')
<div class="container">
    <div class="mb-4">
        <a href="{{ route('invoices.index') }}" class="text-decoration-none">&larr; Kembali ke invoice</a>
        <h3 class="mt-2 mb-1">Buat Invoice</h3>
        <p class="text-muted mb-0">
            <strong>Nomor invoice:</strong> terisi otomatis dan dapat diedit sebelum disimpan.
        </p>
    </div>

    @include('invoices._form', ['invoice' => null])
</div>
@endsection
