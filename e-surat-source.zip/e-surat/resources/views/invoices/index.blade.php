@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <h3 class="mb-0">Invoice</h3>
        <div class="d-flex flex-wrap gap-2">
            <a href="{{ route('invoices.create') }}" class="btn btn-primary">Buat Invoice</a>
            <a href="{{ route('invoices.export', ['format' => 'csv', 'search' => request('search'), 'month' => request('month'), 'year' => request('year')]) }}"
               class="btn btn-outline-secondary">Ekspor CSV</a>
            <a href="{{ route('invoices.export', ['format' => 'xlsx', 'search' => request('search'), 'month' => request('month'), 'year' => request('year')]) }}"
               class="btn btn-outline-secondary">Ekspor Excel</a>
        </div>
    </div>

    <form class="row g-2 mb-3" method="GET">
        <div class="col-md-5">
            <input name="search" value="{{ request('search') }}" class="form-control"
                   placeholder="Cari nomor, penerima, atau status">
        </div>
        <div class="col-md-3">
            <select name="month" class="form-select" aria-label="Filter bulan">
                <option value="">Semua bulan</option>
                @foreach ([
                    1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
                    5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
                    9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember',
                ] as $monthNumber => $monthName)
                    <option value="{{ $monthNumber }}" @selected((string) request('month') === (string) $monthNumber)>{{ $monthName }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-md-2">
            <input type="number" name="year" value="{{ request('year') }}" class="form-control"
                   min="1900" max="9999" placeholder="Tahun" aria-label="Filter tahun">
        </div>
        <div class="col-md-2 d-flex gap-2">
            <button class="btn btn-outline-secondary">Filter</button>
            <a href="{{ route('invoices.index') }}" class="btn btn-outline-secondary">Reset</a>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-striped align-middle">
            <thead>
                <tr><th>Nomor</th><th>Tanggal</th><th>Penerima</th><th>Total</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
            @forelse ($invoices as $invoice)
                <tr>
                    <td>{{ $invoice->full_number }}</td>
                    <td>{{ \Carbon\Carbon::parse($invoice->date)->format('d/m/Y') }}</td>
                    <td>{{ $invoice->recipient }}</td>
                    <td>Rp {{ number_format($invoice->totalWithTax(), 0, ',', '.') }}</td>
                    <td>{{ ucfirst($invoice->status) }}</td>
                    <td class="text-nowrap">
                        <a href="{{ route('invoices.show', $invoice) }}" class="btn btn-sm btn-outline-primary">Lihat</a>
                        <a href="{{ route('invoices.edit', $invoice) }}" class="btn btn-sm btn-outline-secondary">Edit</a>
                        <a href="{{ route('invoices.pdf', $invoice) }}" class="btn btn-sm btn-outline-secondary" target="_blank" rel="noopener">PDF</a>
                    </td>
                </tr>
            @empty
                <tr><td colspan="6" class="py-4 text-center text-muted">Belum ada invoice.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
        <p class="mb-0 text-muted">
            Menampilkan {{ $invoices->firstItem() ?? 0 }} s/d {{ $invoices->lastItem() ?? 0 }}
            dari <strong>{{ $invoices->total() }} data</strong>
        </p>
        {{ $invoices->links('pagination.invoices') }}
    </div>
</div>
@endsection
