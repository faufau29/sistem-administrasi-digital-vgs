@extends('layouts.app')

@section('content')
@php
    $total = $invoice->totalWithTax();
    $subtotal = (float) $invoice->amount;
    $tax = $invoice->taxAmount();
    $downPayment = (float) ($invoice->down_payment ?? 0);
    $remaining = max(0, $total - $downPayment);
    $lineItems = $invoice->lineItems();
@endphp
<div class="container">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
        <div>
            <a href="{{ route('invoices.index') }}" class="text-decoration-none">&larr; Kembali ke daftar invoice</a>
            <h3 class="mt-2 mb-0">Invoice {{ $invoice->full_number }}</h3>
        </div>
        <div class="d-flex gap-2">
            <a href="{{ route('invoices.word', $invoice) }}" class="btn btn-outline-primary" target="_blank" rel="noopener">Unduh Word</a>
            <a href="{{ route('invoices.pdf', $invoice) }}" class="btn btn-primary" target="_blank" rel="noopener">Unduh / Cetak PDF</a>
            <a href="{{ route('invoices.edit', $invoice) }}" class="btn btn-outline-secondary">Edit</a>
        </div>
    </div>

    <div class="card">
        <div class="card-body p-4">
            <div class="row g-3">
                <div class="col-md-6"><strong>Nomor:</strong> {{ $invoice->full_number }}</div>
                <div class="col-md-6"><strong>Tanggal:</strong> {{ \Carbon\Carbon::parse($invoice->date)->format('d/m/Y') }}</div>
                <div class="col-md-6"><strong>Ditagihkan kepada:</strong> {{ $invoice->recipient }}</div>
                <div class="col-md-6"><strong>Jenis klien:</strong> {{ $invoice->client_type === 'company' ? 'Perusahaan' : 'Perorangan' }}</div>
                <div class="col-md-6"><strong>Status:</strong> {{ ucfirst($invoice->status) }}</div>
                <div class="col-12">
                    <strong>Rincian pelatihan:</strong>
                    <div class="table-responsive mt-2">
                        <table class="table table-bordered align-middle mb-0">
                            <thead class="table-light">
                                <tr><th>Pelatihan / Skema</th><th class="text-center">Qty</th><th class="text-end">Harga per unit</th><th class="text-end">Total</th></tr>
                            </thead>
                            <tbody>
                                @foreach ($lineItems as $item)
                                    <tr>
                                        <td>{{ $item->description }}</td>
                                        <td class="text-center">{{ number_format($item->quantity, 0, ',', '.') }}</td>
                                        <td class="text-end">Rp {{ number_format((float) $item->unit_price, 0, ',', '.') }}</td>
                                        <td class="text-end">Rp {{ number_format((float) $item->line_total, 0, ',', '.') }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr><th colspan="3" class="text-end">Subtotal</th><th class="text-end">Rp {{ number_format($subtotal, 0, ',', '.') }}</th></tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                @if ($tax > 0)
                    <div class="col-md-4"><strong>PPn Nilai Lain 11%:</strong> Rp {{ number_format($tax, 0, ',', '.') }}</div>
                @endif
                <div class="col-md-4"><strong>Total invoice:</strong> Rp {{ number_format($total, 0, ',', '.') }}</div>
                @if ($downPayment > 0)
                    <div class="col-md-6"><strong>DP:</strong> Rp {{ number_format($downPayment, 0, ',', '.') }}</div>
                @endif
                <div class="col-md-6"><strong>Sisa tagihan:</strong> Rp {{ number_format($remaining, 0, ',', '.') }}</div>
            </div>
            @if ($invoice->requiresStamp())
                <div class="alert alert-warning mt-4 mb-0">
                    Meterai otomatis disertakan pada dokumen invoice karena totalnya Rp5.000.000 atau lebih.
                </div>
            @endif
            <div class="mt-4">
                <form method="POST" action="{{ route('invoices.destroy', $invoice) }}"
                      onsubmit="return confirm('Yakin ingin menghapus invoice ini?')">
                    @csrf
                    @method('DELETE')
                    <button class="btn btn-outline-danger" type="submit">Hapus Invoice</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
