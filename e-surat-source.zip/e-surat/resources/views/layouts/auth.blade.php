<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#250b58">
    <title>@yield('title') - E-Surat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --ink: #231545;
            --muted: #746b89;
            --purple: #7c3aed;
            --purple-dark: #250b58;
            --accent: #f5c842;
        }

        * {
            box-sizing: border-box;
        }

        body {
            min-height: 100vh;
            margin: 0;
            color: #fff;
            background:
                radial-gradient(ellipse at 91% 12%, rgba(128, 43, 227, .48), transparent 34%),
                radial-gradient(ellipse at 65% 100%, rgba(109, 39, 219, .52), transparent 40%),
                linear-gradient(112deg, #1a0648 0%, #310879 54%, #50119a 100%);
            font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        }

        .auth-shell {
            width: min(100%, 1440px);
            min-height: 100vh;
            display: grid;
            grid-template-columns: minmax(0, 1.35fr) minmax(360px, .75fr);
            align-items: stretch;
            gap: clamp(40px, 6vw, 88px);
            overflow: hidden;
            padding: 42px clamp(32px, 4vw, 56px);
        }

        .auth-aside {
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            min-width: 0;
            min-height: 0;
            padding: 4px 0 0;
            color: #fff;
        }

        .auth-architecture {
            position: absolute;
            z-index: 0;
            right: -12px;
            bottom: -35px;
            width: min(58%, 430px);
            height: 390px;
            color: #d3a8ff;
            opacity: .16;
            pointer-events: none;
        }

        .brand {
            display: inline-flex;
            align-items: center;
            align-self: flex-start;
            width: fit-content;
            margin: 0;
            color: #fff;
            font-size: .76rem;
            font-weight: 600;
            letter-spacing: .12em;
            text-transform: uppercase;
        }

        .brand-logo-card {
            display: grid;
            width: 198px;
            flex: 0 0 auto;
            place-items: center;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, .72);
            border-radius: 12px;
            background: #fff;
            box-shadow: 0 8px 26px rgba(10, 4, 34, .18);
        }

        .brand-logo {
            display: block;
            width: 100%;
            height: auto;
        }

        .aside-copy {
            position: relative;
            z-index: 1;
            max-width: 600px;
            margin: 24px 0 0;
        }

        .aside-label {
            display: inline-flex;
            align-items: center;
            gap: 0;
            margin-bottom: 13px;
            padding: 7px 15px;
            border: 1px solid rgba(255, 255, 255, .1);
            border-radius: 999px;
            background: rgba(255, 255, 255, .1);
            color: var(--accent);
            font-size: .8rem;
            font-weight: 700;
            letter-spacing: .01em;
        }

        .aside-label::before {
            content: none;
        }

        .aside-copy h1 {
            max-width: 680px;
            margin-bottom: 12px;
            font-size: clamp(3rem, 4.7vw, 4rem);
            font-weight: 800;
            letter-spacing: -.04em;
            line-height: .91;
            text-transform: uppercase;
        }

        .aside-copy h1 span {
            color: var(--accent);
        }

        .aside-copy p,
        .aside-footer {
            color: rgba(255, 255, 255, .78);
            font-size: .98rem;
            line-height: 1.75;
        }

        .aside-copy > p:last-child {
            max-width: 510px;
            margin: 0;
            font-size: .98rem;
            line-height: 1.42;
        }

        .aside-features {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 110px));
            gap: 14px;
            margin: 19px 0 0;
            padding: 0;
            color: #fff;
            font-size: .82rem;
            list-style: none;
        }

        .aside-features li {
            display: flex;
            min-width: 0;
            min-height: 96px;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 12px 8px;
            border: 1px solid rgba(255, 255, 255, .13);
            border-radius: 20px;
            background: rgba(255, 255, 255, .09);
            backdrop-filter: blur(8px);
            line-height: 1.35;
            text-align: center;
        }

        .aside-features svg {
            flex: 0 0 auto;
            width: 32px;
            height: 32px;
            color: #ffd21f;
        }

        .aside-footer {
            position: relative;
            z-index: 1;
            margin: auto 0 0;
            padding-top: 0;
            color: #f5d96d;
            font-size: .94rem;
            font-style: italic;
            font-weight: 600;
            letter-spacing: .025em;
        }

        .auth-main {
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 0;
            padding: 0;
            transform: translateY(-13px);
        }

        .auth-content {
            width: 100%;
            max-width: 404px;
            padding: 47px 32px 43px;
            border: 1px solid rgba(255, 255, 255, .2);
            border-radius: 30px;
            background: rgba(255, 255, 255, .13);
            box-shadow: 0 24px 70px rgba(15, 2, 44, .24), inset 0 1px 0 rgba(255, 255, 255, .16);
            backdrop-filter: blur(18px);
        }

        .form-symbol {
            display: grid;
            width: 62px;
            height: 62px;
            margin: 0 auto 8px;
            place-items: center;
            border: 1px solid rgba(255, 255, 255, .18);
            border: 0;
            background: transparent;
            color: #ffd21f;
        }

        .form-symbol svg {
            width: 56px;
            height: 56px;
        }

        .form-kicker {
            display: none;
        }

        .form-title {
            text-align: center;
            margin-bottom: 2px;
            color: #fff;
            font-size: 2.25rem;
            font-weight: 800;
            letter-spacing: -.035em;
            text-transform: uppercase;
        }

        .form-description {
            text-align: center;
            margin-bottom: 22px;
            color: rgba(255, 255, 255, .86);
            font-size: .86rem;
            line-height: 1.5;
        }

        .form-label {
            margin-bottom: 9px;
            color: rgba(255, 255, 255, .94);
            font-size: .875rem;
            font-weight: 600;
        }

        .auth-input-wrap {
            position: relative;
        }

        .auth-input-icon {
            position: absolute;
            z-index: 2;
            top: 50%;
            left: 15px;
            width: 19px;
            height: 19px;
            color: #7783a0;
            transform: translateY(-50%);
            pointer-events: none;
        }

        .form-control {
            min-height: 50px;
            border-color: rgba(255, 255, 255, .8);
            border-radius: 12px;
            color: #2b2042;
            font-size: .9rem;
            background-color: rgba(255, 255, 255, .97);
            box-shadow: 0 1px 2px rgba(31, 57, 77, .08);
            transition: border-color .2s ease, box-shadow .2s ease;
        }

        .auth-input-wrap .form-control {
            padding-left: 46px;
        }

        .password-wrap .form-control {
            padding-left: 12px;
        }

        .auth-input-wrap .form-control.has-password-toggle {
            padding-right: 48px;
        }

        .password-toggle {
            position: absolute;
            z-index: 3;
            top: 50%;
            right: 12px;
            display: grid;
            width: 34px;
            height: 34px;
            padding: 0;
            place-items: center;
            border: 0;
            border-radius: 9px;
            background: transparent;
            color: #7783a0;
            transform: translateY(-50%);
            transition: background-color .15s ease, color .15s ease;
        }

        .password-toggle:hover {
            background: #f0edf8;
            color: #5628a0;
        }

        .password-toggle:focus-visible {
            outline: 2px solid #8b5cf6;
            outline-offset: 1px;
        }

        .password-toggle svg {
            width: 19px;
            height: 19px;
        }

        .password-toggle .eye-off {
            display: none;
        }

        .password-toggle[aria-pressed="true"] .eye {
            display: none;
        }

        .password-toggle[aria-pressed="true"] .eye-off {
            display: block;
        }

        .auth-login-form .mb-4 {
            margin-bottom: 12px !important;
        }

        .form-control::placeholder {
            color: #9aa9b8;
        }

        .form-control:focus {
            border-color: #e0b7ff;
            box-shadow: 0 0 0 4px rgba(224, 183, 255, .2);
        }

        .remember-row {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: -5px 0 17px;
            color: rgba(255, 255, 255, .94);
            font-size: .82rem;
        }

        .remember-row .form-check-input {
            width: 17px;
            height: 17px;
            margin: 0;
            border-color: rgba(255, 255, 255, .8);
            border-radius: 4px;
            cursor: pointer;
        }

        .remember-row .form-check-input:checked {
            border-color: #f4c51d;
            background-color: #f4c51d;
        }

        .remember-row label {
            cursor: pointer;
        }

        .btn-auth {
            min-height: 54px;
            border: 1px solid rgba(255, 255, 255, .2);
            border-radius: 14px;
            background: linear-gradient(105deg, #d946ef, #8b5cf6);
            color: #fff;
            font-size: .96rem;
            font-weight: 700;
            box-shadow: 0 10px 24px rgba(22, 5, 65, .25);
            transition: background .2s ease, transform .2s ease, box-shadow .2s ease;
        }

        .btn-auth:hover {
            transform: translateY(-2px);
            background: linear-gradient(105deg, #e452ec, #9b6cff);
            color: #fff;
            box-shadow: 0 13px 28px rgba(22, 5, 65, .32);
        }

        .btn-auth:focus-visible,
        .auth-switch a:focus-visible,
        .brand:focus-visible {
            outline: 3px solid rgba(245, 200, 66, .72);
            outline-offset: 3px;
        }

        .auth-switch {
            margin: 17px 0 0;
            padding: 0;
            border: 0;
            color: rgba(255, 255, 255, .9);
            font-size: .82rem;
            text-align: center;
        }

        .auth-switch a {
            color: #ffd21f;
            font-weight: 650;
            text-decoration: none;
        }

        .auth-switch a:hover {
            text-decoration: underline;
        }

        .alert {
            margin-bottom: 22px;
            border-radius: 12px;
            font-size: .88rem;
        }

        @media (max-width: 900px) {
            body {
                align-items: start;
            }

            .auth-shell {
                min-height: 0;
                grid-template-columns: 1fr;
                align-items: start;
                gap: 34px;
                padding: 32px clamp(22px, 6vw, 54px);
            }

            .auth-aside {
                min-height: 0;
                padding: 0;
            }

            .brand {
                margin-bottom: 0;
                font-size: .67rem;
            }

            .brand-logo-card {
                width: min(42vw, 230px);
            }

            .aside-copy {
                margin: 34px 0 0;
            }

            .aside-label {
                margin-bottom: 13px;
                font-size: .66rem;
            }

            .aside-copy h1 {
                max-width: 500px;
                margin-bottom: 12px;
                font-size: clamp(2.5rem, 8vw, 3.6rem);
            }

            .aside-copy > p:last-child {
                font-size: .9rem;
            }

            .aside-features {
                grid-template-columns: repeat(4, minmax(0, 1fr));
                max-width: 520px;
                gap: 10px;
                margin-top: 20px;
            }

            .aside-features li {
                min-height: 84px;
                padding: 10px 6px;
                font-size: .72rem;
            }

            .aside-footer {
                margin-top: 24px;
                padding-top: 0;
            }

            .auth-main {
                padding: 0;
                transform: none;
            }

            .auth-content {
                max-width: 460px;
                padding: 30px 26px 26px;
                border-radius: 24px;
            }

            .form-description {
                margin-bottom: 23px;
                font-size: .86rem;
            }
        }

        @media (max-width: 520px) {
            .auth-shell {
                gap: 28px;
                padding: 26px 20px 34px;
            }

            .aside-copy {
                margin-top: 28px;
            }

            .aside-copy h1 {
                font-size: clamp(2.2rem, 11vw, 3rem);
            }

            .aside-features {
                grid-template-columns: repeat(2, minmax(0, 110px));
                gap: 9px;
            }

            .aside-features li {
                min-height: 76px;
                font-size: .75rem;
            }

            .auth-content {
                padding: 25px 21px 23px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                scroll-behavior: auto !important;
                transition-duration: .01ms !important;
            }

            .btn-auth:hover {
                transform: none;
            }
        }
    </style>
</head>
<body>
    <main class="auth-shell">
        <aside class="auth-aside">
            <a class="brand text-decoration-none" href="{{ url('/') }}">
                <span class="brand-logo-card">
                    <img class="brand-logo" src="{{ asset('images/veritrus-logo.png') }}" alt="Logo Veritrus">
                </span>
            </a>
            <svg class="auth-architecture" aria-hidden="true" focusable="false" viewBox="0 0 430 390" fill="none">
                <path d="M92 390V142l92-48 92 48v248M276 390V194l91-45 63 31v210M35 390V220l57-30" stroke="currentColor" stroke-width="5"/>
                <path d="M92 142h184M92 184h184M92 226h184M92 268h184M92 310h184M92 352h184M276 224h154M276 264h154M276 304h154M276 344h154" stroke="currentColor" stroke-width="3"/>
                <path d="M114 159v18m32-18v18m32-18v18m32-18v18m32-18v18m-128 24v18m32-18v18m32-18v18m32-18v18m32-18v18m-128 24v18m32-18v18m32-18v18m32-18v18m32-18v18m-128 24v18m32-18v18m32-18v18m32-18v18m32-18v18m-128 24v18m32-18v18m32-18v18m32-18v18m32-18v18M300 207v20m34-20v20m34-20v20m34-20v20m-102 18v20m34-20v20m34-20v20m34-20v20m-102 18v20m34-20v20m34-20v20m34-20v20m-102 18v20m34-20v20m34-20v20m34-20v20" stroke="currentColor" stroke-width="3"/>
            </svg>
            <div class="aside-copy">
                <h1>Sistem<br>Administrasi<br>Digital<br><span>PT VGS</span></h1>
                <ul class="aside-features">
                    <li>
                        <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none">
                            <rect x="3" y="5" width="18" height="14" rx="2" stroke="currentColor" stroke-width="2"/>
                            <path d="m4 7 8 6 8-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        Akses dokumen
                    </li>
                    <li>
                        <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none">
                            <path d="M12 3 20 6v5c0 5-3.4 8.3-8 10-4.6-1.7-8-5-8-10V6l8-3Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
                            <path d="m8.5 12 2.2 2.2 4.8-5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        Keamanan data
                    </li>
                    <li>
                        <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none">
                            <circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2"/>
                            <path d="M12 7v5l3 2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        Proses lebih cepat
                    </li>
                    <li>
                        <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none">
                            <path d="M7 18h10a4 4 0 0 0 .7-7.9A6 6 0 0 0 6 8.5 4.8 4.8 0 0 0 7 18Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M12 15V9m0 0-2.5 2.5M12 9l2.5 2.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        Penyimpanan terpusat
                    </li>
                </ul>
            </div>
            <p class="aside-footer">Bersama Digital, Menuju Kerja Lebih Produktif.</p>
        </aside>
        <section class="auth-main">
            <div class="auth-content">
                @yield('form')
            </div>
        </section>
    </main>
    <script>
        document.querySelectorAll('[data-password-toggle]').forEach((toggle) => {
            const input = document.getElementById(toggle.dataset.passwordToggle);

            if (!input) {
                return;
            }

            toggle.addEventListener('click', () => {
                const isVisible = input.type === 'text';
                input.type = isVisible ? 'password' : 'text';
                toggle.setAttribute('aria-pressed', String(!isVisible));
                toggle.setAttribute('aria-label', isVisible ? 'Tampilkan kata sandi' : 'Sembunyikan kata sandi');
            });
        });
    </script>
</body>
</html>
