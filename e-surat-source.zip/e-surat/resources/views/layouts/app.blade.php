<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#250b58">
    <title>@yield('title', 'Dashboard') - E-Surat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            color-scheme: light;
            --app-ink: #2b194b;
            --app-muted: #786e8b;
            --app-purple: #7136bd;
            --app-purple-dark: #250b58;
            --app-lilac: #f3edfb;
            --app-gold: #f5c842;
            --app-line: #e9e2f2;
        }

        body {
            min-height: 100vh;
            margin: 0;
            color: var(--app-ink);
            background:
                radial-gradient(ellipse at 92% 0%, rgba(124, 58, 237, .06), transparent 34rem),
                #faf8fd;
            font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        }

        .app-header {
            position: relative;
            z-index: 10;
            color: #fff;
            background:
                radial-gradient(ellipse at 92% 0%, rgba(170, 105, 255, .3), transparent 28rem),
                linear-gradient(112deg, #1a0648 0%, #310879 58%, #50119a 100%);
            box-shadow: 0 8px 26px rgba(31, 8, 69, .16);
        }

        .app-header-inner {
            display: flex;
            width: min(100% - 48px, 1360px);
            min-height: 82px;
            align-items: center;
            gap: 1.5rem;
            margin: 0 auto;
        }

        .app-brand {
            display: inline-flex;
            flex: 0 0 auto;
            align-items: center;
            gap: 12px;
            color: #fff;
            text-decoration: none;
        }

        .app-brand-logo {
            display: block;
            width: 148px;
            height: auto;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, .7);
            border-radius: 9px;
            background: #fff;
        }

        .app-brand-caption {
            color: rgba(255, 255, 255, .78);
            font-size: .68rem;
            font-weight: 700;
            letter-spacing: .13em;
            line-height: 1.35;
            text-transform: uppercase;
        }

        .app-navigation {
            display: flex;
            min-width: 0;
            flex: 1 1 auto;
            align-items: center;
            gap: 3px;
        }

        .app-navigation .nav-link {
            display: inline-flex;
            min-height: 40px;
            align-items: center;
            padding: .55rem .72rem;
            border-radius: 10px;
            color: rgba(255, 255, 255, .8);
            font-size: .87rem;
            font-weight: 600;
            white-space: nowrap;
            transition: background-color .15s ease, color .15s ease;
        }

        .app-navigation .nav-link:hover,
        .app-navigation .nav-link.active {
            background: rgba(255, 255, 255, .14);
            color: #fff;
        }

        .app-navigation .nav-link.active {
            box-shadow: inset 0 -2px 0 var(--app-gold);
        }

        .app-user {
            display: flex;
            flex: 0 0 auto;
            align-items: center;
            gap: 12px;
            margin-left: auto;
        }

        .app-user-name {
            max-width: 150px;
            overflow: hidden;
            color: rgba(255, 255, 255, .92);
            font-size: .85rem;
            font-weight: 600;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .app-logout {
            padding: .48rem .78rem;
            border: 1px solid rgba(255, 255, 255, .32);
            border-radius: 10px;
            color: #fff;
            font-size: .83rem;
            font-weight: 650;
            transition: background-color .15s ease, border-color .15s ease;
        }

        .app-logout:hover {
            border-color: rgba(245, 200, 66, .75);
            background: rgba(255, 255, 255, .12);
            color: #fff;
        }

        .app-main {
            min-height: calc(100vh - 82px);
            padding: 2rem 0 3rem;
        }

        .app-main > .container {
            max-width: 1280px;
        }

        .app-main h1,
        .app-main h2,
        .app-main h3 {
            color: var(--app-ink);
        }

        .app-main .btn {
            border-radius: 10px;
            font-weight: 600;
        }

        .app-main .btn-primary {
            border-color: var(--app-purple);
            background: linear-gradient(105deg, #8b5cf6, #7136bd);
            box-shadow: 0 5px 13px rgba(78, 35, 136, .14);
        }

        .app-main .btn-primary:hover {
            border-color: #6326a8;
            background: linear-gradient(105deg, #7d4be8, #6326a8);
        }

        .app-main .btn-outline-primary {
            border-color: #bda2dc;
            color: var(--app-purple);
        }

        .app-main .btn-outline-primary:hover {
            border-color: var(--app-purple);
            background: var(--app-purple);
            color: #fff;
        }

        .app-main .btn-secondary {
            border-color: #e6deef;
            background: #f3eff8;
            color: #4c3a69;
        }

        .app-main .btn-secondary:hover {
            border-color: #d3c4e5;
            background: #eae2f4;
            color: #382254;
        }

        .app-main .btn-outline-secondary {
            border-color: #d7cde3;
            color: #65577a;
        }

        .app-main .btn-outline-secondary:hover {
            border-color: #d7cde3;
            background: #f1ebf8;
            color: #49316b;
        }

        .app-main a:not(.btn):not(.module-card):not(.action-link) {
            color: var(--app-purple);
        }

        .app-main a:not(.btn):not(.module-card):not(.action-link):hover {
            color: #56259a;
        }

        .app-main .btn:focus-visible,
        .app-navigation .nav-link:focus-visible,
        .app-logout:focus-visible {
            outline: 3px solid rgba(245, 200, 66, .72);
            outline-offset: 3px;
        }

        .app-main .form-control,
        .app-main .form-select {
            min-height: 42px;
            border-color: #e2dbea;
            border-radius: 10px;
            color: var(--app-ink);
            background-color: #fff;
        }

        .app-main .form-control:focus,
        .app-main .form-select:focus {
            border-color: #b88be7;
            box-shadow: 0 0 0 3px rgba(124, 58, 237, .13);
        }

        .app-main .table {
            --bs-table-bg: #fff;
            --bs-table-striped-bg: #faf8fd;
            --bs-table-hover-bg: #f5effc;
            --bs-table-color: var(--app-ink);
            margin-bottom: 1rem;
            border-color: var(--app-line);
        }

        .app-main .table thead th {
            padding-top: .9rem;
            padding-bottom: .9rem;
            border-bottom-color: #ded3ec;
            background: #f5effb;
            color: #49316b;
            font-size: .82rem;
            font-weight: 700;
            white-space: nowrap;
        }

        .app-main .table tbody td,
        .app-main .table tbody th {
            padding-top: .8rem;
            padding-bottom: .8rem;
        }

        .app-main .card {
            border-color: var(--app-line);
            border-radius: 16px;
            box-shadow: 0 5px 18px rgba(47, 21, 86, .05);
        }

        .app-main .pagination {
            --bs-pagination-color: var(--app-purple);
            --bs-pagination-border-color: var(--app-line);
            --bs-pagination-hover-color: var(--app-purple-dark);
            --bs-pagination-hover-bg: var(--app-lilac);
            --bs-pagination-focus-box-shadow: 0 0 0 .2rem rgba(124, 58, 237, .15);
            --bs-pagination-active-bg: var(--app-purple);
            --bs-pagination-active-border-color: var(--app-purple);
        }

        .app-main .alert {
            border: 0;
            border-radius: 12px;
        }

        .app-main .form-label {
            color: #49316b;
            font-weight: 600;
        }

        @media (max-width: 1050px) {
            .app-header-inner {
                flex-wrap: wrap;
                gap: .55rem 1rem;
                padding: 14px 0 10px;
            }

            .app-navigation {
                order: 3;
                width: 100%;
                flex-basis: 100%;
                overflow-x: auto;
                padding: 3px 0;
                scrollbar-width: thin;
            }

            .app-user {
                margin-left: auto;
            }
        }

        @media (max-width: 575.98px) {
            .app-header-inner {
                width: min(100% - 28px, 1360px);
            }

            .app-brand-logo {
                width: 122px;
            }

            .app-brand-caption {
                font-size: .58rem;
            }

            .app-user {
                gap: 8px;
            }

            .app-user-name {
                display: none;
            }

            .app-main {
                padding: 1.25rem 0 2rem;
            }
        }

        @media print {
            .app-header {
                display: none !important;
            }

            .app-main {
                min-height: 0;
                padding: 0;
            }
        }
    </style>
</head>
<body>
<header class="app-header">
    <div class="app-header-inner">
        <a class="app-brand" href="{{ url('/dashboard') }}" aria-label="E-Surat, Dashboard">
            <img class="app-brand-logo" src="{{ asset('images/veritrus-logo.png') }}" alt="Veritrus">
            <span class="app-brand-caption">Sistem Administrasi<br>Digital Veritrustgs</span>
        </a>

        <nav class="app-navigation" aria-label="Navigasi utama">
            <a class="nav-link {{ request()->is('dashboard') ? 'active' : '' }}" href="{{ url('/dashboard') }}">Dashboard</a>
            <a class="nav-link {{ request()->routeIs('letters.*') ? 'active' : '' }}" href="{{ route('letters.index') }}">Surat</a>
            <a class="nav-link {{ request()->routeIs('invoices.*') ? 'active' : '' }}" href="{{ route('invoices.index') }}">Invoice</a>
            <a class="nav-link {{ request()->routeIs('receipts.*') ? 'active' : '' }}" href="{{ route('receipts.index') }}">Kwitansi</a>
            <a class="nav-link {{ request()->routeIs('reports.*') ? 'active' : '' }}" href="{{ route('reports.monthly') }}">Laporan</a>
            @if (in_array(auth()->user()->role, ['admin', 'direktur'], true))
                <a class="nav-link {{ request()->routeIs('categories.*') ? 'active' : '' }}" href="{{ route('categories.index') }}">Kategori</a>
                <a class="nav-link {{ request()->routeIs('templates.*') ? 'active' : '' }}" href="{{ route('templates.index') }}">Template</a>
                <a class="nav-link {{ request()->routeIs('imports.*') ? 'active' : '' }}" href="{{ route('imports.index') }}">Impor</a>
            @endif
        </nav>

        <div class="app-user">
            <span class="app-user-name">{{ auth()->user()->name }}</span>
            <form method="POST" action="{{ url('/logout') }}">
                @csrf
                <button class="btn app-logout" type="submit">Keluar</button>
            </form>
        </div>
    </div>
</header>

<main class="app-main">
    @yield('content')
</main>
</body>
</html>
