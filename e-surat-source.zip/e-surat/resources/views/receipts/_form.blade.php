

<form method="POST" action="{{ $receipt ? route('receipts.update', $receipt) : route('receipts.store') }}">
    @csrf
    @if ($receipt)
        @method('PUT')
    @endif

    @if ($errors->any())
        <div class="alert alert-danger" role="alert">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <div class="card-body p-4">
            <div class="row g-3">
                <div class="col-md-6">
                    <label for="payer" class="form-label">Telah diterima dari</label>
                    <input id="payer" name="payer" class="form-control" required maxlength="255"
                           value="{{ old('payer', $receipt?->payer) }}" placeholder="Nama pihak yang membayar">
                </div>
                <div class="col-md-6">
                    <label for="date" class="form-label">Tanggal kwitansi</label>
                    <input id="date" type="date" name="date" class="form-control" required
                           value="{{ old('date', $receipt?->date ?? now()->toDateString()) }}">
                </div>
                <div class="col-md-6">
                    <label for="full_number" class="form-label">Nomor kwitansi</label>
                    <input id="full_number" name="full_number" class="form-control" maxlength="255"
                           value="{{ old('full_number', $receipt?->full_number ?? $nextNumber ?? '') }}"
                           placeholder="KWT/POPAL BNSP -Veritrust 413/2026"
                           aria-describedby="receipt-number-help" @required($receipt)>
                    <div id="receipt-number-help" class="form-text">
                        Nomor berikutnya terisi otomatis dan dapat diedit; nomor yang sudah digunakan ditolak.
                    </div>
                </div>
                <div class="col-md-6">
                    <label for="amount" class="form-label">Uang sejumlah (Rp)</label>
                    <input id="amount" type="number" name="amount" class="form-control" required
                           min="0" max="9999999999999" step="0.01"
                           value="{{ old('amount', $receipt?->amount) }}" placeholder="Contoh: 3900000">
                    <div id="amount-preview" class="form-text" aria-live="polite">
                        @php($amountValue = old('amount', $receipt?->amount))
                        {{ $amountValue !== null && $amountValue !== '' ? 'Tampilan nominal: Rp ' . number_format((float) $amountValue, 2, ',', '.') : 'Tampilan nominal akan muncul saat jumlah diisi.' }}
                    </div>
                </div>
                <div class="col-12">
                    <label for="purpose" class="form-label">Untuk keperluan</label>
                    <textarea id="purpose" name="purpose" class="form-control" rows="2" maxlength="2000"
                              required>{{ old('purpose', $receipt?->purpose) }}</textarea>
                    @if (count($savedPurposes) > 0)
                        <div class="input-group mt-2">
                            <select id="saved_purpose" class="form-select" aria-label="Pilih keperluan kwitansi tersimpan">
                                <option value="">Pilih keperluan dari kwitansi sebelumnya</option>
                                @foreach ($savedPurposes as $savedPurpose)
                                    <option value="{{ $savedPurpose }}">{{ $savedPurpose }}</option>
                                @endforeach
                            </select>
                            <button id="use_saved_purpose" class="btn btn-outline-secondary" type="button">Tempel</button>
                        </div>
                    @endif
                    <div class="form-text">Keperluan akan tersimpan bersama kwitansi dan dapat digunakan kembali. Contoh: pelunasan atau pembayaran uang muka training.</div>
                </div>
                <div class="col-md-6">
                    <label for="remaining_amount" class="form-label">Sisa pembayaran (Rp)</label>
                    <input id="remaining_amount" type="number" name="remaining_amount" class="form-control" required
                           min="0" max="9999999999999" step="0.01"
                           value="{{ old('remaining_amount', $receipt?->remaining_amount ?? 0) }}">
                </div>
                <div class="col-md-6">
                    <label for="payment_method" class="form-label">Cara bayar</label>
                    <select id="payment_method" name="payment_method" class="form-select" required>
                        @foreach (['cash' => 'Tunai / Cash', 'transfer' => 'Transfer'] as $value => $label)
                            <option value="{{ $value }}" @selected(old('payment_method', $receipt?->payment_method ?? 'transfer') === $value)>
                                {{ $label }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="status" class="form-label">Status kwitansi</label>
                    <select id="status" name="status" class="form-select" required>
                        @foreach (['paid' => 'Lunas', 'unpaid' => 'Belum Lunas'] as $value => $label)
                            <option value="{{ $value }}" @selected(old('status', $receipt ? ($receipt->isPaid() ? 'paid' : 'unpaid') : 'paid') === $value)>
                                {{ $label }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>
        </div>
        <div class="card-footer bg-white d-flex justify-content-end gap-2 p-3">
            <a href="{{ $receipt ? route('receipts.show', $receipt) : route('receipts.index') }}"
               class="btn btn-outline-secondary">Batal</a>
            <button class="btn btn-primary" type="submit">{{ $receipt ? 'Simpan Perubahan' : 'Buat Kwitansi' }}</button>
        </div>
    </div>
</form>

<script>
    const receiptAmountInput = document.getElementById('amount');
    const receiptAmountPreview = document.getElementById('amount-preview');
    const receiptCurrencyFormatter = new Intl.NumberFormat('id-ID', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });

    receiptAmountInput.addEventListener('input', function () {
        const amount = Number(receiptAmountInput.value);
        receiptAmountPreview.textContent = receiptAmountInput.value === '' || !Number.isFinite(amount)
            ? 'Tampilan nominal akan muncul saat jumlah diisi.'
            : 'Tampilan nominal: Rp ' + receiptCurrencyFormatter.format(amount);
    });
</script>

@if (count($savedPurposes) > 0)
    <script>
        document.getElementById('use_saved_purpose').addEventListener('click', function () {
            const savedPurpose = document.getElementById('saved_purpose');
            if (savedPurpose.value) {
                document.getElementById('purpose').value = savedPurpose.value;
            }
        });
    </script>
@endif
