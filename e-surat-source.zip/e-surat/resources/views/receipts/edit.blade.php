@extends('layouts.app')

@section('content')
<div class="container">
    <div class="mb-3">
        <a href="{{ route('receipts.show', $receipt) }}" class="text-decoration-none">&larr; Kembali ke kwitansi</a>
        <h3 class="mt-2">Edit Kwitansi {{ $receipt->full_number }}</h3>
    </div>
    @include('receipts._form', ['receipt' => $receipt])
</div>
@endsection
