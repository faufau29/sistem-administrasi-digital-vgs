<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Kwitansi {{ $receipt->full_number }}</title>
    <style>
        @page {
            size: A4 landscape;
            margin: 96px 76px 60px;
        }

        body {
            color: #111;
            font-family: "DejaVu Sans", sans-serif;
            font-size: 14px;
        }

        .brand {
            margin: 0 auto 48px;
            text-align: center;
        }

        .brand-table {
            border-collapse: collapse;
            margin: 0 auto;
        }

        .brand-logo-cell {
            padding-right: 8px;
            vertical-align: middle;
        }

        .brand-logo {
            display: block;
            height: 63px;
            width: 72px;
        }

        .brand-copy {
            text-align: left;
            vertical-align: middle;
        }

        .brand-name {
            color: #008b80;
            font-size: 34px;
            font-weight: normal;
            letter-spacing: 1px;
        }

        .brand-tagline {
            color: #49616b;
            font-size: 12px;
            margin-top: -3px;
        }

        h1 {
            font-size: 14px;
            margin: 0 0 16px;
            text-align: center;
        }

        .details {
            border-collapse: collapse;
            line-height: 1.35;
            margin-left: 9px;
            width: 88%;
        }

        .details td {
            padding: 2px 0;
            vertical-align: top;
        }

        .label {
            width: 31%;
        }

        .separator {
            text-align: center;
            width: 2%;
        }

        .value {
            width: 67%;
        }

        .bottom {
            border-collapse: collapse;
            margin-top: 58px;
            width: 100%;
        }

        .bottom td {
            padding: 0;
            vertical-align: top;
        }

        .paid-stamp {
            border-collapse: collapse;
            height: 54px;
            table-layout: fixed;
            width: 201px;
        }

        .paid-stamp td {
            border: 4px solid #69ad44;
            border-radius: 2px;
            color: #111;
            font-size: 27px;
            text-align: center;
            vertical-align: middle;
            white-space: nowrap;
        }

        .not-paid {
            font-size: 25px;
        }

        .payment-note {
            border-collapse: collapse;
            font-size: 11px;
            margin: 26px 0 0 4px;
            white-space: nowrap;
        }

        .payment-note td {
            padding: 0 3px 0 0;
            text-align: left;
            vertical-align: top;
        }

        .payment-note .crossed-out {
            text-decoration: line-through;
        }

        .receiver {
            text-align: center;
            width: 36%;
        }

        .signature-space {
            height: 8px;
        }

        .signature {
            display: block;
            height: auto;
            margin: 0 auto;
            width: 205px;
        }

        .signature-stamped {
            width: 170px;
        }

        .signer {
            font-size: 12px;
        }

    </style>
</head>
<body>
    <div class="brand">
        <table class="brand-table">
            <tr>
                <td class="brand-logo-cell">
                    <img class="brand-logo"
                         src="data:image/png;base64,{{ base64_encode(file_get_contents(public_path('images/receipt-logo.png'))) }}"
                         alt="">
                </td>
                <td class="brand-copy">
                    <div class="brand-name">Veritrust</div>
                    <div class="brand-tagline">Trusted Partner to Be Excellence</div>
                </td>
            </tr>
        </table>
    </div>

    <h1>KWITANSI</h1>

    <table class="details">
        <tr>
            <td class="label">No Kwitansi</td><td class="separator">:</td>
            <td class="value">{{ $receipt->full_number }}</td>
        </tr>
        <tr>
            <td class="label">Tanggal</td><td class="separator">:</td>
            <td class="value">{{ \Carbon\Carbon::parse($receipt->date)->locale('id')->translatedFormat('d F Y') }}</td>
        </tr>
        <tr>
            <td class="label">Telah diterima Dari</td><td class="separator">:</td>
            <td class="value">{{ $receipt->payer }}</td>
        </tr>
        <tr>
            <td class="label">Uang Sejumlah</td><td class="separator">:</td>
            <td class="value">Rp. {{ number_format((float) $receipt->amount, 2, ',', '.') }}</td>
        </tr>
        <tr>
            <td class="label">Untuk Keperluan</td><td class="separator">:</td>
            <td class="value">{{ $receipt->purpose }}</td>
        </tr>
        <tr>
            <td class="label"></td><td class="separator"></td><td class="value">&nbsp;</td>
        </tr>
        <tr>
            <td class="label">Sisa Pembayaran</td><td class="separator">:</td>
            <td class="value">Rp. {{ number_format((float) $receipt->remaining_amount, 0, ',', '.') }}</td>
        </tr>
    </table>

    <table class="bottom">
        <tr>
            <td>
                @if ($receipt->isPaid())
                    <table class="paid-stamp">
                        <tr><td>LUNAS</td></tr>
                    </table>
                @else
                    <table class="paid-stamp not-paid">
                        <tr><td>BELUM LUNAS</td></tr>
                    </table>
                @endif
                <table class="payment-note">
                    <tr>
                        <td>Ket. Bayar:</td>
                        <td>
                            <span class="{{ $receipt->payment_method === 'transfer' ? 'crossed-out' : '' }}">Cash</span>
                            / <span class="{{ $receipt->payment_method === 'cash' ? 'crossed-out' : '' }}">Transfer*</span>
                        </td>
                    </tr>
                </table>
            </td>
            <td class="receiver">
                <strong>Yang Menerima</strong>
                <div class="signature-space"></div>
                <img class="signature {{ $receipt->requiresStamp() ? 'signature-stamped' : '' }}"
                     src="data:image/png;base64,{{ base64_encode(file_get_contents(public_path($receipt->requiresStamp()
                         ? 'images/receipt-signature-stamped.png'
                         : 'images/receipt-signature.png'))) }}"
                     alt="Tanda tangan Fitriyah, S.Si., M.Si">
                <div class="signer">Fitriyah, S.Si., M.Si</div>
            </td>
        </tr>
    </table>
</body>
</html>
