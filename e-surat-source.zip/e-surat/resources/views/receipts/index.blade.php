@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Kwitansi</h3>
        <div>
            <a href="{{ route('receipts.create') }}" class="btn btn-primary">Buat Kwitansi</a>
            <a href="{{ route('receipts.export', ['format'=>'csv','search'=>request('search'),'month'=>request('month'),'year'=>request('year')]) }}" class="btn btn-outline-secondary">Ekspor CSV</a>
            <a href="{{ route('receipts.export', ['format'=>'xlsx','search'=>request('search'),'month'=>request('month'),'year'=>request('year')]) }}" class="btn btn-outline-secondary">Ekspor Excel</a>
        </div>
    </div>

    <form class="row g-2 mb-3" method="GET">
        <div class="col-md-5">
            <input name="search" value="{{ request('search') }}" class="form-control" placeholder="Cari nomor, pembayar, keperluan">
        </div>
        <div class="col-md-3">
            <select name="month" class="form-select" aria-label="Filter bulan">
                <option value="">Semua bulan</option>
                @foreach ([
                    1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
                    5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
                    9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember',
                ] as $monthNumber => $monthName)
                    <option value="{{ $monthNumber }}" @selected((string) request('month') === (string) $monthNumber)>{{ $monthName }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-md-2">
            <input type="number" name="year" value="{{ request('year') }}" class="form-control"
                   min="1900" max="9999" placeholder="Tahun" aria-label="Filter tahun">
        </div>
        <div class="col-md-2 d-flex gap-2">
            <button class="btn btn-outline-secondary">Filter</button>
            <a href="{{ route('receipts.index') }}" class="btn btn-outline-secondary">Reset</a>
        </div>
    </form>

    <table class="table table-striped">
        <thead><tr><th>Nomor Kwitansi</th><th>Tanggal</th><th>Diterima dari</th><th>Jumlah</th><th>Status</th><th></th></tr></thead>
        <tbody>
        @forelse($receipts as $receipt)
            <tr>
                <td>{{ $receipt->full_number }}</td>
                <td>{{ \Carbon\Carbon::parse($receipt->date)->format('d/m/Y') }}</td>
                <td>{{ $receipt->payer }}</td>
                <td>Rp {{ number_format($receipt->amount, 0, ',', '.') }}</td>
                <td>{{ $receipt->paymentStatusLabel() }}</td>
                <td class="text-nowrap">
                    <a href="{{ route('receipts.show', $receipt) }}" class="btn btn-sm btn-outline-primary">Lihat</a>
                    <a href="{{ route('receipts.edit', $receipt) }}" class="btn btn-sm btn-outline-secondary">Edit</a>
                    <a href="{{ route('receipts.pdf', $receipt) }}" class="btn btn-sm btn-outline-secondary" target="_blank" rel="noopener">PDF</a>
                </td>
            </tr>
        @empty
            <tr><td colspan="6" class="py-4 text-center text-muted">Belum ada kwitansi.</td></tr>
        @endforelse
        </tbody>
    </table>

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
        <p class="mb-0 text-muted">
            Menampilkan {{ $receipts->firstItem() ?? 0 }} s/d {{ $receipts->lastItem() ?? 0 }}
            dari <strong>{{ $receipts->total() }} data</strong>
        </p>
        {{ $receipts->links('pagination.invoices') }}
    </div>
</div>
@endsection
