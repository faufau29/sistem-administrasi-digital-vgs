@extends('layouts.app')

@section('content')
<div class="container">
    <div class="mb-3">
        <a href="{{ route('receipts.index') }}" class="text-decoration-none">&larr; Kembali ke daftar kwitansi</a>
        <h3 class="mt-2">Buat Kwitansi</h3>
        <p class="text-muted mb-0">Nomor kwitansi terisi otomatis dan dapat diedit sebelum disimpan.</p>
    </div>
    @include('receipts._form', ['receipt' => null])
</div>
@endsection
