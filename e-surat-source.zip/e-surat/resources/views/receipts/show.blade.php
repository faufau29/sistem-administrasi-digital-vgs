@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
        <div>
            <a href="{{ route('receipts.index') }}" class="text-decoration-none">&larr; Kembali ke daftar kwitansi</a>
            <h3 class="mt-2 mb-0">Kwitansi {{ $receipt->full_number }}</h3>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <a href="{{ route('receipts.word', $receipt) }}" class="btn btn-outline-primary" target="_blank" rel="noopener">Unduh Word</a>
            <a href="{{ route('receipts.pdf', $receipt) }}" class="btn btn-primary" target="_blank" rel="noopener">Unduh / Cetak PDF</a>
            <a href="{{ route('receipts.edit', $receipt) }}" class="btn btn-outline-secondary">Edit</a>
        </div>
    </div>

    <div class="card">
        <div class="card-body p-4">
            <div class="row g-3">
                <div class="col-md-6"><strong>Nomor kwitansi:</strong> {{ $receipt->full_number }}</div>
                <div class="col-md-6"><strong>Tanggal:</strong> {{ \Carbon\Carbon::parse($receipt->date)->locale('id')->translatedFormat('d F Y') }}</div>
                <div class="col-md-6"><strong>Telah diterima dari:</strong> {{ $receipt->payer }}</div>
                <div class="col-md-6"><strong>Uang sejumlah:</strong> Rp {{ number_format($receipt->amount, 2, ',', '.') }}</div>
                <div class="col-12"><strong>Untuk keperluan:</strong> {{ $receipt->purpose }}</div>
                <div class="col-md-6"><strong>Sisa pembayaran:</strong> Rp {{ number_format($receipt->remaining_amount, 2, ',', '.') }}</div>
                <div class="col-md-6"><strong>Cara bayar:</strong> {{ $receipt->payment_method === 'cash' ? 'Cash' : 'Transfer' }}</div>
                <div class="col-md-6"><strong>Status:</strong> {{ $receipt->paymentStatusLabel() }}</div>
            </div>
            <div class="mt-4">
                <form method="POST" action="{{ route('receipts.destroy', $receipt) }}"
                      onsubmit="return confirm('Yakin ingin menghapus kwitansi ini?')">
                    @csrf
                    @method('DELETE')
                    <button class="btn btn-outline-danger" type="submit">Hapus Kwitansi</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
