@extends('layouts.app')

@section('content')
<div class="container">
    <h3>Edit Template</h3>
    <form method="POST" action="{{ route('templates.update', $template) }}" enctype="multipart/form-data">
        @csrf @method('PUT')
        <div class="mb-3">
            <label class="form-label">Name</label>
            <input name="name" class="form-control" required value="{{ $template->name }}">
        </div>
        <div class="mb-3">
            <label class="form-label">Kategori Arsip / Penomoran</label>
            <select name="category_id" class="form-control">
                <option value="">-- none --</option>
                @foreach($categories as $c)
                    <option value="{{ $c->id }}" {{ $template->category_id == $c->id ? 'selected':'' }}>{{ $c->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Format untuk Jenis Surat</label>
            <select name="letter_type" class="form-control">
                <option value="">-- template umum --</option>
                @foreach($letterTypes as $value => $label)
                    <option value="{{ $value }}" {{ $template->letter_type === $value ? 'selected' : '' }}>{{ $label }}</option>
                @endforeach
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Content</label>
            <textarea name="content" class="form-control" rows="8">{{ $template->content }}</textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Upload DOCX template (optional)</label>
            <input type="file" name="template_file" class="form-control">
            @if($template->file_name)
                <div class="mt-2">Current file: <a href="{{ Storage::url('templates/'.$template->file_name) }}" target="_blank">{{ $template->file_name }}</a></div>
            @endif
        </div>
        <div class="form-check mb-3">
            <input type="checkbox" name="is_default" class="form-check-input" {{ $template->is_default ? 'checked':'' }}>
            <label class="form-check-label">Default for this letter format</label>
        </div>
        <button class="btn btn-primary">Update</button>
    </form>
</div>
@endsection
