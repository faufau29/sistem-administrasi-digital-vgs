@extends('layouts.app')

@section('content')
<div class="container">
    <h3>New Template</h3>
    <form method="POST" action="{{ route('templates.store') }}" enctype="multipart/form-data">
        @csrf
        <div class="mb-3">
            <label class="form-label">Name</label>
            <input name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Kategori Arsip / Penomoran</label>
            <select name="category_id" class="form-control">
                <option value="">-- none --</option>
                @foreach($categories as $c)
                    <option value="{{ $c->id }}">{{ $c->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Format untuk Jenis Surat</label>
            <select name="letter_type" class="form-control">
                <option value="">-- template umum --</option>
                @foreach($letterTypes as $value => $label)
                    <option value="{{ $value }}">{{ $label }}</option>
                @endforeach
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Content (use placeholders like {{'{{nomor_surat}}'}} for HTML templates)</label>
            <textarea name="content" class="form-control" rows="8"></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">DOCX placeholders</label>
            <div class="small text-muted">When uploading a DOCX template, use PhpWord Template placeholders like <code>${subject}</code>, <code>${date}</code>, <code>${full_number}</code>, <code>${recipient_name}</code>, <code>${body}</code>.</div>
        </div>
        <div class="mb-3">
            <label class="form-label">Upload DOCX template (optional)</label>
            <input type="file" name="template_file" class="form-control">
        </div>
        <div class="form-check mb-3">
            <input type="checkbox" name="is_default" class="form-check-input">
            <label class="form-check-label">Default for this letter format</label>
        </div>
        <button class="btn btn-primary">Create</button>
    </form>
</div>
@endsection
