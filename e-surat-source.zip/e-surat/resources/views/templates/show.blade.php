@extends('layouts.app')

@section('content')
<div class="container">
    <h3>Template Details</h3>
    <div class="card mb-3">
        <div class="card-body">
            <p><strong>Name:</strong> {{ $template->name }}</p>
            <p><strong>Category:</strong> {{ $template->category->name ?? 'Global' }}</p>
            <p><strong>Default:</strong> {{ $template->is_default ? 'Yes' : 'No' }}</p>
            <hr>
            <div><strong>Content</strong></div>
            <pre class="bg-light p-3">{{ $template->content }}</pre>
            <div class="mt-3">
                <a href="{{ route('templates.edit', $template) }}" class="btn btn-secondary">Edit</a>
                @if($template->file_name)
                    <a href="{{ Storage::url('templates/'.$template->file_name) }}" class="btn btn-outline-primary" target="_blank">Download DOCX</a>
                @endif
                <form method="POST" action="{{ route('templates.destroy', $template) }}" style="display:inline-block;" onsubmit="return confirm('Delete this template?')">
                    @csrf @method('DELETE')
                    <button class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
