@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Letter Templates</h3>
        <a href="{{ route('templates.create') }}" class="btn btn-primary">New Template</a>
    </div>

    @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif

    <table class="table table-striped">
        <thead><tr><th>Name</th><th>Format Surat</th><th>Kategori Arsip</th><th>Default</th><th></th></tr></thead>
        <tbody>
        @foreach($templates as $t)
            <tr>
                <td>{{ $t->name }}</td>
                <td>{{ $t->letter_type ? config('letter_types.'.$t->letter_type, 'Surat Umum') : 'Template Umum' }}</td>
                <td>{{ $t->category->name ?? '-' }}</td>
                <td>{{ $t->is_default ? 'Yes':'No' }}</td>
                <td>
                    <a href="{{ route('templates.edit', $t) }}" class="btn btn-sm btn-secondary">Edit</a>
                    <form action="{{ route('templates.destroy', $t) }}" method="POST" style="display:inline-block;" onsubmit="return confirm('Delete?')">
                        @csrf @method('DELETE')
                        <button class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>

    {{ $templates->links() }}
</div>
@endsection
