@extends('layouts.auth')

@section('title', 'Masuk')

@section('form')
    <div class="form-symbol" aria-hidden="true">
        <svg viewBox="0 0 32 32" fill="none">
            <path d="M10 10V7.5A2.5 2.5 0 0 1 12.5 5h7A2.5 2.5 0 0 1 22 7.5V10" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
            <path d="M5 11.5A2.5 2.5 0 0 1 7.5 9h17a2.5 2.5 0 0 1 2.5 2.5v13a2.5 2.5 0 0 1-2.5 2.5h-17A2.5 2.5 0 0 1 5 24.5v-13Z" fill="currentColor"/>
            <path d="m7 13 9 6.5 9-6.5" stroke="#53259a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </div>
    <h2 class="form-title">Login</h2>
    <p class="form-description">Sistem Administrasi Digital PT VGS</p>

    @if ($errors->any())
        <div class="alert alert-danger" role="alert">{{ $errors->first() }}</div>
    @endif

    <form class="auth-login-form" method="POST" action="{{ url('/login') }}">
        @csrf
        <div class="mb-3">
            <label for="email" class="visually-hidden">Alamat email</label>
            <div class="auth-input-wrap">
                <svg class="auth-input-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm0 2c-4.42 0-8 2.24-8 5v1h16v-1c0-2.76-3.58-5-8-5Z"/>
                </svg>
                <input id="email" type="email" name="email" class="form-control" placeholder="Masukkan email"
                   autocomplete="email" required autofocus value="{{ old('email') }}">
            </div>
        </div>
        <div class="mb-4">
            <label for="password" class="visually-hidden">Kata sandi</label>
            <div class="auth-input-wrap">
                <svg class="auth-input-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17 9h-1V7a4 4 0 0 0-8 0v2H7a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2ZM10 7a2 2 0 1 1 4 0v2h-4V7Zm3 9.73V18h-2v-1.27a2 2 0 1 1 2 0Z"/>
                </svg>
                <input id="password" type="password" name="password" class="form-control has-password-toggle" placeholder="Masukkan kata sandi"
                   autocomplete="current-password" required>
                <button class="password-toggle" type="button" data-password-toggle="password"
                        aria-label="Tampilkan kata sandi" aria-pressed="false">
                    <svg class="eye" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none">
                        <path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>
                        <circle cx="12" cy="12" r="2.7" stroke="currentColor" stroke-width="1.8"/>
                    </svg>
                    <svg class="eye-off" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none">
                        <path d="m3 3 18 18M10.6 6.2A9.8 9.8 0 0 1 12 6c6 0 9.5 6 9.5 6a16 16 0 0 1-3.1 3.7M6.2 6.7C3.9 8.2 2.5 12 2.5 12s3.5 6 9.5 6c1 0 1.9-.2 2.7-.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M9.9 9.9a3 3 0 0 0 4.2 4.2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                    </svg>
                </button>
            </div>
        </div>
        <div class="remember-row">
            <input id="remember" class="form-check-input" type="checkbox" name="remember" value="1">
            <label for="remember">Ingat saya</label>
        </div>
        <div class="d-grid">
            <button class="btn btn-auth" type="submit">Login</button>
        </div>
    </form>

    <p class="auth-switch">Belum punya akun? <a href="{{ route('register') }}">Daftar sekarang</a></p>
@endsection
