@extends('layouts.auth')

@section('title', 'Buat Akun')

@section('form')
    <div class="form-symbol" aria-hidden="true">
        <svg viewBox="0 0 32 32" fill="none">
            <circle cx="13" cy="11" r="5" stroke="currentColor" stroke-width="2.5"/>
            <path d="M4.5 26a8.5 8.5 0 0 1 17 0" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
            <path d="M24 13v10m-5-5h10" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
        </svg>
    </div>
    <p class="form-kicker">Mulai sekarang</p>
    <h2 class="form-title">Buat akun baru</h2>
    <p class="form-description">Isi data berikut untuk membuat akun staf dan mulai menggunakan E-Surat.</p>

    @if ($errors->any())
        <div class="alert alert-danger" role="alert">{{ $errors->first() }}</div>
    @endif

    <form method="POST" action="{{ route('register') }}">
        @csrf
        <div class="mb-3">
            <label for="name" class="form-label">Nama lengkap</label>
            <input id="name" type="text" name="name" class="form-control" placeholder="Nama Anda"
                   autocomplete="name" required autofocus value="{{ old('name') }}">
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Alamat email</label>
            <input id="email" type="email" name="email" class="form-control" placeholder="nama@perusahaan.com"
                   autocomplete="email" required value="{{ old('email') }}">
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Kata sandi</label>
            <div class="auth-input-wrap password-wrap">
                <input id="password" type="password" name="password" class="form-control has-password-toggle" placeholder="Minimal 8 karakter"
                       autocomplete="new-password" required>
                <button class="password-toggle" type="button" data-password-toggle="password"
                        aria-label="Tampilkan kata sandi" aria-pressed="false">
                    <svg class="eye" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none">
                        <path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>
                        <circle cx="12" cy="12" r="2.7" stroke="currentColor" stroke-width="1.8"/>
                    </svg>
                    <svg class="eye-off" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none">
                        <path d="m3 3 18 18M10.6 6.2A9.8 9.8 0 0 1 12 6c6 0 9.5 6 9.5 6a16 16 0 0 1-3.1 3.7M6.2 6.7C3.9 8.2 2.5 12 2.5 12s3.5 6 9.5 6c1 0 1.9-.2 2.7-.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M9.9 9.9a3 3 0 0 0 4.2 4.2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                    </svg>
                </button>
            </div>
        </div>
        <div class="mb-4">
            <label for="password_confirmation" class="form-label">Ulangi kata sandi</label>
            <div class="auth-input-wrap password-wrap">
                <input id="password_confirmation" type="password" name="password_confirmation" class="form-control has-password-toggle"
                       placeholder="Masukkan ulang kata sandi" autocomplete="new-password" required>
                <button class="password-toggle" type="button" data-password-toggle="password_confirmation"
                        aria-label="Tampilkan kata sandi" aria-pressed="false">
                    <svg class="eye" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none">
                        <path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>
                        <circle cx="12" cy="12" r="2.7" stroke="currentColor" stroke-width="1.8"/>
                    </svg>
                    <svg class="eye-off" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none">
                        <path d="m3 3 18 18M10.6 6.2A9.8 9.8 0 0 1 12 6c6 0 9.5 6 9.5 6a16 16 0 0 1-3.1 3.7M6.2 6.7C3.9 8.2 2.5 12 2.5 12s3.5 6 9.5 6c1 0 1.9-.2 2.7-.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M9.9 9.9a3 3 0 0 0 4.2 4.2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
                    </svg>
                </button>
            </div>
        </div>
        <div class="d-grid">
            <button class="btn btn-auth" type="submit">Buat akun</button>
        </div>
    </form>

    <p class="auth-switch">Sudah punya akun? <a href="{{ route('login') }}">Masuk</a></p>
@endsection
